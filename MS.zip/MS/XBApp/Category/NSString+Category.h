//
//  NSString+Category.h
//  MonkeyKing
//
//  Created by paimwin123 on 2018/3/15.
//  Copyright © 2018年 paimwin123. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Category)

/**
 *  用户名验证
 *
 *  @param userName 用户名
 *
 *  @return 是否符合规则
 */
+ (BOOL)isUserName:(NSString * _Nullable)userName;

/**
 *  判断是否是密码
 *
 *  @param passworld 密码
 *
 *  @return 是否符合规则 字母数字下划线的组合
 */
+ (BOOL)isPasswodld:(NSString *_Nullable)passworld;

//计算出图片缓存大小
+ (NSString * _Nullable)fileSize;

//当前版本号
+ (NSString * _Nullable)getNowVersion;


+ (NSString *_Nullable)getTime:(long)time;
+ (NSString *_Nullable)getmatichTime:(long)time;

+ (NSString *)get24Color:(long)time;


- (BOOL)isPhoneNum;


+ (NSString*_Nullable)getCurrentTimes;
//获取当前时间戳
+(NSString *_Nullable)getNowTimeTimestamp;

+ (NSString *_Nullable)getThisTime:(NSNumber *_Nullable)time;

//获取年月日
+ (NSString *_Nullable)getAboutTime:(NSString *_Nullable)time;

/**
 获取当前周几
 */
+ (NSString *_Nullable)getCurrentWeek;
+ (NSString *_Nullable)getTodayStr;


/**
 字符串转时间戳
 */
+(NSInteger)timeSwitchTimestamp:(NSString *)formatTime andFormatter:(NSString *)format;


+ (NSString *)getFullTime:(NSNumber *)time;
@end
