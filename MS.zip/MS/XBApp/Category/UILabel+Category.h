//
//  UILabel+Category.h
//  MonkeyKing
//
//  Created by paimwin123 on 2018/3/15.
//  Copyright © 2018年 paimwin123. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Category)

/**
 *  获取label高度
 *
 *  @param width 标签宽
 *
 *  @return label高度
 */
- (CGFloat)getHeightWithWidth:(CGFloat)width;

- (CGFloat)getWidth;

- (void)setDifferentColor:(UIColor *)color with:(NSRange)rang;

- (void)setDifferentFont:(NSInteger)font with:(NSRange)rang;

/**
 改变label中已知文字的颜色

 @param changeArr 要改变颜色font的字符串数组
 @param allColor 不改变的颜色
 @param markColor 改变的颜色
 @param fontSize 改变的font
 */

- (void)changeStringArr:(NSArray *)changeArr andAllColor:(UIColor *)allColor andMarkColor:(UIColor *)markColor andMarkFondSize:(float)fontSize;

/**
 添加删除线
 */
- (void)adddeleteLine;
@end
