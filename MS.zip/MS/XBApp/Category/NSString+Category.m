//
//  NSString+Category.m
//  MonkeyKing
//
//  Created by paimwin123 on 2018/3/15.
//  Copyright © 2018年 paimwin123. All rights reserved.
//

#import "NSString+Category.h"
#import <SDImageCache.h>

@implementation NSString (Category)

/**
 *  用户名验证
 *
 *  @param userName 用户名
 *
 *  @return 是否符合规则
 */
+ (BOOL)isUserName:(NSString *)userName
{
    NSString *phoneRegex1 = @"^[\u4E00-\u9FA5A-Za-z0-9_]+$";
    NSPredicate *phoneTest1 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex1];
    return  [phoneTest1 evaluateWithObject:userName];
}


/**
 *  判断是否是密码
 *
 *  @param passworld 密码
 *
 *  @return 是否符合规则 字母数字下划线的组合
 */
+ (BOOL)isPasswodld:(NSString *)passworld {
    //    /^[\w]{6,20}$/
    NSString *phoneRegex1 = @"^[A-Za-z0-9_]{6,20}$";
    NSPredicate *phoneTest1 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex1];
//    bool a =  [phoneTest1 evaluateWithObject:passworld];
    return  [phoneTest1 evaluateWithObject:passworld];
}

//计算出大小
+ (NSString *)fileSize {
    NSUInteger size = [[SDImageCache sharedImageCache] getSize];
    // 1k = 1024, 1m = 1024k
    if (size < 1024) {// 小于1k
        return [NSString stringWithFormat:@"%ldB",(long)size];
    }else if (size < 1024 * 1024){// 小于1m
        CGFloat aFloat = size/1024;
        return [NSString stringWithFormat:@"%.0fK",aFloat];
    }else if (size < 1024 * 1024 * 1024){// 小于1G
        CGFloat aFloat = size/(1024 * 1024);
        return [NSString stringWithFormat:@"%.2fM",aFloat];
    }else{
        CGFloat aFloat = size/(1024*1024*1024);
        return [NSString stringWithFormat:@"%.2fG",aFloat];
    }
}


//当前版本号
+(NSString *)getNowVersion {
    NSString * str = [[[NSBundle mainBundle] infoDictionary] valueForKey:@"CFBundleShortVersionString"];
    return [NSString stringWithFormat:@"v%@", str];
}

- (BOOL)isPhoneNum{

    // 130-139  150-153,155-159  180-189  145,147  170,171,173,176,177,178
    NSString *phoneRegex = @"^((13[0-9])|(15[^4,\\D])|(18[0-9])|(14[57])|(17[013678]))\\d{8}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    return [phoneTest evaluateWithObject:self];

}

+ (NSString *)getTime:(long)time {
    NSDateFormatter *stampFormatter = [[NSDateFormatter alloc] init];
    [stampFormatter setDateFormat:@"YYYY-MM-dd"];
    //以 1970/01/01 GMT为基准，然后过了secs秒的时间   HH:mm:ss
    NSDate *stampDate = [NSDate dateWithTimeIntervalSince1970:time];
    return  [stampFormatter stringFromDate:stampDate];
    
}

+ (NSString *)get24Color:(long)time {
    NSDateFormatter *stampFormatter = [[NSDateFormatter alloc] init];
    [stampFormatter setDateFormat:@"YYYY-MM-dd"];
    //以 1970/01/01 GMT为基准，然后过了secs秒的时间   HH:mm:ss
    NSDate *stampDate = [NSDate dateWithTimeIntervalSince1970:time];
    NSString *abouttime =  [stampFormatter stringFromDate:stampDate];
    
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:@"YYYY-MM-dd"]; //(@"YYYY-MM-dd hh:mm:ss") ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    
    
    
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    
    [formatter setTimeZone:timeZone];
    
    
    
    NSDate* date = [formatter dateFromString:abouttime]; //------------将字符串按formatter转成nsdate
    
    //时间转时间戳的方法:
    
    NSInteger timeSp = [[NSNumber numberWithDouble:[date timeIntervalSince1970]] integerValue];
    
    
    
//    NSLog(@"将某个时间转化成 时间戳&&&&&&&timeSp:%ld",(long)timeSp); //时间戳的值
    
    
    
    return @(timeSp).stringValue;
    
}

+ (NSString *)getThisTime:(NSNumber *)time {
    NSDateFormatter *stampFormatter = [[NSDateFormatter alloc] init];
    [stampFormatter setDateFormat:@"MM-dd HH:mm"];
    NSDate *stampDate = [NSDate dateWithTimeIntervalSince1970:time.integerValue / 1000];
    return  [stampFormatter stringFromDate:stampDate];
}

+ (NSString *)getFullTime:(NSNumber *)time {
    NSDateFormatter *stampFormatter = [[NSDateFormatter alloc] init];
    [stampFormatter setDateFormat:@"YYYY-MM-dd HH:mm"];
    NSDate *stampDate = [NSDate dateWithTimeIntervalSince1970:time.integerValue / 1000];
    return  [stampFormatter stringFromDate:stampDate];
}

+ (NSString *)getmatichTime:(long)time {
    NSDateFormatter *stampFormatter = [[NSDateFormatter alloc] init];
    [stampFormatter setDateFormat:@"HH:mm"];
    //以 1970/01/01 GMT为基准，然后过了secs秒的时间   HH:mm:ss
    NSDate *stampDate = [NSDate dateWithTimeIntervalSince1970:time];
    NSString * timeStr = [[stampFormatter stringFromDate:stampDate] substringToIndex:2];
    if (timeStr.integerValue < 9) {
        return @"24:00";
    } else {
        NSDate *stampDate2 = [NSDate dateWithTimeIntervalSince1970:time - 60 * 60];
        return [stampFormatter stringFromDate:stampDate2];
    }
}



+ (NSString *)getCurrentWeek {
    NSDateComponents *componets = [[NSCalendar autoupdatingCurrentCalendar] components:NSCalendarUnitWeekday fromDate:[NSDate date]];
    NSInteger weekday = [componets weekday];
    NSString *currentWeek  = weekday == 1 ? @"7" : [NSString stringWithFormat:@"%zd", weekday -1];
    return currentWeek;
}

+(NSString*)getCurrentTimes{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    
    //现在时间,你可以输出来看下是什么格式
    
    NSDate *datenow = [NSDate date];
    
    //----------将nsdate按formatter格式转成nsstring
    
    NSString *currentTimeString = [formatter stringFromDate:datenow];
    
    
    return currentTimeString;
    
}

+ (NSString *)getTodayStr {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    
    [formatter setDateFormat:@"YYYY-MM-dd"];
    
    //现在时间,你可以输出来看下是什么格式
    
    NSDate *datenow = [NSDate date];
    
    //----------将nsdate按formatter格式转成nsstring
    
    NSString *currentTimeString = [formatter stringFromDate:datenow];

    return currentTimeString;
}


+ (NSString *)getAboutTime:(NSString *)time {
    
    NSDate *date  = [NSDate dateWithTimeIntervalSince1970:time.integerValue];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd E"];
    NSString *dateString  = [formatter stringFromDate: date];
    return dateString;
    
}



+(NSString *)getNowTimeTimestamp{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init] ;
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"]; // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    
    //设置时区,这个对于时间的处理有时很重要
    
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    
    [formatter setTimeZone:timeZone];
    
    NSDate *datenow = [NSDate date];//现在时间,你可以输出来看下是什么格式
    
    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[datenow timeIntervalSince1970]];
    
    return timeSp;
    
}





/**
字符串转时间戳
 */
+(NSInteger)timeSwitchTimestamp:(NSString *)formatTime andFormatter:(NSString *)format{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:format]; //(@"YYYY-MM-dd hh:mm:ss") ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    
    [formatter setTimeZone:timeZone];
    NSDate* date = [formatter dateFromString:formatTime]; //------------将字符串按formatter转成nsdate
    
    //时间转时间戳的方法:
    
    NSInteger timeSp = [[NSNumber numberWithDouble:[date timeIntervalSince1970]] integerValue];
    return timeSp;
}



@end
