//
//  UIImage+Gategory.h
//  QuestionsAndAnswers
//
//  Created by paimwin123 on 17/4/27.
//  Copyright © 2017年 paimwin123. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Gategory)

- (UIImage *)fixOrientation;

+ (UIImage *)newImageWithImage:(UIImage *)image filterName:(NSString *)name;

+ (UIImage *)createImageWithColor:(UIColor*)color rect:(CGRect)rect;

+ (UIImage *)coreBlurImage:(UIImage *)image withBlurNumber:(CGFloat)blur;



/**
图片压缩
 */
+(NSData *)zipNSDataWithImage:(UIImage *)sourceImage;
@end
