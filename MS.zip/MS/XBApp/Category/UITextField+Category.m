//
//  UITextField+Category.m
//  MonkeyKing
//
//  Created by paimwin123 on 2018/3/15.
//  Copyright © 2018年 paimwin123. All rights reserved.
//

#import "UITextField+Category.h"

@implementation UITextField (Category)

/**
 *  提示文字 和 颜色
 */
- (void)setPlaceholder:(NSString *)placeholder WithColor:(UIColor *)color {
    self.placeholder = placeholder;
    self.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.placeholder attributes:@{NSForegroundColorAttributeName: color}];
}

@end
