//
//  AppleStoreModel.m
//  KuMeiYouPin
//
//  Created by 陈一 on 2018/3/23.
//  Copyright © 2018年 chenyi. All rights reserved.
//

#import "AppleStoreModel.h"

@implementation AppleStoreModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end
