//
//  UIViewController+Category.m
//  MonkeyKing
//
//  Created by paimwin123 on 2018/3/15.
//  Copyright © 2018年 paimwin123. All rights reserved.
//

#import "UIViewController+Category.h"
#import "AppDelegate.h"
#import "sys/utsname.h"

@implementation UIViewController (Category)

- (CGFloat)navHeight {
    static float navHeight = 0;
    if (navHeight == 0) {
        // 状态栏(statusbar)
        CGRect rectStatus = [[UIApplication sharedApplication] statusBarFrame];
        
        // 导航栏（navigationbar）
        CGRect rectNav = self.navigationController.navigationBar.frame;
        navHeight = rectStatus.size.height + rectNav.size.height;
    }
    
    return navHeight;
}

/**
 *  设置背景色
 */
- (void)setBackgroundColor:(UIColor *)color {
    self.view.backgroundColor = color;
}

/**
 *  设置返回按钮
 */
- (void)setLeftBarButtonItem {
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"back_black"] imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)] style:(UIBarButtonItemStylePlain) target:self action:@selector(popEvent)];
    self.navigationController.interactivePopGestureRecognizer.delegate = (id<UIGestureRecognizerDelegate>)self;
}


/**
 *  设置返回按钮
 */
- (void)setLeftBarButtonItemWithTitle:(NSString *_Nullable)title {
    UIButton *right = [UIButton buttonWithType:UIButtonTypeCustom];
    right.frame = CGRectMake(0, 0, 60, 44);
    [right addTarget:self action:@selector(popEvent) forControlEvents:UIControlEventTouchUpInside];
    [right setTitleColor:UIColorFromRGB(0x4c5468) forState:(UIControlStateNormal)];
    right.titleLabel.font = [UIFont systemFontOfSize:15];
    [right setTitle:title forState:UIControlStateNormal];
    UIBarButtonItem *rightBut = [[UIBarButtonItem alloc] initWithCustomView:right];
    self.navigationItem.leftBarButtonItem = rightBut;
    self.navigationController.interactivePopGestureRecognizer.delegate = (id<UIGestureRecognizerDelegate>)self;
}

/**
 *  pop ViewController
 */
- (void)popEvent {
//    self.navigationController.interactivePopGestureRecognizer.delegate = nil;
    [self.navigationController popViewControllerAnimated:true];
}

/**
 *  设置返回按钮
 */
- (void)setRightBarButtonItemWithImage:(NSString *_Nullable)imageString action:(nullable SEL)action {
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:imageString] imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)] style:(UIBarButtonItemStylePlain) target:self action:action];
}

/**
 *  设置右按钮
 */
- (void)setRightBarButtonItemWithTitle:(NSString *_Nullable)title action:(nullable SEL)action {
    UIButton *right = [UIButton buttonWithType:UIButtonTypeCustom];
    right.frame = CGRectMake(0, 0, 60, 44);
    [right addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [right setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    right.titleLabel.font = [UIFont systemFontOfSize:15];
    [right setTitle:title forState:UIControlStateNormal];
    UIBarButtonItem *rightBut = [[UIBarButtonItem alloc] initWithCustomView:right];
    self.navigationItem.rightBarButtonItem = rightBut;
}

/**
 *  更改导航栏字体颜色
 */
- (void)setTitleWithColor:(UIColor *)color font:(UIFont *)font {
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithObject:color forKey:NSForegroundColorAttributeName];
    [dict setObject:font forKey:NSFontAttributeName];
    self.navigationController.navigationBar.titleTextAttributes = dict;
}

/**
 *  信息提示
 */
- (void)showToast:(NSString *)text{
    
    CGFloat width = 60;
    
    UILabel *tipLabel=nil;
    UIWindow *window = ((AppDelegate *)[UIApplication sharedApplication].delegate).window;
    tipLabel=(UILabel *)[window viewWithTag:8888];
    NSDictionary * tdic = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:14],NSFontAttributeName,nil];
    CGSize  actualsize =[text boundingRectWithSize:CGSizeMake(10000,MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin  attributes:tdic context:nil].size;
    
    if (!tipLabel) {
        tipLabel=[[UILabel alloc] initWithFrame:CGRectMake((window.bounds.size.width - width *ZOOM_SCALE - actualsize.width)/2, (window.bounds.size.height-64)/2-30, width + actualsize.width, actualsize.height + 20 * ZOOM_SCALE)];
        tipLabel.backgroundColor = JKRGBAColor(1, 1, 1, 0.8);
        tipLabel.alpha = 0.8;
        tipLabel.layer.cornerRadius = 10;
        tipLabel.clipsToBounds = YES;
        tipLabel.textAlignment=NSTextAlignmentCenter;
        tipLabel.textColor=[UIColor colorWithWhite:1.0 alpha:0.8];
        tipLabel.font=[UIFont boldSystemFontOfSize:14];
        tipLabel.numberOfLines=0;
        tipLabel.tag=8888;
        tipLabel.text=text;
        [window addSubview:tipLabel];
    } else {
        tipLabel.frame = CGRectMake((window.bounds.size.width - width * ZOOM_SCALE - actualsize.width)/2, (window.bounds.size.height-64)/2, width + actualsize.width, actualsize.height + 20 * ZOOM_SCALE);
        tipLabel.text=text;
    }
    [self performSelector:@selector(removeToast) withObject:nil afterDelay:1.5];
}

- (void)removeToast{
    UIWindow *window = ((AppDelegate *)[UIApplication sharedApplication].delegate).window;
    UILabel *label=(UILabel *)[window viewWithTag:8888];
    //    [UIView animateWithDuration:1.0
    //                     animations:^{
    //                         label.frame=CGRectMake(window.bounds.size.width/2, (window.bounds.size.height - 64)/2, 0, 0);
    //                     }completion:^(BOOL finished) {
    [label removeFromSuperview];
    //                     }];
}

- (NSString *)iphoneType {
    
    struct utsname systemInfo;
    
    uname(&systemInfo);
    
    NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
    
    if ([platform isEqualToString:@"iPhone1,1"]) return @"iPhone 2G";
    
    if ([platform isEqualToString:@"iPhone1,2"]) return @"iPhone 3G";
    
    if ([platform isEqualToString:@"iPhone2,1"]) return @"iPhone 3GS";
    
    if ([platform isEqualToString:@"iPhone3,1"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone3,2"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone3,3"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone4,1"]) return @"iPhone 4S";
    
    if ([platform isEqualToString:@"iPhone5,1"]) return @"iPhone 5";
    
    if ([platform isEqualToString:@"iPhone5,2"]) return @"iPhone 5";
    
    if ([platform isEqualToString:@"iPhone5,3"]) return @"iPhone 5c";
    
    if ([platform isEqualToString:@"iPhone5,4"]) return @"iPhone 5c";
    
    if ([platform isEqualToString:@"iPhone6,1"]) return @"iPhone 5s";
    
    if ([platform isEqualToString:@"iPhone6,2"]) return @"iPhone 5s";
    
    if ([platform isEqualToString:@"iPhone7,1"]) return @"iPhone 6 Plus";
    
    if ([platform isEqualToString:@"iPhone7,2"]) return @"iPhone 6";
    
    if ([platform isEqualToString:@"iPhone8,1"]) return @"iPhone 6s";
    
    if ([platform isEqualToString:@"iPhone8,2"]) return @"iPhone 6s Plus";
    
    if ([platform isEqualToString:@"iPhone8,4"]) return @"iPhone SE";
    
    if ([platform isEqualToString:@"iPhone9,1"]) return @"iPhone 7";
    
    if ([platform isEqualToString:@"iPhone9,2"]) return @"iPhone 7 Plus";
    
    if ([platform isEqualToString:@"iPod1,1"])   return @"iPod Touch 1G";
    
    if ([platform isEqualToString:@"iPod2,1"])   return @"iPod Touch 2G";
    
    if ([platform isEqualToString:@"iPod3,1"])   return @"iPod Touch 3G";
    
    if ([platform isEqualToString:@"iPod4,1"])   return @"iPod Touch 4G";
    
    if ([platform isEqualToString:@"iPod5,1"])   return @"iPod Touch 5G";
    
    if ([platform isEqualToString:@"iPad1,1"])   return @"iPad 1G";
    
    if ([platform isEqualToString:@"iPad2,1"])   return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,2"])   return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,3"])   return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,4"])   return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,5"])   return @"iPad Mini 1G";
    
    if ([platform isEqualToString:@"iPad2,6"])   return @"iPad Mini 1G";
    
    if ([platform isEqualToString:@"iPad2,7"])   return @"iPad Mini 1G";
    
    if ([platform isEqualToString:@"iPad3,1"])   return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,2"])   return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,3"])   return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,4"])   return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad3,5"])   return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad3,6"])   return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad4,1"])   return @"iPad Air";
    
    if ([platform isEqualToString:@"iPad4,2"])   return @"iPad Air";
    
    if ([platform isEqualToString:@"iPad4,3"])   return @"iPad Air";
    
    if ([platform isEqualToString:@"iPad4,4"])   return @"iPad Mini 2G";
    
    if ([platform isEqualToString:@"iPad4,5"])   return @"iPad Mini 2G";
    
    if ([platform isEqualToString:@"iPad4,6"])   return @"iPad Mini 2G";
    
    if ([platform isEqualToString:@"i386"])      return @"iPhone Simulator";
    
    if ([platform isEqualToString:@"x86_64"])    return @"iPhone Simulator";
    
    return platform;
    
}



@end
