//
//  UITextField+Category.h
//  MonkeyKing
//
//  Created by paimwin123 on 2018/3/15.
//  Copyright © 2018年 paimwin123. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (Category)

/**
 *  提示文字 和 颜色
 */
- (void)setPlaceholder:(NSString *)placeholder WithColor:(UIColor *)color;

@end
