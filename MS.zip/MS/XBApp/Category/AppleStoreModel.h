//
//  AppleStoreModel.h
//  KuMeiYouPin
//
//  Created by 陈一 on 2018/3/23.
//  Copyright © 2018年 chenyi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppleStoreModel : NSObject
@property(nonatomic,copy) NSString * version;


@property(nonatomic,copy)NSString *releaseNotes;

//更新时间
@property(nonatomic,copy)NSString *currentVersionReleaseDate;

//AppStore地址
@property(nonatomic,copy)NSString *trackViewUrl;

@property(nonatomic,assign)NSInteger ifUpdate;//是否需要强制更新(0:不需要,1:建议更新,2:强制更新)
@end
