//
//  WMProgressView.m
//  WMPageController
//
//  Created by Mark on 15/6/20.
//  Copyright (c) 2015年 yq. All rights reserved.
//

#import "WMProgressView.h"
@implementation WMProgressView {
    int                     sign;
    CGFloat                 gap;
    CGFloat                 step;
    __weak CADisplayLink    *_link;

}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];

    if (self) {
        _lineView = [[UIView alloc]init];
        _lineView.height = self.height;
        _lineView.left = 0;
        _lineView.top = 0;
        _progress = -1;
        _lineView.cornerRadius=self.height/2;
        [self addSubview:_lineView];
    }

    return self;
}

- (void)setColor:(CGColorRef)color {
    _color = color;
    _lineView.backgroundColor = [UIColor colorWithCGColor:self.color];
}

- (void)setProgress:(CGFloat)progress {
    _progress = progress;

    
    CGFloat width = [self.itemFrames[(int)progress] CGRectValue].size.width;
    
    CGFloat offsetX = 0;
    
    if (self.lineShowWidth>0) {
        _lineView.width = _lineShowWidth;
        offsetX =(width - _lineShowWidth)/2;
    }
    else
    {
        _lineView.width = [self.itemFrames[(int)progress] CGRectValue].size.width;
         offsetX =0;
    }
    

    if ((int)progress == progress) {
        [UIView animateWithDuration:0.2 delay:0 usingSpringWithDamping:1 initialSpringVelocity:0.5 options:UIViewAnimationOptionCurveEaseIn animations:^{
            _lineView.left = width * progress +offsetX ;
        } completion:^(BOOL finished) {
            _lineView.left = width * progress +offsetX;
        }];
    } else {
        _lineView.left = width * progress +offsetX;
    }
}

@end
