//
//  AdView.h
//  广告循环滚动效果
//
//  Created by QzydeMac on 14/12/24.
//  Copyright (c) 2014年 Qzy. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM (NSUInteger, UIPageControlShowStyle) {
    /**
     *  不显示PageControl
     */
    UIPageControlShowStyleNone,// default
    UIPageControlShowStyleLeft,
    UIPageControlShowStyleCenter,
    UIPageControlShowStyleRight,
};

typedef NS_ENUM (NSUInteger, AdTitleShowStyle) {
    /**
     *  不显示标题
     */
    AdTitleShowStyleNone,
    AdTitleShowStyleLeft,
    AdTitleShowStyleCenter,
    AdTitleShowStyleRight,
};

@interface AdView : UIView<UIScrollViewDelegate>

@property (assign, nonatomic) NSTimer                   *moveTimer;

@property (nonatomic, assign) CGFloat adMoveTime;

@property (retain, nonatomic, readonly) UIScrollView    *adScrollView;

@property (retain, nonatomic, readonly) UIPageControl   *pageControl;

@property (retain, nonatomic, readonly) NSArray         *imageLinkURL;

@property (retain, nonatomic, readonly) NSArray         *adTitleArray;

@property (assign, nonatomic) UIPageControlShowStyle PageControlShowStyle;

@property (assign, nonatomic, readonly) AdTitleShowStyle adTitleStyle;

@property (nonatomic, strong) UIImage *placeHoldImage;

@property (nonatomic, assign) BOOL isNeedCycleRoll;

@property (nonatomic, strong, readonly) UILabel *centerAdLabel;

#pragma mark   方法

- (void)click:(void (^)(NSInteger index, NSString *imageURL))block;

- (void)scroll:(void (^)(NSInteger index, NSString *imageURL))block;

- (void)setAdTitleArray:(NSArray *)adTitleArray withShowStyle:(AdTitleShowStyle)adTitleStyle;

- (void)setimageLinkURL:(NSArray *)imageLinkURL;

@end
