//
//  AdScrollView.m
//  广告循环滚动效果
//
//  Created by QzydeMac on 14/12/20.
//  Copyright (c) 2014年 Qzy. All rights reserved.
//

#import "AdView.h"
#import "UIImageView+WebCache.h"

@interface AdView ()

@property (nonatomic, assign) NSUInteger    centerImageIndex;
@property (nonatomic, assign) NSUInteger    leftImageIndex;
@property (nonatomic, assign) NSUInteger    rightImageIndex;

@property (retain, nonatomic, readonly) UIImageView *leftImageView;
@property (retain, nonatomic, readonly) UIImageView *centerImageView;
@property (retain, nonatomic, readonly) UIImageView *rightImageView;

@property (nonatomic, strong) void (^callBack)(NSInteger index, NSString *imageURL);
@property (nonatomic, strong) void (^scrollCallBack)(NSInteger index, NSString *imageURL);

@end

@implementation AdView

#pragma mark - 自由指定广告所占的frame
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        // 默认滚动式4.0s
        _adMoveTime = 4.0;
        _adScrollView = [[UIScrollView alloc]initWithFrame:self.bounds];
        _adScrollView.bounces = NO;
        _adScrollView.showsHorizontalScrollIndicator = NO;
        _adScrollView.showsVerticalScrollIndicator = NO;
        _adScrollView.pagingEnabled = YES;
        _adScrollView.contentOffset = CGPointMake(self.width, 0);
        _adScrollView.contentSize = CGSizeMake(self.width * 3, self.height);
        _adScrollView.delegate = self;
        // 该句是否执行会影响pageControl的位置,如果该应用上面有导航栏,就是用该句,否则注释掉即可
        _adScrollView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
        
        _leftImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.width, self.height)];
        _leftImageView.contentMode = UIViewContentModeScaleAspectFill;
        _leftImageView.clipsToBounds = YES;
        [_adScrollView addSubview:_leftImageView];
        
        _centerImageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.width, 0, self.width, self.height)];
        _centerImageView.contentMode = UIViewContentModeScaleAspectFill;
        _centerImageView.clipsToBounds = YES;
        _centerImageView.userInteractionEnabled = YES;
        
        [_centerImageView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)]];
        
        [_adScrollView addSubview:_centerImageView];
        
        _rightImageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.width * 2, 0, self.width, self.height)];
        _rightImageView.contentMode = UIViewContentModeScaleAspectFill;
        _rightImageView.clipsToBounds = YES;
        [_adScrollView addSubview:_rightImageView];
        
        _adScrollView.backgroundColor = [UIColor whiteColor];
        _isNeedCycleRoll = YES;
        [self addSubview:_adScrollView];
    }
    
    return self;
}


- (void)willMoveToSuperview:(UIView *)newSuperview {
    [super willMoveToSuperview:newSuperview];
    if (!newSuperview) {
        [self.moveTimer invalidate];
        self.moveTimer = nil;
    }
}

- (void)setUpTime {
    if (_isNeedCycleRoll) {
        [_moveTimer invalidate];
        _moveTimer = nil;
        _moveTimer = [NSTimer scheduledTimerWithTimeInterval:_adMoveTime target:self selector:@selector(animalMoveImage:) userInfo:nil repeats:YES];
    }
}

#pragma mark - 设置广告所使用的图片(名字)

- (void)setPlaceHoldImage:(UIImage *)placeHoldImage {
    _placeHoldImage = placeHoldImage;
    _leftImageView.image = _placeHoldImage;
    _centerImageView.image = _placeHoldImage;
    _rightImageView.image = _placeHoldImage;
}

- (void)setimageLinkURL:(NSArray *)imageLinkURL {
    _imageLinkURL = imageLinkURL;
    
    if (imageLinkURL.count == 0) {
        return;
    } else if (imageLinkURL.count == 1) {
        _rightImageIndex = 0;
    } else {
        _rightImageIndex = 1;
    }
    
    _leftImageIndex = imageLinkURL.count - 1;
    _centerImageIndex = 0;
    
    [_leftImageView sd_setImageWithURL:[NSURL URLWithString:imageLinkURL[_leftImageIndex]] placeholderImage:self.placeHoldImage];
    [_centerImageView sd_setImageWithURL:[NSURL URLWithString:imageLinkURL[_centerImageIndex]] placeholderImage:self.placeHoldImage];
    [_rightImageView sd_setImageWithURL:[NSURL URLWithString:imageLinkURL[_rightImageIndex]] placeholderImage:self.placeHoldImage];
    
    [self updatePageControl];
    
    [self setUpTime];
}

#pragma mark - 设置每个对应广告对应的广告语
- (void)setAdTitleArray:(NSArray *)adTitleArray withShowStyle:(AdTitleShowStyle)adTitleStyle {
    _adTitleArray = adTitleArray;
    
    if (adTitleStyle == AdTitleShowStyleNone) {
        return;
    }
    
    //上面的灰色遮罩
    UIView *vv = [[UIView alloc] initWithFrame:CGRectMake(0, self.height - 30, self.width, 30)];
    vv.backgroundColor = [UIColor blackColor];
    vv.alpha = 0.3;
    [self addSubview:vv];
    
    [self bringSubviewToFront:_pageControl];
    //上面的标题
    _centerAdLabel = [[UILabel alloc]init];
    _centerAdLabel.backgroundColor = [UIColor clearColor];
    _centerAdLabel.frame = CGRectMake(0, self.height - 30, self.width - 20, 30);
    _centerAdLabel.textColor = [UIColor lightGrayColor];
    _centerAdLabel.font = [UIFont boldSystemFontOfSize:15];
    [self addSubview:_centerAdLabel];
    
    if (adTitleStyle == AdTitleShowStyleLeft) {
        _centerAdLabel.textAlignment = NSTextAlignmentLeft;
    } else if (adTitleStyle == AdTitleShowStyleCenter) {
        _centerAdLabel.textAlignment = NSTextAlignmentCenter;
    } else {
        _centerAdLabel.textAlignment = NSTextAlignmentRight;
    }
    
    _centerAdLabel.text = _adTitleArray[_centerImageIndex];
}

#pragma mark - 创建pageControl,指定其显示样式
- (void)setPageControlShowStyle:(UIPageControlShowStyle)PageControlShowStyle {
    _PageControlShowStyle = PageControlShowStyle;
    
    if (PageControlShowStyle != UIPageControlShowStyleNone) {
        [self updatePageControl];
    }
}

- (void)updatePageControl {
    if (!_pageControl) {
        _pageControl = [[UIPageControl alloc]init];
    }
    
    _pageControl.numberOfPages = _imageLinkURL.count;
    
    if (_PageControlShowStyle == UIPageControlShowStyleLeft) {
        _pageControl.frame = CGRectMake(0, self.height - 20, 20 * _pageControl.numberOfPages, 20);
    } else if (_PageControlShowStyle == UIPageControlShowStyleCenter) {
        _pageControl.frame = CGRectMake(0, 0, 12 * _pageControl.numberOfPages + 10, 12);
        _pageControl.center = CGPointMake(self.width / 2.0, self.height - 18);
    } else {
        _pageControl.frame = CGRectMake(self.width - 20 * _pageControl.numberOfPages, self.height - 20, 20 * _pageControl.numberOfPages, 20);
    }
    
    _pageControl.currentPage = 0;
    
    _pageControl.enabled = NO;
    
    [self addSubview:_pageControl];
}

#pragma mark - 计时器到时,系统滚动图片
- (void)animalMoveImage:(NSTimer *)time {
    [_adScrollView setContentOffset:CGPointMake(self.width * 2, 0) animated:YES];
}

#pragma mark - delegate

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (_adScrollView.contentOffset.x == 0) {
        _centerImageIndex = _centerImageIndex - 1;
        _leftImageIndex = _leftImageIndex - 1;
        _rightImageIndex = _rightImageIndex - 1;
        
        if (_leftImageIndex == -1) {
            _leftImageIndex = _imageLinkURL.count - 1;
        }
        
        if (_centerImageIndex == -1) {
            _centerImageIndex = _imageLinkURL.count - 1;
        }
        
        if (_rightImageIndex == -1) {
            _rightImageIndex = _imageLinkURL.count - 1;
        }
        
        
    } else if (_adScrollView.contentOffset.x == self.width * 2) {
        _centerImageIndex = _centerImageIndex + 1;
        _leftImageIndex = _leftImageIndex + 1;
        _rightImageIndex = _rightImageIndex + 1;
        
        if (_leftImageIndex == _imageLinkURL.count) {
            _leftImageIndex = 0;
        }
        
        if (_centerImageIndex == _imageLinkURL.count) {
            _centerImageIndex = 0;
        }
        
        if (_rightImageIndex == _imageLinkURL.count) {
            _rightImageIndex = 0;
        }
    } else {
        return;
    }
    
    [_leftImageView sd_setImageWithURL:[NSURL URLWithString:_imageLinkURL[_leftImageIndex]] placeholderImage:self.placeHoldImage];
    
    [_centerImageView sd_setImageWithURL:[NSURL URLWithString:_imageLinkURL[_centerImageIndex]] placeholderImage:self.placeHoldImage];
    
    [_rightImageView sd_setImageWithURL:[NSURL URLWithString:_imageLinkURL[_rightImageIndex]] placeholderImage:self.placeHoldImage];
    
    _pageControl.currentPage = _centerImageIndex;
    
    if (self.scrollCallBack) {
        self.scrollCallBack(_centerImageIndex, nil);
    }
    
    //有时候只有在右广告标签的时候才需要加载
    if (_adTitleArray) {
        if (_centerImageIndex <= _adTitleArray.count - 1) {
            _centerAdLabel.text = _adTitleArray[_centerImageIndex];
        }
    }
    
    _adScrollView.contentOffset = CGPointMake(self.width, 0);
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [_moveTimer setFireDate:[NSDate distantFuture]];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [_moveTimer setFireDate:[NSDate dateWithTimeIntervalSinceNow:_adMoveTime]];
}


#pragma mark  - event

- (void)tap {
    if (_callBack) {
        _callBack(_centerImageIndex, _imageLinkURL[_centerImageIndex]);
    }
}

- (void)click:(void (^)(NSInteger index, NSString *imageURL))block {
    self.callBack = block;
}

-(void)scroll:(void (^)(NSInteger, NSString *))block
{
    self.scrollCallBack = block;
}

@end

