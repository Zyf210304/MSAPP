//  UIVerticalLoopView.m
//  Jovi
//
//  Created by yuzhuo on 2016/11/23.
//  Copyright © 2016年 dianping.com. All rights reserved.
//

#import "UIVerticalLoopView.h"

@implementation MTAVerticalLoopView
{
    BOOL _animating;
}

#pragma mark - lifecycle
- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];

    if (self) {
        [self setupView];
    }

    return self;
}

#pragma mark - private method
- (void)setupView {
    _firstContentLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    [_firstContentLabel setBackgroundColor:[UIColor clearColor]];
    [_firstContentLabel setNumberOfLines:0];
    _firstContentLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGesturRecongnizer1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loopContentClick)];
    tapGesturRecongnizer1.numberOfTapsRequired = 1;
    [_firstContentLabel addGestureRecognizer:tapGesturRecongnizer1];

    _firstContentLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [_firstContentLabel setTextColor:[UIColor colorHex:@"#666666"]];
    _firstContentLabel.font = [UIFont boldSystemFontOfSize:12.f];

    _secondContentLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, self.frame.size.height, self.frame.size.width , self.frame.size.height)];
    [_secondContentLabel setBackgroundColor:[UIColor clearColor]];
    [_secondContentLabel setTextColor:[UIColor colorHex:@"#666666"]];
    _secondContentLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    [_secondContentLabel setNumberOfLines:0];
    _secondContentLabel.userInteractionEnabled = YES;
    _secondContentLabel.font = [UIFont boldSystemFontOfSize:12.f];

    UITapGestureRecognizer *tapGesturRecongnizer2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loopContentClick)];
    tapGesturRecongnizer2.numberOfTapsRequired = 1;
    [_secondContentLabel addGestureRecognizer:tapGesturRecongnizer2];

    [self addSubview:_firstContentLabel];
    [self addSubview:_secondContentLabel];

    // 默认初始方向是向上
    _Direction = VerticalLoopDirectionDown;
    _verticalLoopAnimationDuration = 0.5;
    self.clipsToBounds = YES;
}

- (void)startVerticalLoopAnimation {
    NSArray<NSString *> *data = [self.data copy];

    if (currentIndex >= data.count) {
        [self verticalLoopAnimationDidStop:nil finished:nil context:nil];
        return;
    }

    NSString *firstAd = [data objectAtIndex:currentIndex];

    // 赋值给显示控件label01的 attributedText
    _firstContentLabel.text = firstAd;
    [_firstContentLabel setNeedsDisplay];

    float   firstContentLaStartY = 0;
    float   firstContentLaEndY = 0;
    float   secondContentLaStartY = 0;
    float   secondContentLaEndY = 0;

    int secondCurrentIndex = currentIndex + 1;

    if (secondCurrentIndex > data.count - 1) {
        secondCurrentIndex = 0;
    }

    switch (_Direction) {
        case VerticalLoopDirectionBottom:

            firstContentLaStartY = 0;
            firstContentLaEndY = self.frame.size.height;

            secondContentLaStartY = firstContentLaStartY - self.frame.size.height;
            secondContentLaEndY = firstContentLaEndY - self.frame.size.height;

            break;

        case VerticalLoopDirectionDown:

            firstContentLaStartY = 0;
            firstContentLaEndY = -self.frame.size.height;

            secondContentLaStartY = firstContentLaStartY + self.frame.size.height;
            secondContentLaEndY = firstContentLaEndY + self.frame.size.height;

            break;

        default:
            break;
    }

    NSString *secondAd = [data objectAtIndex:secondCurrentIndex];

    _secondContentLabel.text = secondAd;
    [_secondContentLabel setNeedsDisplay];

    _firstContentLabel.frame = CGRectMake(0, firstContentLaStartY, self.frame.size.width , self.frame.size.height);
    _secondContentLabel.frame = CGRectMake(0, secondContentLaStartY, self.frame.size.width , self.frame.size.height);

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(00 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self didAnimation:firstContentLaEndY secondContent:secondContentLaEndY];
    });
}

- (void)verticalLoopAnimationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context {
    currentIndex++;

    if (currentIndex >= [self.data count]) {
        currentIndex = 0;
    }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self startVerticalLoopAnimation];
    });
}

- (void)loopContentClick {
    if ([self.loopDelegate respondsToSelector:@selector(didClickContentAtIndex:)]) {
        [self.loopDelegate didClickContentAtIndex:currentIndex];
    }
}

#pragma mark - verticalLoop Animation Handling
- (void)start {
    // 开启动画默认第一条信息
    currentIndex = 0;

    // 开始动画
    if (!_animating) {
        _animating = YES;
        [self performSelectorOnMainThread:@selector(startVerticalLoopAnimation) withObject:nil waitUntilDone:NO];
        //        [self startVerticalLoopAnimation];
    }
}

- (void)didAnimation:(float)firstContentLaEndY secondContent:(float)secondContentLaEndY {
    if ([self.data count] > 1) {
        [UIView beginAnimations:@"" context:nil];
        [UIView setAnimationCurve:UIViewAnimationCurveLinear];
        [UIView setAnimationDuration:_verticalLoopAnimationDuration];
        [UIView setAnimationDelay:5];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(verticalLoopAnimationDidStop:finished:context:)];
        CGRect firstContentLabelFrame = _firstContentLabel.frame;
        firstContentLabelFrame.origin.y = firstContentLaEndY;

        [_firstContentLabel setFrame:firstContentLabelFrame];
        [_secondContentLabel setFrame:CGRectMake(0, secondContentLaEndY, self.frame.size.width, self.frame.size.height)];

        [UIView commitAnimations];
    } else {
        _animating = NO;
    }
}

@end
