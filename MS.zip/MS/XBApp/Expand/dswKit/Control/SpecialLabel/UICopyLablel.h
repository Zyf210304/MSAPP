//
//  UICopyLablel.h
//  qtyd
//
//  Created by stephendsw on 15/8/20.
//  Copyright (c) 2015年 qtyd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UICopyLablel : UILabel

@end
