//
//  ToastView.h
//  XBApp
//
//  Created by stephen on 2018/5/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ToastView : UIView

/**
 *  优先级
 *
 */
@property (nonatomic , assign ) NSInteger priority;


-(BOOL)showInView:(UIView *)view;

@end
