//
//  ToastView.m
//  XBApp
//
//  Created by stephen on 2018/5/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "ToastView.h"

@implementation ToastView

-(BOOL)showInView:(UIView *)view_{
    
    BOOL hasToast = NO;
    
    for (UIView * view  in view_.subviews) {
        if ([view isKindOfClass:[ToastView class]]   ) {
            hasToast=YES;
            
            ToastView * newView= (ToastView *) view ;
            
            if (self.priority > newView.priority) {
                [newView removeFromSuperview];
                [view_ addSubview:self];
                return YES;
            }
        }
    }
    
    if (!hasToast) {
         [view_ addSubview:self];
         return YES;
    }
    
    return false;
    
}

@end
