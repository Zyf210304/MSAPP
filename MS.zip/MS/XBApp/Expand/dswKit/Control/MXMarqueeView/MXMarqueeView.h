//
//  MXMarqueeView.h
//  MXMarqueeViewDemo
//
//  Created by Long on 12-9-24.
//  Copyright (c) 2012年 Long. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (MXMarqueeView)

- (void)startAnimation;

@end
