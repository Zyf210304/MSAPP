//
//  MXMarqueeView.m
//  MXMarqueeViewDemo
//
//  Created by Long on 12-9-24.
//  Copyright (c) 2012年 Long. All rights reserved.
//

#import "MXMarqueeView.h"

@implementation UILabel (MXMarqueeView)

- (void)startAnimation
{
    
    CABasicAnimation *anima = [CABasicAnimation animationWithKeyPath:@"transform.translation.x"];
    anima.fromValue = @(-self.width);
    anima.toValue = @(APP_WIDTH);
    anima.duration =5.0f;
    anima.fillMode = kCAFillModeForwards;
    anima.repeatCount = HUGE_VALF;
    [self.layer addAnimation:anima forKey:@"positionAnimation"];
    
}

@end
