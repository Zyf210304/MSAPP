//
//  WTReTextField.m
//  WTReTextField
//
//  Created by Alex Skalozub on 5/5/13.
//  Copyright (c) 2013 Alex Skalozub.
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
//  to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
//  and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
//  IN THE SOFTWARE.
//

#import "WTReTextField.h"
#import "WTReParser.h"

@implementation WTReTextField

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];

    if (self) {
        _lastAcceptedValue = nil;
        _parser = nil;
        [self addTarget:self action:@selector(formatInput:) forControlEvents:UIControlEventEditingChanged];
    }

    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];

    if (self) {
        _lastAcceptedValue = nil;
        _parser = nil;
        [self addTarget:self action:@selector(formatInput:) forControlEvents:UIControlEventEditingChanged];
    }

    return self;
}

- (void)dealloc {
    _lastAcceptedValue = nil;
    _parser = nil;
    [self removeTarget:self action:@selector(formatInput:) forControlEvents:UIControlEventEditingChanged];
}

- (void)setPattern:(NSString *)pattern {
    if ((pattern == nil) || [pattern isEqualToString:@""]) {
        _parser = nil;
    } else {
        _parser = [[WTReParser alloc] initWithPattern:pattern];
    }
}

- (NSString *)pattern {
    return _parser.pattern;
}

- (void)formatInput:(UITextField *)textField {
    if (_parser == nil) {
        return;
    }

    WTReParser *localParser = _parser;

    NSString *formatted = [localParser reformatString:textField.text];

    if (formatted == nil) {
        formatted = _lastAcceptedValue;
    } else {
        _lastAcceptedValue = formatted;
    }

    NSString *newText = formatted;

    if (![textField.text isEqualToString:newText]) {
        textField.text = formatted;
        [self sendActionsForControlEvents:UIControlEventValueChanged];
    }
}

- (void)editChangeEvent {
    [self performSelector:@selector(editChangeAction:) withObject:nil];
}

@end
