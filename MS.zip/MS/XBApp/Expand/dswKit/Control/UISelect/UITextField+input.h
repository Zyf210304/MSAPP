//
//  UITextField+input.h
//  Car_ZJ
//
//  Created by stephen on 15/4/15.
//  Copyright (c) 2015年 qtyd. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UITextField (input)<UIPickerViewDataSource, UIPickerViewDelegate>

/**
 *  输入时间
 */
- (void)setInputTime;

/**
 *  输入时间 format
 */
- (void)setInputTime:(NSString *)format;

/**
 *  选择输入
 */
- (void)setInputDropList:(NSArray *)data;

/**
 *  自定义图片
 */
- (void)setRightImage:(NSString *)imageName;

/**
 *  自定义图片
 */
- (void)setLeftImage:(NSString *)imageName;

-(void)setRightText:(NSString *)text;

-(void)setLeftLabel:(UILabel *)label;

@end
