//
//  DSWKit.h
//  test
//
//  Created by stephen on 15/3/5.
//  Copyright (c) 2015年 dsw. All rights reserved.
//


#define NoticePostNetworkError  @"notNetwork"

#define  EPS                    1e-7

typedef void (^ Action)(void);

////// Foundation

#import "NSObject+quick.h"
#import "NSArray+Linq.h"
#import "NSDictionary+quick.h"
#import "NSMutableAttributedString+quick.h"

#import "NSTimer+block.h"
#import "NSDate+RMCalendarLogic.h"
#import "NSObject+KVO.h"
#import "NSDateFormatter+quick.h"

#import "NSString+regularExpression.h"
#import "NSString+Encry.h"
#import "NSString+quick.h"
#import "NSString+URL.h"
#import "Map.h"

////// UI

#import "UIControl+BlockEvent.h"
#import "UIControl+Property.h"
#import "UIView+quick.h"
#import "UIAlertView+quick.h"
#import "UIImage+other.h"
#import "UIColor+hexColor.h"
#import "UIViewController+xib.h"
#import "UIViewController+toast.h"
#import "DTableViewCell.h"
#import "UIImageView+webImage.h"
#import "UIText+Text.h"
#import "CALayer+quick.h"
#import "UINavigationController+quick.h"
#import "UIBarButtonItem+quick.h"
#import "UIPageControl+page.h"
#import "UILabel+padding.h"
#import "UIWebView+autoHeight.h"

#import "DGridView.h"
#import "DStackView.h"
#import "DWrapView.h"

////// Tool

#import "IPHelper.h"
#import "AppUtil.h"
#import "DSandBox.h"
#import "DDebug.h"

