//
//  UIViewController+BackButtonHandler.m
//  qtyd
//
//  Created by stephendsw on 15/8/21.
//  Copyright (c) 2015年 qtyd. All rights reserved.
//

#import "UIViewController+BackButtonHandler.h"
#import <objc/runtime.h>

@implementation UIViewController (BackButtonHandler)

- (BOOL)navigationShouldPopOnBackButton {
    return YES;
}

#pragma mark - navigationItem


- (void)setRightBarTitle:(NSString *)title block:(Action)block_ {
    UIBarButtonItem *itembar = [[UIBarButtonItem alloc]initWithTitle:title style:UIBarButtonItemStyleDone target:self action:@selector(rightBarTitleClick)];
    
    self.navigationItem.rightBarButtonItem = itembar;
    
    objc_setAssociatedObject(self, @selector(rightBarTitleClick),block_, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void)setRightBarImage:(UIImage *)image block:(Action)block_ {
    
    UIBarButtonItem * item = [[UIBarButtonItem alloc]initWithImage:[image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStyleDone target:self  action:@selector(rightBarTitleClick)];
    
    self.navigationItem.rightBarButtonItem = item;
    
    objc_setAssociatedObject(self, @selector(rightBarTitleClick),block_, OBJC_ASSOCIATION_COPY_NONATOMIC);
    
    
}

- (void)setLeftBarTitle:(NSString *)title block:(Action)block_ {
    UIBarButtonItem *itembar = [[UIBarButtonItem alloc]initWithTitle:title style:UIBarButtonItemStyleDone target:self action:@selector(leftBarTitleClick)];
    
    self.navigationItem.leftBarButtonItem = itembar;
    
    objc_setAssociatedObject(self, @selector(leftBarTitleClick),block_, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void)setLeftBarImage:(UIImage *)image block:(Action)block_ {
    UIBarButtonItem *itembar = [[UIBarButtonItem alloc]initWithImage:[image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStyleDone target:self action:@selector(leftBarTitleClick)];
    
    self.navigationItem.leftBarButtonItem = itembar;
    
    objc_setAssociatedObject(self, @selector(leftBarTitleClick), block_, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void)leftBarTitleClick {
    Action block= objc_getAssociatedObject(self, _cmd);
    block();
}


- (void)rightBarTitleClick {
    Action block= objc_getAssociatedObject(self, _cmd);
    block();
}




@end

@implementation UINavigationController (ShouldPopOnBackButton)

- (BOOL)navigationBar:(UINavigationBar *)navigationBar shouldPopItem:(UINavigationItem *)item {
    if ([self.viewControllers count] < [navigationBar.items count]) {
        return YES;
    }
    
    BOOL shouldPop = YES;
    
    UIViewController *vc = [self topViewController];
    
    if ([vc respondsToSelector:@selector(navigationShouldPopOnBackButton)]) {
        shouldPop = [vc navigationShouldPopOnBackButton];
    }
    
    if (shouldPop) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self popViewControllerAnimated:YES];
        });
    } else {
        // Workaround for iOS7.1. Thanks to @boliva - http://stackoverflow.com/posts/comments/34452906
        
        for (UIView *subview in [navigationBar subviews]) {
            if (subview.alpha < 1.) {
                [UIView animateWithDuration:.25 animations:^{
                    subview.alpha = 1.;
                }];
            }
        }
    }
    
    return NO;
}

@end
