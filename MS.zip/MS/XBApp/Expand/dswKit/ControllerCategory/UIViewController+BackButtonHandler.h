//
//  UIViewController+BackButtonHandler.h
//  qtyd
//
//  Created by stephendsw on 15/8/21.
//  Copyright (c) 2015年 qtyd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (BackButtonHandler)<UINavigationControllerDelegate>

- (BOOL)navigationShouldPopOnBackButton;

- (void)setLeftBarTitle:(NSString *)title block:(Action)block_;
- (void)setLeftBarImage:(UIImage *)image block:(Action)block_;

- (void)setRightBarTitle:(NSString *)title block:(Action)block_;
- (void)setRightBarImage:(UIImage *)image block:(Action)block_;

@end
