//
//  UIViewController+xib.h
//  test
//
//  Created by stephen on 15/3/5.
//  Copyright (c) 2015年 dsw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (xib)


@property (nonatomic ,readonly) CGFloat  navegationBarHeight;

@property (nonatomic ,readonly) CGFloat  tabBarHeight;

@property (nonatomic ,readonly) CGFloat  contentHeight;

+ (instancetype)controllerFromXib;

+ (instancetype)storyboard:(NSString *)name viewid:(NSString *)key;



@end
