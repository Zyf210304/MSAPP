//
//  UIViewController+qiuck.m
//  test
//
//  Created by stephen on 15/3/5.
//  Copyright (c) 2015年 dsw. All rights reserved.
//

#import "UIViewController+xib.h"

@implementation UIViewController (xib)

+ (instancetype)controllerFromXib {
    NSString *name = [[self class] className];

    NSString *nameiPhone = [NSString stringWithFormat:@"%@~iphone", name];

    NSString    *path = [[NSBundle mainBundle] pathForResource:name ofType:@"nib"];
    NSString    *pathiPhone = [[NSBundle mainBundle] pathForResource:nameiPhone ofType:@"nib"];

    NSFileManager *fileManger = [NSFileManager defaultManager];

    if ([fileManger fileExistsAtPath:path] || [fileManger fileExistsAtPath:pathiPhone]) {
        return [[self alloc]initWithNibName:name bundle:nil];
    } else {
        return [[self alloc]init];
    }
}

+ (instancetype)storyboard:(NSString *)name viewid:(NSString *)key {
    UIStoryboard *stroryboard = [UIStoryboard storyboardWithName:name bundle:nil];

    return [stroryboard instantiateViewControllerWithIdentifier:key];
}

- (CGFloat)navegationBarHeight
{
    if (self.navigationController) {
        return APP_NAVIGATION_BAR_HEIGHT;
    }
    else
    {
        return 0;
    }
}

- (CGFloat)tabBarHeight
{
    if (self.tabBarController) {
        return APP_TAB_BAR_BAR_HEIGHT;
    }
    else
    {
        return 0;
    }
}

-(CGFloat)contentHeight
{
    return  APP_HEIGHT - self.tabBarHeight- self.navegationBarHeight;
}


@end
