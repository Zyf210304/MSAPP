//
//  UIPageControl+page.m
//  XBApp
//
//  Created by stephen on 2018/2/28.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "UIPageControl+page.h"

@implementation UIPageControl (page)

-(void)bindScrollView:(UIScrollView *)scrollview{
    
    scrollview.pagingEnabled=YES;
    
    [self bindKeyPath:@"contentSize" object:scrollview block:^(id newObj) {
        
        NSInteger allPage= scrollview.contentSize.width / scrollview.width;
        self.numberOfPages=allPage;
        
        if (allPage>1) {
            self.hidden=NO;
        }
        else{
            self.hidden=YES;
        }
        
    }];
    
    [self bindKeyPath:@"contentOffset" object:scrollview block:^(id newObj) {
        
        NSInteger allPage= scrollview.contentSize.width / scrollview.width;
        
        NSInteger currentPage =  scrollview.contentOffset.x / scrollview.width;
        if (currentPage>(allPage-1)) {
            currentPage=(allPage-1);
        }
        if (currentPage<0) {
            currentPage=0;
        }
        
        self.currentPage = currentPage;
    }];

}

@end
