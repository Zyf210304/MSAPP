//
//  UIControl+Property.h
//  qtyd
//
//  Created by stephendsw on 16/1/26.
//  Copyright © 2016年 qtyd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIControl (Property)

@property (nonatomic, assign) BOOL showBackgroundColorHighlighted;

- (void)willTouch;

- (void)didTouch;

@end
