//
//  UIBarButtonItem+quick.h
//  XBApp
//
//  Created by stephen on 2018/2/2.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (quick)

@property (nonatomic, strong) UIFont *font;

@property (nonatomic, strong) UIColor *textColor;

@end

@interface UITabBarItem (quick)

-(void)setTextColor:(UIColor *)textColor forState:(UIControlState )state;

-(void)setFont:(UIFont *)font forState:(UIControlState)state;

@end

@interface UINavigationBar (quick)

@property (nonatomic, strong) UIFont *font;

@property (nonatomic, strong) UIColor *textColor;

@end







