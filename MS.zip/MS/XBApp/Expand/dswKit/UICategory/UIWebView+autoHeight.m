//
//  UIWebView+autoHeight.m
//  XBApp
//
//  Created by stephen on 2018/5/2.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "UIWebView+autoHeight.h"

@implementation UIWebView (autoHeight)

-(void)loadHTMLString:(NSString *)string block:(bindingBlock)block
{
    
    self.scrollView.showsVerticalScrollIndicator=NO;
    self.scrollView.showsHorizontalScrollIndicator=NO;
    self.scrollView.scrollEnabled=NO;
    
    [self stringByEvaluatingJavaScriptFromString:@"document.body.innerHTML='';"];
    self.scrollView.subviews.firstObject.height=0;

    [self bindKeyPath:@"contentSize" object:self.scrollView block:^(id newObj) {
        self.height= self.scrollView.contentSize.height;
        block(newObj);
    }];
    
    self.height= arc4random() % 100 + 50;
    
    [self loadHTMLString:string baseURL:nil];
    
}

@end
