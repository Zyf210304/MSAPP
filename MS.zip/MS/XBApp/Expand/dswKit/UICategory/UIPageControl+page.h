//
//  UIPageControl+page.h
//  XBApp
//
//  Created by stephen on 2018/2/28.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIPageControl (page)

-(void)bindScrollView:(UIScrollView *)scrollview;

@end
