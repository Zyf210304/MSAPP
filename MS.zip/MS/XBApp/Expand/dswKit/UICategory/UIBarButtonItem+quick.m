//
//  UIBarButtonItem+quick.m
//  XBApp
//
//  Created by stephen on 2018/2/2.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "UIBarButtonItem+quick.h"

@implementation UIBarButtonItem (quick)

-(void)setTextColor:(UIColor *)textColor
{
    
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    
    if ([self titleTextAttributesForState:UIControlStateNormal]) {
        [dic addEntriesFromDictionary : [self titleTextAttributesForState:UIControlStateNormal]];
    }
    
    dic[NSForegroundColorAttributeName]=textColor;
    
    [self setTitleTextAttributes:dic forState:UIControlStateNormal];
    [self setTitleTextAttributes:dic forState:UIControlStateSelected];
    [self setTitleTextAttributes:dic forState:UIControlStateHighlighted];
}

-(UIColor *)textColor
{
    return  [self titleTextAttributesForState:UIControlStateNormal][NSForegroundColorAttributeName];
}

-(void)setFont:(UIFont *)font
{
    
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    
    if ([self titleTextAttributesForState:UIControlStateNormal]) {
        [dic addEntriesFromDictionary : [self titleTextAttributesForState:UIControlStateNormal]];
    }
    
    dic[NSFontAttributeName]=font;
    
    [self setTitleTextAttributes:dic forState:UIControlStateNormal];
    [self setTitleTextAttributes:dic forState:UIControlStateSelected];
    [self setTitleTextAttributes:dic forState:UIControlStateHighlighted];
    
}

-(UIFont *)font
{
    return  [self titleTextAttributesForState:UIControlStateNormal][NSFontAttributeName];
}

@end

@implementation UITabBarItem (quick)

-(void)setTextColor:(UIColor *)textColor forState:(UIControlState)state
{
    [self setTitleTextAttributes:@{NSForegroundColorAttributeName:textColor} forState:state];
}

-(void)setFont:(UIFont *)font forState:(UIControlState)state
{
    [self setTitleTextAttributes:@{NSFontAttributeName:font} forState:state];
}

@end


@implementation UINavigationBar (quick)

-(void)setTextColor:(UIColor *)textColor
{
    [self setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:textColor,NSForegroundColorAttributeName, nil]];
}

-(UIColor *)textColor
{
    return self.titleTextAttributes[NSForegroundColorAttributeName];
}

-(void)setFont:(UIFont *)font
{
    [self setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil]];
}
-(UIFont *)font
{
    return self.titleTextAttributes[NSFontAttributeName];
}

@end
