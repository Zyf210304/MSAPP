//
//  UIWebView+autoHeight.h
//  XBApp
//
//  Created by stephen on 2018/5/2.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWebView (autoHeight)

-(void)loadHTMLString:(NSString *)string  block:(bindingBlock)block;

@end
