//
//  UILabel+padding.h
//  XBApp
//
//  Created by stephen on 2018/3/21.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE @interface UILabel (padding)

/**
 修改label内容距 `top` `left` `bottom` `right` 边距
 */
@property (nonatomic, assign) IBInspectable UIEdgeInsets yf_contentInsets;

@end
