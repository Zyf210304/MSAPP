//
//  DXibView.h
//  qtyd
//
//  Created by stephendsw on 2016/11/15.
//  Copyright © 2016年 qtyd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DXibView : UIView

@property (nonatomic , strong ) IBOutlet UIView * contentView;

@end
