//
//  UIScrollView+contentSize.swift
//  changfu
//
//  Created by stephen on 2017/9/12.
//  Copyright © 2017年 changfulicai. All rights reserved.
//

import Foundation
import UIKit

extension UIScrollView{
    
    func autoContentSize() {
        var maxy: CGFloat = 0
        for item: UIView in subviews {
            if (item is UIImageView) {
                continue
            }
            if item.height + item.top > maxy {
                maxy = item.height + item.top
            }
        }
        contentSize = CGSize(width: 0, height: maxy)
    }
    
}
