//
//  BaseViewController.m
//  qtyd
//
//  Created by stephendsw on 15/8/17.
//  Copyright (c) 2015年 qtyd. All rights reserved.
//

#import "BaseViewController.h"
#import "AppUtil.h"

@interface BaseViewController ()

@end

@implementation BaseViewController
{
    UIView          *topview;
    UIView          *bottomView;
    UIEdgeInsets    bottomEdge;

    UIView *centerView;

}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.automaticallyAdjustsScrollViewInsets = NO;
    self.edgesForExtendedLayout = UIRectEdgeNone;
}

#pragma  mark - layout
- (void)addHeadView:(UIView *)view {
    topview = view;
    [self.view addSubview:topview];
}

- (void)addBottomView:(UIView *)view {
    bottomView = view;
    [self.view addSubview:bottomView];
}

- (void)addBottomView:(UIView *)view padding:(UIEdgeInsets)edge {
    [self addBottomView:view];
    bottomEdge = edge;
}

- (void)removeBottomView {
    [bottomView removeFromSuperview];
    bottomView = nil;
}

- (void)addCenterView:(UIView *)view {
    centerView = view;
    [self.view addSubview:centerView];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    // ================= has other
    float   top = 0;
    float   cH = 0;

    // top
    if (topview) {
        topview.frame = CGRectMake(0, 0, self.view.width, topview.height);
    }

    // center
    if (centerView) {
        if (topview) {
            top = topview.bottom;
        } else {
            top = 0;
        }

        cH = self.view.height - top - bottomView.height - bottomEdge.top - bottomEdge.bottom;

        centerView.frame = CGRectMake(0, top, self.view.width, cH);
    }

    // bottom
    if (bottomView) {
        bottomView.width = self.view.width - bottomEdge.left - bottomEdge.right;
        bottomView.height = bottomView.height;
        bottomView.left = bottomEdge.left;
        bottomView.bottom = self.view.height - bottomEdge.bottom;
    }
}

@end
