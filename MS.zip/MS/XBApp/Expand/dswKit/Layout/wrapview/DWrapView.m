//
//  DWrapView.m
//  test
//
//  Created by stephen on 15/2/28.
//  Copyright (c) 2015年 dsw. All rights reserved.
//

#import "DWrapView.h"

@implementation DWrapView
{
    NSInteger   columns;
    BOOL        isAvgWidth;
}

- (void)willMoveToSuperview:(UIView *)newSuperview {
    [self setNeedsLayout];
    [self layoutIfNeeded];
}

-(instancetype)initWidth:(CGFloat)width
{
    self = [super initWidth:width];
    
    if (self) {
        self.showLine=YES;
    }
    
    return self;
}

- (instancetype)initWidth:(CGFloat)width columns:(NSInteger)column {
    self = [super initWidth:width];

    if (self) {
        self.showLine=YES;
        columns = column;
        isAvgWidth = YES;
    }

    return self;
}

- (void)setColumn:(NSInteger)num {
    columns = num;
    isAvgWidth = YES;
}

- (CGFloat)getAvgItemWidth:(NSInteger)num {
    return (self.width - self.offsetX * 2) / num;
}

- (void)addView:(UIView *)view {
    [self addView:view margin:UIEdgeInsetsZero];
}

- (void)addView:(UIView *)view padding:(UIEdgeInsets)padding {
    [self addView:view margin:UIEdgeInsetsZero padding:padding];
}

- (void)addView:(UIView *)view margin:(UIEdgeInsets)edge {
    [self addView:view margin:edge padding:UIEdgeInsetsZero];
}

- (void)addView:(UIView *)view margin:(UIEdgeInsets)edge padding:(UIEdgeInsets)padding {
    if (view == self) {
        return;
    }

    view.padding = padding;
    view.margin = edge;

    if (![self.subviews containsObject:view]) {
        [self addSubview:view];
        [self _addView:view margin:view.margin padding:view.padding];
    }
}

#pragma  mark  update

- (void)_addView:(UIView *)view margin:(UIEdgeInsets)margin padding:(UIEdgeInsets)padding {
    if ([view isKindOfClass:[self class]]) {
        [view setNeedsLayout];
        [view layoutIfNeeded];
    }

    if (self.subHeight == 0) {
        self.subHeight = 90;
    }

    CGRect  rect = view.frame;
    CGFloat viewWidth;

    if (isAvgWidth) {
        viewWidth = [self getAvgItemWidth:columns];
    } else {
        viewWidth = view.width;
    }

    rect.size.width = viewWidth;
    rect.size.height = self.subHeight;

    if ([view isKindOfClass:[UILabel class]]) {
        UILabel *label = (UILabel *)view;
        label.lineBreakMode = NSLineBreakByTruncatingTail;
        label.numberOfLines = 0;
        [label autoHeight];

        rect.size.height = label.height;
    }

    rect.origin = CGPointMake(0, 0);
    
    rect.size =CGSizeMake(viewWidth - margin.left -margin.right , rect.size.height - margin.top -margin.bottom );
    
    if (frontView && (frontView.right + viewWidth < self.width + 1)) {
        // 插入当前行
       
        rect.origin.x = frontView.right+frontView.margin.right+frontView.padding.right+ view.padding.left +view.margin.left  ;
        
        rect.origin.y = frontView.origin.y - frontView.margin.top - frontView.padding.top + view.padding.top+ view.margin.top ;
        
    } else {
        // 插入新行
        rect.origin.x = self.offsetX +view.padding.left+view.margin.left ;
        rect.origin.y = frontView.bottom +frontView.margin.bottom+ frontView.padding.bottom + view.padding.top+ view.margin.top ;
    }
   
    view.frame = rect;
    frontView = view;
    
    if (view.bottom + margin.bottom + padding.bottom > self.height) {
        self.height=view.bottom + margin.bottom + padding.bottom;
    }
}

- (void)updateView {
    NSArray<UIView *> *subviews = self.subviews;
    frontView = nil;
    self.height=0;
    for (UIView *item in subviews) {
        [self _addView:item margin:item.margin padding:item.padding];
    }
}

@end
