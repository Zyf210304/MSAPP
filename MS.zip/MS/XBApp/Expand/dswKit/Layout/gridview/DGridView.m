//
//  FlowView.m
//  test
//
//  Created by stephen on 15/2/12.
//  Copyright (c) 2015年 dsw. All rights reserved.
//

#import "DGridView.h"
#import <objc/runtime.h>
#import "NSObject+quick.h"

#import "DWrapView.h"


@implementation UIView (Row)

- (BOOL)showLine {
    return [objc_getAssociatedObject(self, _cmd) boolValue];
}

- (void)setShowLine:(BOOL)showLine{
    objc_setAssociatedObject(self, @selector(showLine), @(showLine), OBJC_ASSOCIATION_COPY_NONATOMIC);
}

@end

#pragma mark - grid

@implementation DGridView
{
    NSMutableArray *lineList;
}
@synthesize rowHeight;

- (void)setColumn:(NSInteger)s height:(NSInteger)h {
    lineList = [NSMutableArray new];
    self.lineColor = [UIColor colorHex:@"e6e6e6" alpha:0.5];
    self.isShowLine = YES;
    column = s;
    rowHeight = h;
    self.offsetX = 15;
}

- (NSArray<UIView *> *)showRowList {
    NSMutableArray<UIView *> *showRowList = [NSMutableArray new];
    
    for (UIView *item in self.subviews) {
        if (!item.hidden) {
            [showRowList addObject:item];
        }
    }
    
    return showRowList;
}

#pragma mark  add

- (void)addRowView:(UIView *)view {
    [self addView:view crossColumn:column];
}

- (void)addView:(UIView *)view {
    [self addView:view crossColumn:1];
}

- (void)addView:(UIView *)view crossColumn:(CGFloat)num {
    [self addView:view crossColumn:num margin:UIEdgeInsetsZero];
}

- (void)addView:(UIView *)view crossColumn:(CGFloat)num margin:(UIEdgeInsets)margin {
    [self addView:view crossColumn:num margin:margin padding:UIEdgeInsetsZero];
}

- (void)addView:(UIView *)view crossColumn:(CGFloat)num padding:(UIEdgeInsets)padding {
    [self addView:view crossColumn:num margin:UIEdgeInsetsZero padding:padding];
}

- (void)addView:(UIView *)view crossColumn:(CGFloat)num margin:(UIEdgeInsets)margin padding:(UIEdgeInsets)padding {
    // 异常
    NSAssert(column > 0, @"Column 列数不得为0");
    
    if (view == self) {
        return;
    }
    
    CGFloat itemWidth = (self.width - self.offsetX * 2 - 1) / column;
    view.width = itemWidth * num;
    
    BOOL hasLast = NO;
    
    
    
    // warp item 未满格
    if (frontView  &&  [frontView isKindOfClass:[DWrapView class]] ) {
        //允许误差10
        
        UIView * lastView=frontView.subviews.lastObject;
        
        if ( lastView.right +  view.width < frontView.width  + 10 ) {
            hasLast = YES;
        }
    }
    
    if ([view isKindOfClass:[UILabel class]] && UIEdgeInsetsEqualToEdgeInsets(padding, UIEdgeInsetsZero)) {
        CGFloat offsetTopBottom = (self.rowHeight - ((UILabel *)view).font.pointSize -3) / 2;
        
        padding = UIEdgeInsetsMake(offsetTopBottom, 0, offsetTopBottom, 0);
    }
    
    if (hasLast) {
        // 最后一行
        DWrapView *rowView = (DWrapView *)frontView;
        [rowView addView:view margin:margin padding:padding];
        self.height=rowView.bottom + margin.bottom + padding.bottom;
    } else {
        // 新建一行
        DWrapView *rowView = [[DWrapView alloc]initWidth:self.width];
        rowView.offsetX = self.offsetX;
        rowView.backgroundColor = [UIColor whiteColor];
        if (view.height>rowHeight) {
            rowView.subHeight = view.height;
        }
        else{
            rowView.subHeight = rowHeight;
        }
        
        [rowView addView:view margin:margin padding:padding];
        [self addView:rowView margin:UIEdgeInsetsZero];
        frontView = rowView;
    }
    
}

- (void)updateView {
    [super updateView];
    [self setBorder];
}

#pragma mark  show

- (void)showRow:(NSInteger)row {
    self.subviews[row].hidden = NO;
    [self updateView];
}

- (void)hideRow:(NSInteger)row {
    self.subviews[row].hidden = YES;
    [self updateView];
}

#pragma  mark -border
- (void)setBorder {
    // 线条
    for (CALayer *item in lineList) {
        [item removeFromSuperlayer];
    }
    
    [lineList removeAllObjects];
    
    //
    // border
    if (self.isShowLine) {
        NSMutableArray<NSMutableArray *> *sectionList = [NSMutableArray new];
        
        BOOL needAdd = NO;
        
        for (UIView *item in [self showRowList]) {
            // 提取section分组
            if (item.showLine) {
                if (sectionList.count == 0) {
                    needAdd = YES;
                }
                
                if (needAdd) {
                    NSMutableArray *itemList = [NSMutableArray new];
                    [itemList addObject:item];
                    [sectionList addObject:itemList];
                    needAdd = NO;
                } else {
                    [sectionList.lastObject addObject:item];
                }
            } else {
                needAdd = YES;
            }
        }
        
        if (self.lineType == 0) {
            for (NSMutableArray *itemlist in sectionList) {
                for (int i = 0; i < itemlist.count; i++) {
                    CGFloat xoffset = self.offsetX;
                    
                    UIView  *view = itemlist[i];
                    CALayer *layer = [CALayer new];
                    CGRect  rect = CGRectMake(xoffset, view.bottom - 1 + 0.5, self.width - 2 * xoffset, 1);
                    layer.frame = GetLineRectX(rect);
                    layer.backgroundColor = self.lineColor.CGColor;
                    [self.layer addSublayer:layer];
                    [lineList addObject:layer];
                }
            }
        } else if (self.lineType == 1) {
            for (NSMutableArray *itemlist in sectionList) {
                for (int i = 0; i < itemlist.count; i++) {
                    CGFloat xoffset = self.offsetX;
                    UIView  *view = itemlist[i];
                    CALayer *layer = [CALayer new];
                    
                    if (i == 0) {
                        CALayer *layer = [CALayer new];
                        CGRect  rect = CGRectMake(0, view.top - 0.5, self.width, 1);
                        layer.frame = GetLineRectX(rect);
                        layer.backgroundColor = self.lineColor.CGColor;
                        [self.layer addSublayer:layer];
                        [lineList addObject:layer];
                    }
                    
                    if (i == itemlist.count - 1) {
                        xoffset = 0;
                    }
                    
                    CGRect rect = CGRectMake(xoffset, view.bottom - 1 + 0.5, self.width - xoffset, 1);
                    layer.frame = GetLineRectX(rect);
                    layer.backgroundColor = self.lineColor.CGColor;
                    [self.layer addSublayer:layer];
                    [lineList addObject:layer];
                    
                    [view setBottomLine:nil];
                }
            }
        }
        else if (self.lineType == 2) {
            for (NSMutableArray *itemlist in sectionList) {
                for (int i = 0; i < itemlist.count-1; i++) {
                    CGFloat xoffset = self.offsetX;
                    
                    UIView  *view = itemlist[i];
                    CALayer *layer = [CALayer new];
                    CGRect  rect = CGRectMake(xoffset, view.bottom - 1 + 0.5, self.width - 2 * xoffset, 1);
                    layer.frame = GetLineRectX(rect);
                    layer.backgroundColor = self.lineColor.CGColor;
                    [self.layer addSublayer:layer];
                    [lineList addObject:layer];
                }
            }
        }
        else if (self.lineType == 3) {
            for (NSMutableArray *itemlist in sectionList) {
                for (int i = 0; i < itemlist.count-1; i++) {
                    CGFloat xoffset = self.offsetX + 16 + 10;
                    
                    UIView  *view = itemlist[i];
                    CALayer *layer = [CALayer new];
                    CGRect  rect = CGRectMake(xoffset, view.bottom - 1 + 0.5, self.width - xoffset, 1);
                    layer.frame = GetLineRectX(rect);
                    layer.backgroundColor = self.lineColor.CGColor;
                    [self.layer addSublayer:layer];
                    [lineList addObject:layer];
                }
            }
        }
        else if (self.lineType == 4) {
            for (NSMutableArray *itemlist in sectionList) {
                for (int i = 0; i < itemlist.count-1; i++) {
                    CGFloat xoffset = self.offsetX;
                    
                    UIView  *view = itemlist[i];
                    CALayer *layer = [CALayer new];
                    CGRect  rect = CGRectMake(xoffset, view.bottom - 1 + 0.5, self.width - xoffset, 1);
                    layer.frame = GetLineRectX(rect);
                    layer.backgroundColor = self.lineColor.CGColor;
                    [self.layer addSublayer:layer];
                    [lineList addObject:layer];
                }
            }
        }
    }
}

@end
