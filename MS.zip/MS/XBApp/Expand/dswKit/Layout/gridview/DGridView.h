//
//  FlowView.h
//  test
//
//  Created by stephen on 15/2/12.
//  Copyright (c) 2015年 dsw. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DLayoutBaseView.h"
#import "NSObject+KVO.h"
#import "DStackView.h"


@interface UIView (Row)

/**
 *  grid row 是否显示分割线
 */
@property (nonatomic, assign) BOOL showLine;

@end

/**
 *  网格布局
 */
@interface DGridView : DStackView

{
    // 配置
    CGFloat column;
    CGFloat rowHeight;
}
@property (nonatomic, assign) CGFloat rowHeight;

/**
 *  距离父视图边距
 */
@property (nonatomic, assign) CGFloat offsetX;



#pragma mark  init

- (void)setColumn:(NSInteger)s height:(NSInteger)h;

#pragma mark  show line

@property (nonatomic, strong)  UIColor *lineColor;

@property (nonatomic, assign) BOOL isShowLine;

/**
 *  0 尾部有横线  , offsex both
 *  1 首尾有横线  , offsex left
 *  2 首位无横线  , offsex both
 *  3 首位无横线  , offsex text
 *  4 首位无横线  , offsex left
 */
@property (nonatomic, assign) NSInteger lineType;

#pragma mark  add view

/**
 *   添加一行,有line
 */
- (void)addRowView:(UIView *)view;

- (void)addView:(UIView *)view crossColumn:(CGFloat)num;

- (void)addView:(UIView *)view crossColumn:(CGFloat)num margin:(UIEdgeInsets)margin;

- (void)addView:(UIView *)view crossColumn:(CGFloat)num padding:(UIEdgeInsets)padding;

#pragma mark  delete view

// - (void)removeRow:(NSInteger)row;

#pragma mark  show hide

- (void)showRow:(NSInteger)row;

- (void)hideRow:(NSInteger)row;

@end
