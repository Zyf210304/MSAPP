/*
 *   Erica Sadun, http://ericasadun.com
 *   iPhone Developer's Cookbook, 3.0 Edition
 *   BSD License, Use at your own risk
 */

// frema 快速设置
#import <UIKit/UIKit.h>

CGPoint CGRectGetCenter(CGRect rect);

CGRect CGRectMoveToCenter(CGRect rect, CGPoint center);

@interface UIView (ViewFrameGeometry)

@property CGPoint   origin;

@property CGSize    size;

@property (readonly) CGPoint    bottomLeft;

@property (readonly) CGPoint    bottomRight;

@property (readonly) CGPoint    topRight;

/**
 *  size.height
 */
@property CGFloat   height;

/**
 *  size.width
 */
@property CGFloat   width;

/**
 *  origin.y
 */
@property CGFloat   top;

/**
 *  origin.x
 */
@property CGFloat   left;

/**
 *  有height -> origin.y
 */
@property CGFloat   bottom;

/**
 *  有width -> origin.x
 */
@property CGFloat   right;

/**
 *  有width height
 */
@property (assign, nonatomic) CGFloat   centerX;

/**
 *  有width height
 */
@property (assign, nonatomic) CGFloat   centerY;

- (void)moveBy:(CGPoint)delta;

- (void)scaleBy:(CGFloat)scaleFactor;

- (void)fitInSize:(CGSize)aSize;

@end
