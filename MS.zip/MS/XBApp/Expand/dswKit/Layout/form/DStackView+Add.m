//
//  DStackView+Add.m
//  qtyd
//
//  Created by stephendsw on 15/9/21.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import "DStackView+Add.h"
#import "UIControl+BlockEvent.h"

@implementation DStackView (Add)

- (UIButton *)addRowButtonTitle:(NSString *)str click:(void (^)(id value))block {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];

    [button setTitle:str forState:UIControlStateNormal];

    button.frame = CGRectMake(0, 0, 0, 50);

    [self setSubmitButtonStyle:button];
    button.titleLabel.font=[UIFont systemFontOfSize:17];

    [button click:^(id value) {
        block(value);
    }];

    [self addView:button margin:UIEdgeInsetsMake(0, 20, 0, 20)];
    
    return button;
}

@end
