//
//  DGridView+Add.m
//  qtyd
//
//  Created by stephendsw on 15/9/21.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import "DGridView+Add.h"
#import "UITextField+input.h"
#import "TimeCodeButton.h"
#import "UISelect.h"

@implementation DGridView (Add)

#pragma mark - 输入



// 添加  文本-输入框
- (WTReTextField *)addRowInput:(NSString *)title placeholder:(NSString *)str {
    UILabel *label = [[UILabel alloc]init];

    label.text = title;
    [self setLabelStyle:label];

    WTReTextField *tfview = [[WTReTextField alloc]init];
    [tfview setLeftLabel:label];
    tfview.placeholder = str;
    [self setTfviewStyle:tfview];
    [self addView:tfview crossColumn:column];

    return tfview;
}

/**
 *   添加  输入框
 *
 */
- (WTReTextField *)addRowInputWithplaceholder:(NSString *)str {
    WTReTextField *tfview = [[WTReTextField alloc]init];

    tfview.placeholder = str;
    [self setTfviewStyle:tfview];
    [self addView:tfview crossColumn:column];

    return tfview;
}

/**
 *  添加  文本-输入框-文本
 *
 */
- (WTReTextField *)addRowInput:(NSString *)title placeholder:(NSString *)str tagText:(NSString *)tag {
    UILabel *label = [[UILabel alloc]init];
    
    label.text = title;
    [self setLabelStyle:label];
    
    WTReTextField *tfview = [[WTReTextField alloc]init];
    tfview.placeholder = str;
    [tfview setLeftLabel:label];
    [self setTfviewStyle:tfview];
    [self addView:tfview crossColumn:column / 16 * 15];
    
    UILabel *labelTag = [[UILabel alloc]init];
    labelTag.textAlignment = NSTextAlignmentRight;
    labelTag.text = tag;
    [self setLabelStyle:labelTag];
    labelTag.font = [UIFont systemFontOfSize:10];
    [self addView:labelTag crossColumn:column / 16 * 1];
    
    return tfview;
}

// 添加  文本-输入框-按钮
- (WTReTextField *)addRowInput:(NSString *)title placeholder:(NSString *)str clickText:(NSString *)text block:(void (^)(id value))block {
    UILabel *label = [[UILabel alloc]init];
    label.text = title;
    [self setLabelStyle:label];
    
    WTReTextField *tfview = [[WTReTextField alloc]init];
    [tfview setLeftLabel:label];
    tfview.placeholder = str;
    [self setTfviewStyle:tfview];
    [self addView:tfview crossColumn:column / 16 * 13];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [button click:^(id value) {
        block(value);
    }];
    
    [QTTheme btnBlackStyle:button];
    
    [button setTitle:text forState:UIControlStateNormal];
    
    [button sizeToFit];
    
    [self addView:button crossColumn:column / 16 * 3 margin:UIEdgeInsetsMake(10, 0, 10, 0)];
    
    return tfview;
}

// 添加  输入框-按钮
- (WTReTextField *)addRowplaceholder:(NSString *)str clickText:(NSString *)text block:(void (^)(id value))block {
    WTReTextField *tfview = [[WTReTextField alloc]init];
    
    tfview.placeholder = str;
    [self setTfviewStyle:tfview];
    [self addView:tfview crossColumn:column];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button click:^(id value) {
        block(value);
    }];
    
    button.backgroundColor = [UIColor whiteColor];
    [button setTitleColor:Theme.themeColor forState:UIControlStateNormal];
    button.enabled = YES;
    button.titleLabel.font = [UIFont systemFontOfSize:14];
    button.contentHorizontalAlignment = NSTextAlignmentRight;
    button.showBackgroundColorHighlighted = YES;
    
    [button setTitle:text forState:UIControlStateNormal];
    
    [button sizeToFit];
    
    tfview.rightView = button;
    tfview.rightViewMode = UITextFieldViewModeAlways;
    
    return tfview;
}



#pragma mark - 文本

/**
 *   添加  文本-文本
 *
 */
- (UILabel *)addRowLabelLimit:(NSString *)title text:(NSString *)str {
    UILabel *label = [[UILabel alloc]init];
    label.text = title;
    [self setLabelStyle:label];
    label.numberOfLines=0;
    label.textAlignment = NSTextAlignmentCenter;
    [label sizeToFit];

    [self addView:label crossColumn:3];
    
    UILabel *label2 = [[UILabel alloc]init];
    label2.text = str;
    label2.numberOfLines = 0;
    label2.textAlignment = NSTextAlignmentLeft;
    [self setLabelStyle:label2];
    label2.textColor = [UIColor colorHex:@"666666"];
    [self addView:label2 crossColumn: 13];
    return label2;
}

/**
 *   添加  文本-文本
 *
 */
- (UILabel *)addRowLabel:(NSString *)title text:(NSString *)str {
    UILabel *label = [[UILabel alloc]init];
    label.text = title;
    [self setLabelStyle:label];
    [label sizeToFit];
    
    CGFloat allwidth = ( self.width - self.offsetX *2);
    CGFloat labelWidth =  label.width + 10;
    
    [self addView:label crossColumn:labelWidth / allwidth *column];

    UILabel *label2 = [[UILabel alloc]init];
    label2.text = str;
    label2.numberOfLines = 0;
    label2.textAlignment = NSTextAlignmentRight;
    [self setLabelStyle:label2];
    label2.textColor = [UIColor colorHex:@"666666"];
    [self addView:label2 crossColumn: (allwidth- labelWidth)/ allwidth *column];
    return label2;
}

/**
 *   添加  文本
 *
 */
- (UILabel *)addRowLabel:(NSString *)title  {
    UILabel *label = [[UILabel alloc]init];

    label.text = title;
    [self setLabelStyle:label];
    [self addView:label crossColumn:column];

    return label;
}

- (UILabel *)addhalfRowLabel:(NSString *)title  {
    UILabel *label = [[UILabel alloc]init];
    
    label.text = title;
    [self setLabelStyle:label];
    [self addView:label crossColumn:column];
    
    return label;
}


/**
 *   添加  文本提示
 *
 */
- (YFPlaceOrderBaseView *)addBaseViewTitle:(NSString *)title {
    YFPlaceOrderBaseView *baseView = [[YFPlaceOrderBaseView alloc] init];
    [baseView setUIWith:Base_TF];
    [baseView setValueWithLeftStr:title addRightLblStr:@""];
    baseView.swith.hidden = YES;
    baseView.centerTF.text = @"10";
    [self addView:baseView crossColumn:column];
    
    return baseView;
}



/**
 *   添加  文本提示
 *
 */
- (UILabel *)addRowLabelTip:(NSString *)title {
    UILabel *label = [UILabel new];

    label.font = [UIFont systemFontOfSize:12];
    label.text = title;
    label.textColor = [UIColor colorHex:@"666666"];
    [label sizeToFit];
    [self addView:label margin:UIEdgeInsetsMake(0, self.offsetX, 0, self.offsetX)];
    return label;
}

#pragma mark - 下拉

/**
 *  添加  文本-下拉框 uiselect
 */
- (UISelect *)addRowDropSelect:(NSString *)title placeholder:(NSString *)str {
    UILabel *label = [[UILabel alloc]init];

    label.text = title;
    [self setLabelStyle:label];

    UISelect *tfview = [[UISelect alloc]init];
    [tfview setLeftLabel:label];
    tfview.placeholder = str;
    [self setTfviewStyle:tfview];
    [self addView:tfview crossColumn:column];

    return tfview;
}

#pragma mark - 点击

/**
 *   添加  文本-文本
 *
 */
- (UILabel *)addRowSelectLabel:(NSString *)title text:(NSString *)str {
    
    UILabel *label = [[UILabel alloc]init];
    label.text = title;
    [self setLabelStyle:label];
    
    CGFloat allwidth = ( self.width - self.offsetX *2);
    CGFloat labelWidth =  label.width + 10;
    
    [self addView:label crossColumn:labelWidth / allwidth *column];
    
    UILabel *label2 = [[UILabel alloc]init];
    label2.text = str;
    label2.numberOfLines = 0;
    label2.textAlignment = NSTextAlignmentRight;
    [self setLabelStyle:label2];
    label2.textColor = [UIColor colorHex:@"666666"];
    
    [self addView:label2 crossColumn: (allwidth- labelWidth -20)/ allwidth *column];
        
    WTReTextField *tfview = [[WTReTextField alloc]init];
    tfview.enabled = NO;
    [self setTfviewStyle:tfview];
    [tfview setRightImage:@"icon-arrows-"];
    
    [self addView:tfview crossColumn:20/ allwidth *column];
    
    return label2;
}


//  添加  文本-选择框
- (WTReTextField *)addRowSelectText:(NSString *)title placeholder:(NSString *)str done:(Action)block; {
    UILabel *label = [[UILabel alloc]init];

    label.text = title;
    [self setLabelStyle:label];
    
    WTReTextField *tfview = [[WTReTextField alloc]init];
    
    [tfview setLeftLabel:label];
    
    tfview.text = str;
    tfview.enabled = NO;
    [self setTfviewStyle:tfview];
    [tfview setRightImage:@"icon-arrows-"];
    [self addView:tfview crossColumn:column];
    [tfview.superview addTapGesture:^{
        [self endEditing:YES];
        block();
    }];
    
    return tfview;
}


/**
 *   添加  文本-点击跳转（提示文字）
 *
 */
- (WTReTextField *)addRowSelectText:(NSString *)str done:(Action)block {
    WTReTextField *tfview = [[WTReTextField alloc]init];

    tfview.text = str;
    tfview.enabled = NO;
    [self setTfviewStyle:tfview];
    [tfview setRightImage:@"icon-arrows-"];
    [self addView:tfview crossColumn:column];
    [tfview.superview addTapGesture:^{
        [self endEditing:YES];
        block();
    }];

    return tfview;
}

#pragma mark - 其他

// 添加  文本-验证码
- (WTReTextField *)addRowCodeText:(void (^)(id value))block {
    
    
    UILabel *label = [[UILabel alloc]init];
    
    label.text = @"验证码  ";
    [self setLabelStyle:label];
    
    WTReTextField *tfview = [[WTReTextField alloc]init];
    tfview.placeholder = @"请输入验证码";
    [self setTfviewStyle:tfview];
    tfview.clearsOnBeginEditing=YES;
    [tfview setLeftLabel:label];
    [self addView:tfview crossColumn:column / 16 * 10];

    TimeCodeButton *button = [TimeCodeButton buttonWithType:UIButtonTypeCustom];
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [button click:^(id value) {
        block(value);
        tfview.text=@"";
    }];
    [button setTitle:@"发送验证码" forState:UIControlStateNormal];
    [self addView:button crossColumn:column / 16 * 6 margin:UIEdgeInsetsMake(5, 0, 5, 0)];
    [self setCodeButtonStyle:button];

    return tfview;
}

// 添加  文本-验证码
- (WTReTextField *)addRowNewBankCodeText:(void (^)(id value))block {
    WTReTextField *tfview = [[WTReTextField alloc]init];
    tfview.placeholder = @"请输入验证码";
    [self setTfviewStyle:tfview];
    tfview.clearsOnBeginEditing=YES;
    [self addView:tfview crossColumn:column / 16 * 10];
    
    TimeCodeButton *button = [TimeCodeButton buttonWithType:UIButtonTypeCustom];
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [button click:^(id value) {
        block(value);
        tfview.text=@"";
    }];
    [button setTitle:@"发送验证码" forState:UIControlStateNormal];
    [button setBackgroundColor:[UIColor redColor]];
    [self addView:button crossColumn:column / 25 * 6 margin:UIEdgeInsetsMake(5, 0, 5, 0)];
    [self setCodeButtonStyle:button];
    
    return tfview;
}



/**
 *  添加  文本-Swicth
 *
 */
- (UISwitch *)addRowSwitch:(NSString *)title   {
    UILabel *label = [[UILabel alloc]init];

    label.text = title;
    [self setLabelStyle:label];
    [self addView:label crossColumn:column / 4 * 3];

    UISwitch *switchBtb = [[UISwitch alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];

    double left = (self.width - self.offsetX * 2) / 4 - 51;

    double top = (self.rowHeight - 31) / 2;

    [self addView:switchBtb crossColumn:column / 4 margin:UIEdgeInsetsMake(top, left, top, 0)];

    return switchBtb;
}

/**
 *  添加  文本-按钮
 *
 */
- (UIButton *)addRowClickButtonTitle:(NSString *)str click:(void (^)(id value))block {
    UILabel *label = [[UILabel alloc]init];
    
    label.text = str;
    [self setLabelStyle:label];
    [self addView:label crossColumn:column / 4 * 3];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:str forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, 0, 50);
    [self setRightButtonStyle:button];
    
    [button click:^(id value) {
        block(value);
    }];
    [self addView:button crossColumn:column / 4  margin:UIEdgeInsetsMake(10, 0, 10, 0)];
    return button;
}

@end
