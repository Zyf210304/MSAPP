//
//  WTReTextField+Add.h
//  qtyd
//
//  Created by stephendsw on 15/9/21.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import "WTReTextField.h"

@interface WTReTextField (Add)

- (void)setPhone;

- (void)setUserName;

- (void)setPwd;

- (void)setValidationCode;

- (void)setEmail;

- (void)setNickName;

- (void)setRealName;

- (void)setIDCard;

- (void)setMoney;

- (void)setMoneyFomart;

- (void)setPositiveInteger;

- (void)setBankCard;

- (void)setPayPassword;

-(void)setEnterYear;

-(void)setCompanyName;

@end
