//
//  DGridView+Add.h
//  qtyd
//
//  Created by stephendsw on 15/9/21.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import "DGridView.h"
#import "WTReTextField.h"
#import "UISelect.h"
#import "YFPlaceOrderBaseView.h"

@interface DGridView (Add)

#pragma mark - 输入

// 添加  文本-输入框
- (WTReTextField *)addRowInput:(NSString *)title placeholder:(NSString *)str;

// 添加  文本-输入框-文本
- (WTReTextField *)addRowInput:(NSString *)title placeholder:(NSString *)str tagText:(NSString *)tag;

// 添加  输入框
- (WTReTextField *)addRowInputWithplaceholder:(NSString *)str;

// 添加  文本-输入框-按钮
- (WTReTextField *)addRowInput:(NSString *)title placeholder:(NSString *)str clickText:(NSString *)text block:(void (^)(id value))block;

// 添加  输入框-按钮
- (WTReTextField *)addRowplaceholder:(NSString *)str clickText:(NSString *)text block:(void (^)(id value))block;

#pragma mark - 文本

/**
 *   添加  文本-文本
 *
 */
- (UILabel *)addRowLabelLimit:(NSString *)title text:(NSString *)str;

/**
 *   添加  文本-文本
 *
 */
- (UILabel *)addRowLabel:(NSString *)title text:(NSString *)str;

/**
 *   添加  文本 有背景
 *
 */
- (UILabel *)addRowLabel:(NSString *)title;
- (UILabel *)addhalfRowLabel:(NSString *)title;
/**
 *   添加  文本提示 无背景
 *
 */
- (UILabel *)addRowLabelTip:(NSString *)title;

#pragma mark - 点击

/**
 *   添加  文本-点击跳转（提示文字）
 *
 */
- (WTReTextField *)addRowSelectText:(NSString *)title placeholder:(NSString *)str done:(void (^)(void))block;

/**
 *   添加  文本-点击跳转（提示文字）
 *
 */
- (WTReTextField *)addRowSelectText:(NSString *)str done:(void (^)(void))block;

/**
 *   添加  文本-文本
 *
 */
- (UILabel *)addRowSelectLabel:(NSString *)title text:(NSString *)str;

#pragma mark - 下拉

/**
 *  添加  文本-下拉框 uiselect
 */
- (UISelect *)addRowDropSelect:(NSString *)title placeholder:(NSString *)str;

#pragma mark - 其他

/**
 *  添加  文本-按钮
 *
 */
- (UIButton *)addRowClickButtonTitle:(NSString *)str click:(void (^)(id value))block;

/**
 *   添加  文本-验证码
 *
 */
- (WTReTextField *)addRowCodeText:(void (^)(id value))block;

- (WTReTextField *)addRowNewBankCodeText:(void (^)(id value))block;
/**
 *  添加  文本-Swicth
 *
 */
- (UISwitch *)addRowSwitch:(NSString *)title;




- (YFPlaceOrderBaseView *)addBaseViewTitle:(NSString *)title;



@end
