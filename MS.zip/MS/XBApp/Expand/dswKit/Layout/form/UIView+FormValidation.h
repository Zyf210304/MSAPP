//
//  UIView+FormValidation.h
//  qtyd
//
//  Created by stephendsw on 15/9/21.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WTReTextField.h"

@interface UIView (FormValidation)

/*
 * 自动验证数据
 */
- (void)validation:(NSInteger)group fail:(void (^)(id value))block success:(void (^)(id value))blocksuccess;

/*
 * 手动验证界面
 */
- (BOOL)validation:(NSInteger)group;

/*
 * 验证数据
 */
- (BOOL)validationData:(NSInteger)group;

/*
 * 单个控件验证数据
 */
- (BOOL)validationText:(WTReTextField *)text;

@end
