//
//  UIView+FormValidation.m
//  qtyd
//
//  Created by stephendsw on 15/9/21.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import "UIView+FormValidation.h"
#import "UIView+layout.h"
#import "WTReTextField.h"
#import "NSString+regularExpression.h"
#import "UIViewController+toast.h"

@implementation UIView (FormValidation)

- (void)validation:(NSInteger)group fail:(void (^)(id value))block success:(void (^)(id value))blocksuccess {
    if ([self validationData:group]) {
        blocksuccess(nil);
    } else {
        block(nil);
    }

    for (UIView *item in self.allSubviews) {
        if ([item isKindOfClass:[WTReTextField class]]) {
            WTReTextField *wtf = (WTReTextField *)item;

            [wtf editChange:^(id value) {
                if ([self validationData:group]) {
                    blocksuccess(wtf);
                } else {
                    block(wtf);
                }
            }];
        }
    }
}

- (BOOL)validationData:(NSInteger)group {
    NSDictionary *type = @{
        kRegIDCard :@(17),
        kRegPassword :@(6),
        kRegValidCode :@(6),
        kRegPhone :@(11),
        kBankCard :@(15),
        kRegNumber :@(1),
        kPositiveInteger :@(12),
        kMoney :@(1),
        kRegNick :@(1)
    };

    for (UIView *item in self.allSubviews) {
        if ([item isKindOfClass:[WTReTextField class]]) {
            WTReTextField *wtf = (WTReTextField *)item;

            if (wtf.group != group) {
                continue;
            }

            NSInteger length = type.i(wtf.pattern);

            if (length == 0) {
                length = 1;
            }

            if (wtf.isNeed && (wtf.text.length < length)) {
                return NO;
            }

            if ([wtf.pattern isEqualToString:kMoney]) {
                if (floatCompare(wtf.text.doubleValue, 0) == 0) {
                    return NO;
                }
            }
        }
    }

    return YES;
}

- (BOOL)validationText:(WTReTextField *)text {
    WTReTextField *wtf = (WTReTextField *)text;

    if (wtf.isNeed && (wtf.text.length == 0)) {
        // [self.viewController showToast:wtf.nilTip];
        return NO;
    }

    NSString *pattern = wtf.pattern;

    if ([pattern isEqualToString:kRegPassword]) {
        pattern = @"(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}";
    }

    if ((pattern.length > 0) && ![wtf.text isMatch:pattern]) {
        // [self.viewController showToast:wtf.errorTip];
        return NO;
    }

    return YES;
}

- (BOOL)validation:(NSInteger)group {
    for (UIView *item in self.allSubviews) {
        if ([item isKindOfClass:[WTReTextField class]]) {
            WTReTextField *wtf = (WTReTextField *)item;

            if (wtf.group != group) {
                continue;
            }

            if (wtf.isNeed && (wtf.text.length == 0)) {
                [self.viewController showToast:wtf.nilTip];
                return NO;
            }

            NSString *pattern = wtf.pattern;

            if ([pattern isEqualToString:kRegPassword]) {
                pattern = @"(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}";
            }

            if ((pattern.length > 0) && ![wtf.text isMatch:pattern]) {
                [self.viewController showToast:wtf.errorTip];
                return NO;
            }
        }
    }

    return YES;
}

@end
