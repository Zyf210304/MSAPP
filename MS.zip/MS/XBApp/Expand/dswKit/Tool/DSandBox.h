//
//  DSandBox.h
//  qtyd
//
//  Pathd by stephendsw on 2017/1/10.
//  Copyright © 2017年 qtyd. All rights reserved.
//

#import <Foundation/Foundation.h>



FOUNDATION_EXPORT NSString *pathDocumentsFile(NSString *fileName);

FOUNDATION_EXPORT NSString *pathTmpFile(NSString *fileName);

FOUNDATION_EXPORT NSString *pathLibraryFile(NSString *fileName);

FOUNDATION_EXPORT NSString *pathPreferencesFile(NSString *fileName);

FOUNDATION_EXPORT NSString *pathCachesFile(NSString *fileName);
