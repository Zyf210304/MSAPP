//
//  IPHelper.h
//  qtyd
//
//  Created by stephendsw on 15/7/16.
//  Copyright (c) 2015年 qtyd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IPHelper : NSObject

+ (NSString *)deviceIPAdress;

@end
