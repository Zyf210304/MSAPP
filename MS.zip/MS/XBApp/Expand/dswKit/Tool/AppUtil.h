//
//  WLAppStoreUtil.h
//  Util
//
//  Created by stephen on 13-11-4.
//  Copyright (c) 2014年 dsw. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

int floatCompare(double fA, double fB);

// ****************************************device****************************************
#pragma mark - device

#define IOS_VERSION_7_OR_ABOVE      (([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) ? (YES) : (NO))

#define IOS_VERSION_8_OR_ABOVE      (([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0) ? (YES) : (NO))

#define  IOS_VERSION_9_OR_ABOVE     (([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.0) ? (YES) : (NO))

#define  IOS_VERSION_11_OR_ABOVE    (([[[UIDevice currentDevice] systemVersion] floatValue] >= 11.0) ? (YES) : (NO))

#define IOS_VERSION_7               (([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0 && ([[[UIDevice currentDevice] systemVersion] floatValue] < 8.0)) ? (YES) : (NO))

#define IOS_VERSION_6               (([[[UIDevice currentDevice] systemVersion] floatValue] >= 6.0 && ([[[UIDevice currentDevice] systemVersion] floatValue] < 7.0)) ? (YES) : (NO))

// **************************************屏幕******************************************
#pragma mark -  屏幕

#define APP_FRAEM   ([UIScreen mainScreen].bounds)
#define APP_WIDTH   ([UIScreen mainScreen].bounds.size.width)
#define APP_HEIGHT  ([UIScreen mainScreen].bounds.size.height)

#define APP_NAVIGATION_BAR_HEIGHT ((APP_HEIGHT == 812) ? (88) : (64))

#define APP_TAB_BAR_BAR_HEIGHT ((APP_HEIGHT == 812) ? (83) : (49))

// **************************************屏幕******************************************
#define IPHONE4     ((APP_HEIGHT == 480) ? (YES) : (NO))

#define IPHONE5     ((APP_HEIGHT == 568) ? (YES) : (NO))

#define IPHONE6     ((APP_HEIGHT == 667) ? (YES) : (NO))

#define IPHONE6PLUS ((APP_HEIGHT == 736) ? (YES) : (NO))

#define IPHONEX ((APP_HEIGHT == 812) ? (YES) : (NO))

@interface AppUtil : NSObject

#pragma mark device

/**
 *  获取openUDID
 *
 */
+ (NSString * __nonnull)getOpenUDID;

/**
 *  获取设备名
 *
 */
+ (NSString * __nonnull)getDeviceName;

/**
 *  获取系统版本
 *
 */
+ (NSString *__nonnull)getSystemName;

/**
 *  是否联网
 *
 */
+ (BOOL)isConnectedToNetwork;

/**
 *  网络类型
 *
 */
+ (NSString *__nonnull)getNetWorkStates;

/**
 *  分辨率
 *
 */
+ (NSString *__nonnull)getResolution;

#pragma mark app

/**
 *  获取app版本
 *
 */
+ (NSString *__nonnull)getAPPVersion;

/**
 *  获取app内部版本
 */
+ (NSString *__nonnull)getAPPBuild;

/**
 *  APP Store 上打开应用
 */
+ (BOOL)appStoreWithAppId:(NSString *__nonnull)appId;

/**
 *  跳转app设置
 */
+(void)openSet;

/**
 *  safari 打开链接
 */
+ (void)safari:(NSString *__nonnull)urlString;

/**
 *  拨打电话
 */
+ (BOOL)dial:(NSString *__nonnull)tel;

/**
 *  打开APP
 */
+ (BOOL)openApp:(NSString *__nonnull)url;

/**
 *  跳转评论
 */
+ (void)openAPPComment:(NSString *__nonnull)appid;

/**
 *  是否有安装QQ客户端(请在info.plist文件中 将QQ(mqq)添加到白名单)
 *
 *  设置方法:在info.plist添加LSApplicationQueriesSchemes 类型Array 2.添加一个 item 值设为:mqq
 *
 *  @return BOOL
 */
+ (BOOL)haveQQ;

/**
 *  发起QQ临时会话
 *
 *  @param QQ 开通QQ推广的QQ号码 (开通QQ推广方法:1.打开QQ推广网址http://shang.qq.com并用QQ登录  2.点击顶部导航栏:推广工具  3.在弹出菜单中点击'立即免费开通')
 */
+ (void)chatWithQQ:(NSString *__nonnull)QQ;

#pragma mark other
+ (void)onceAction:(NSString *__nonnull)key block:(Action __nonnull)block;

+ (void)onceAction:(NSString *__nonnull)key block:(Action __nonnull)block otherBlock:(Action __nonnull)blockOther;

@end
