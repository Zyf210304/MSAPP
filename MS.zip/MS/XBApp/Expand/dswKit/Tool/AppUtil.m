//
//  WLAppStoreUtil.m
//  Util
//
//  Created by dsw on 13-11-4.
//  Copyright (c) 2014年 dsw All rights reserved.
//

#import "AppUtil.h"
#import "OpenUDID.h"

#import <sys/utsname.h>

#import <SystemConfiguration/SystemConfiguration.h>
#import <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#import "NSString+quick.h"

int floatCompare(double fA, double fB) {
    const double    fEpsilon = EPS;
    double          fDelta = fA - fB;
    
    if (fDelta > fEpsilon) {
        return 1;                       // 大于，返回1
    } else if (fDelta < -fEpsilon) {
        return -1;                      // 小于，返回-1
    }
    
    return 0; // 等于，返回0
}

@implementation AppUtil

#pragma mark - device

+ (BOOL)isConnectedToNetwork {
    // Create zero address
    struct sockaddr_in zeroAddress;
    
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sin_len = sizeof(zeroAddress);
    zeroAddress.sin_family = AF_INET;
    
    // Recover reachability flags
    SCNetworkReachabilityRef    defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags  flags;
    BOOL                        didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    
    if (!didRetrieveFlags) {
        // printf("Error. Could not recover network reachability flags\n");
        return 0;
    }
    
    BOOL    isReachable = flags & kSCNetworkFlagsReachable;
    BOOL    needsConnection = flags & kSCNetworkFlagsConnectionRequired;
    return (isReachable && !needsConnection) ? YES : NO;
}

/**
 *  分辨率
 *
 */
+ (NSString *)getResolution {
    CGFloat scale_screen = [UIScreen mainScreen].scale;
    
    return [NSString stringWithFormat:@"%.0f*%.0f", APP_WIDTH * scale_screen, APP_HEIGHT * scale_screen];
}

+ (NSString *)getNetWorkStates {
    UIApplication   *app = [UIApplication sharedApplication];
    NSArray         *children = [[[app valueForKeyPath:@"statusBar"]valueForKeyPath:@"foregroundView"]subviews];
    
    NSString *netType = @"0";
    
    NSDictionary *dicInfo = @{
                              @"0":@"无网络",
                              @"1":@"2G",
                              @"2":@"3G",
                              @"3":@"4G",
                              @"5":@"WIFI"
                              };
    
    // 获取到网络返回码
    for (id child in children) {
        if ([child isKindOfClass:NSClassFromString(@"UIStatusBarDataNetworkItemView")]) {
            // 获取到状态栏
            netType = [NSString stringWithFormat:@"%@", [child valueForKeyPath:@"dataNetworkType"]];
        }
    }
    
    return dicInfo[netType];
}

/**
 *  获取openUDID
 *
 */
+ (NSString *)getOpenUDID {
    return [OpenUDID value];
}

+ (NSString *)getDeviceName {
    struct utsname systemInfo;
    
    uname(&systemInfo);
    
    NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
    
    NSDictionary *dicInfo = @{
                              @"iPhone1,1":@"iPhone 2G",
                              @"iPhone1,2":@"iPhone 3G",
                              @"iPhone2,1":@"iPhone 3GS",
                              @"iPhone3,1":@"iPhone 4",
                              @"iPhone3,2":@"iPhone 4",
                              @"iPhone3,3":@"iPhone 4",
                              @"iPhone4,1":@"iPhone 4S",
                              @"iPhone5,1":@"iPhone 5",
                              @"iPhone5,2":@"iPhone 5",
                              @"iPhone5,3":@"iPhone 5c",
                              @"iPhone5,4":@"iPhone 5c",
                              @"iPhone6,1":@"iPhone 5s",
                              @"iPhone6,2":@"iPhone 5s",
                              @"iPhone7,1":@"iPhone 6 Plus",
                              @"iPhone7,2":@"iPhone 6",
                              @"iPhone8,1":@"iPhone 6s",
                              @"iPhone8,2":@"iPhone 6s Plus",
                              @"iPhone8,4":@"iPhone SE",
                              @"iPhone9,1":@"iPhone 7",
                              @"iPhone9,2":@"iPhone 7 Plus",
                              @"iPhone10,1":@"iPhone 8",
                              @"iPhone10,4":@"iPhone 8",
                              @"iPhone10,2":@"iPhone 8 Plus",
                              @"iPhone10,5":@"iPhone 8 Plus",
                              @"iPhone10,3":@"iPhone X",
                              @"iPhone10,6":@"iPhone X",
                              @"iPod1,1":@"iPod Touch 1G",
                              @"iPod2,1":@"iPod Touch 2G",
                              @"iPod3,1":@"iPod Touch 3G",
                              @"iPod4,1":@"iPod Touch 4G",
                              @"iPod5,1":@"iPod Touch 5G",
                              @"iPad1,1":@"iPad 1G",
                              @"iPad2,1":@"iPad 2",
                              @"iPad2,2":@"iPad 2",
                              @"iPad2,3":@"iPad 2",
                              @"iPad2,4":@"iPad 2",
                              @"iPad2,5":@"iPad Mini 1G",
                              @"iPad2,6":@"iPad Mini 1G",
                              @"iPad2,7":@"iPad Mini 1G",
                              @"iPad3,1":@"iPad 3",
                              @"iPad3,2":@"iPad 3",
                              @"iPad3,3":@"iPad 3",
                              @"iPad3,4":@"iPad 4",
                              @"iPad3,5":@"iPad 4",
                              @"iPad3,6":@"iPad 4",
                              @"iPad4,1":@"iPad Air",
                              @"iPad4,2":@"iPad Air",
                              @"iPad4,3":@"iPad Air",
                              @"iPad4,4":@"iPad Mini 2G",
                              @"iPad4,5":@"iPad Mini 2G",
                              @"iPad4,6":@"iPad Mini 2G",
                              @"i386":@"iPhone Simulator",
                              @"x86_64":@"iPhone Simulator"
                              };
    
    if ([dicInfo valueForKeyPath:platform]) {
        return [dicInfo valueForKeyPath:platform];
    } else {
        return platform;
    }
}

/**
 *  获取系统版本
 *
 */
+ (NSString *)getSystemName {
    return [[UIDevice currentDevice] systemVersion];
}

#pragma mark  - app

+ (void)openAPPComment:(NSString *)appid {
    NSString *str = [NSString stringWithFormat:
                     @"http://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?id=%@&pageNumber=0&sortOrdering=2&type=Purple+Software&mt=8",
                     appid];
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
}

+ (BOOL)appStoreWithAppId:(NSString *)appId {
    NSString *urlPath = [@"itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?id="
                         stringByAppendingString:appId];
    
    return [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlPath]];
}

+ (void)safari:(NSString *)urlString {
    NSURL *url = [[NSURL alloc] initWithString:urlString];
    
    [[UIApplication sharedApplication] openURL:url];
}

+(void)openSet
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
}

+ (BOOL)dial:(NSString *)tel {
    NSURL *url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"telprompt:%@", tel]];
    
    return [[UIApplication sharedApplication] openURL:url];
}

+ (BOOL)openApp:(NSString *)url {
    return [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
}

+ (NSString *)getAPPVersion {
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    
    return infoDic[@"CFBundleShortVersionString"];
}

+ (NSString *)getAPPBuild {
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    
    return infoDic[@"CFBundleVersion"];
}

+ (BOOL)haveQQ {
    return [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"mqq://"]];
}

+ (void)chatWithQQ:(NSString *)QQ {
    NSString *url = [NSString stringWithFormat:@"http://wpa.b.qq.com/cgi/wpa.php?ln=2&uin=%@", QQ];
    
    // http://wpa.b.qq.com/cgi/wpa.php?ln=2&uin=4007201188
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
}

#pragma mark  - app
+ (void)onceAction:(NSString *)key block:(Action)block {
    [AppUtil onceAction:key block:block otherBlock:^{}];
}

+ (void)onceAction:(NSString *)key block:(Action)block otherBlock:(Action)blockOther {
    NSString *VersionKey = [NSString stringWithFormat:@"v%@", [[NSBundle mainBundle] objectForInfoDictionaryKey:(NSString *)kCFBundleVersionKey]];
    
    NSString *key_ = @[[[self class] className], @"_", key, @"_DSWKey", VersionKey].joinedString;
    
    if (![[NSUserDefaults standardUserDefaults] boolForKey:key_]) {
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:key_];
        block();
    } else {
        blockOther();
    }
}

@end

