//
//  NSArray+DLog.h
//  qtyd
//
//  Created by stephendsw on 15/11/24.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import <Foundation/Foundation.h>

// 打印出中文
@interface NSArray (DLog)

@end

// 打印出中文
@interface NSDictionary (DLog)

@end
