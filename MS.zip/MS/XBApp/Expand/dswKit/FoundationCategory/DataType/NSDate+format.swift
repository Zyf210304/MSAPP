//
//  NSDate+format.swift
//  changfu
//
//  Created by stephen on 2017/9/11.
//  Copyright © 2017年 changfulicai. All rights reserved.
//

import Foundation

extension NSDate {
   
    var year:Int {
        get {
            let curCalendar:NSCalendar = NSCalendar.current as NSCalendar
            let componentYear:Int = curCalendar.component(NSCalendar.Unit.year, from: self as Date)
            return componentYear
        }
    }
    
    var month:Int {
        get {
            let curCalendar:NSCalendar = NSCalendar.current as NSCalendar
            let componentMonth:Int = curCalendar.component(NSCalendar.Unit.month, from: self as Date)
            return componentMonth
        }
    }

    var day:Int {
        get {
            let curCalendar:NSCalendar = NSCalendar.current as NSCalendar
            let componentDay:Int = curCalendar.component(NSCalendar.Unit.day, from: self as Date)
            return componentDay
        }
    }
    
    var hour:Int {
        get {
            let curCalendar:NSCalendar = NSCalendar.current as NSCalendar
            let componentHour:Int = curCalendar.component(NSCalendar.Unit.hour, from: self as Date)
            return componentHour
        }
    }
    
    var minute:Int {
        get {
            let curCalendar:NSCalendar = NSCalendar.current as NSCalendar
            let componentMinute:Int = curCalendar.component(NSCalendar.Unit.minute, from: self as Date)
            return componentMinute
        }
    }
    
    var second:Int {
        get {
            let curCalendar:NSCalendar = NSCalendar.current as NSCalendar
            let componentSecond:Int = curCalendar.component(NSCalendar.Unit.second, from: self as Date)
            return componentSecond
        }
    }

    /// yyyy-MM-dd HH:mm:ss
    var longTimeString: String {
        get {
            return string(format: "yyyy-MM-dd HH:mm:ss")
        }
    }
    
    /// yyyy年MM月dd日 HH:mm:ss
    var longChineseTimeString: String {
        get {
            return string(format: "yyyy年MM月dd日 HH:mm:ss")
        }
    }
    
    ///  yyyy-MM-dd
 
    var shortTimeString: String {
        get {
           return string(format: "yyyy-MM-dd")
        }
    }
    
    ///  yyyy年MM月dd日
    
    var shortChineseTimeString: String {
        get {
            return string(format: "yyyy年MM月dd日")
        }
    }
    
    /// HH:mm:ss
    var hourTimeString: String {
        get {
            return string(format: "HH:mm:ss")
        }
    }
    
    func string(format dateFormat: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = dateFormat
        return formatter.string(from: self as Date)
    }
    
    class func date(from dateString : String) -> Date? {
        if dateString.isMatch(kRegNumber) {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyyMMddHHmmss"
             return  formatter.date(from: dateString)!
        }
        else {
            let formatter = DateFormatter.sharedInstance()
            var date: Date?
            var formatList: [String] = ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "yyyy-MM","yyyy-MM-dd HH:mm:ss.SSS"]
            for i in 0..<formatList.count {
                formatter?.dateFormat = formatList[i]
                date = formatter?.date(from: dateString)
                if date != nil {
                    return date!
                }
            }
            return nil
        }
    }
    
    
}
