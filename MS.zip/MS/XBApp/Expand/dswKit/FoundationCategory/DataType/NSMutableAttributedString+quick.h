//
//  NSMutableString+quick.h
//  qtyd
//
//  Created by stephendsw on 15/9/24.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSMutableAttributedString (quick)

@property (readonly, nonatomic) CGSize size;

- (void)appendImageName:(NSString *_Nonnull)imageName;

- (void)appendImage:(UIImage *_Nonnull)image;

- (void)appendString:(NSString *_Nonnull)str;

/**
 *  链接线
 */
- (void)setLinkString:(NSString *_Nonnull)str;

/**
 *  中划线
 */
-(void)setStrikethrough:(NSString *_Nullable)str;

/**
 *  下划线
 */
- (void)setUnderlineString:(NSString *_Nonnull)str;

- (void)setColor:(UIColor *_Nonnull)color string:(NSString *_Nonnull)str;
- (void)setColor:(UIColor *_Nonnull)color;

- (void)setFont:(UIFont *_Nonnull)font string:(NSString *_Nonnull)str;
- (void)setFont:(UIFont *_Nonnull)font;

- (void)setParagraphStyle:(void (^_Nonnull)(NSMutableParagraphStyle * _Nonnull paragraph))block;

- (void)addHtml:(NSString *_Nonnull)htmlString;

/**
 *  文字背景
 */
- (void)setBackgroundColor:(UIColor *_Nonnull)color string:(NSString *_Nonnull)str;

/**
 *  改变文字间距
 */
- (void)setKern:(CGFloat)Kern string:(NSString *_Nonnull)str;

@end
