//
//  NSString+quick.m
//  Car_ZJ
//
//  Created by stephen on 15/3/9.
//  Copyright (c) 2015年 qtyd. All rights reserved.
//

#import "NSString+quick.h"
#import <CommonCrypto/CommonDigest.h>

@implementation NSString (quick)
@dynamic add;

- (NSString *(^)(NSObject *))add {
    return ^(NSObject *str) {
        if (!str) {
            str = @"";
            NSLog(@"================参数为nil==================");
        }
        
        return [self stringByAppendingFormat:@"%@", str];
    };
}

+ (NSString *)toJsonFromNSData:(id)object {
    if (!object) {
        return @"";
    }
    
    NSString    *jsonString = nil;
    NSError     *error;
    NSData      *jsonData = [NSJSONSerialization    dataWithJSONObject:object
                                                              options :NSJSONWritingPrettyPrinted   // Pass 0 if you don't care about the readability of the generated string
                                                              error   :&error];
    
    if (!jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@" " withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    return jsonString;
}

- (NSString *)filterHTML {
    NSString    *html = self;
    NSScanner   *scanner = [NSScanner scannerWithString:html];
    NSString    *text = nil;
    
    while ([scanner isAtEnd] == NO) {
        // 找到标签的起始位置
        [scanner scanUpToString:@"<" intoString:nil];
        // 找到标签的结束位置
        [scanner scanUpToString:@">" intoString:&text];
        // 替换字符
        html = [html stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@>", text] withString:@""];
    }
    
    //    NSString * regEx = @"<([^>]*)>";
    //    html = [html stringByReplacingOccurrencesOfString:regEx withString:@""];
    return html;
}

- (BOOL)containsString:(NSString *)content {
    if (![content isKindOfClass:[NSString class]]) {
        return NO;
    }
    
    NSRange range = [self rangeOfString:content];
    
    return range.location != NSNotFound;
}

+ (BOOL)isEmpty:(NSString *)str {
    NSString *string = str;
    
    if ((string == nil) || (string == NULL)) {
        return YES;
    }
    
    if ([string isKindOfClass:[NSNull class]]) {
        return YES;
    }
    
    if ([[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] == 0) {
        return YES;
    }
    
    return NO;
}

- (id)objectAtIndexedSubscript:(NSUInteger)idx {
    if (self.length <= idx) {
        return nil;
    } else {
        return [self substringWithRange:NSMakeRange(idx, 1)];
    }
}

- (BOOL)isEmoji {
    const unichar high = [self characterAtIndex: 0];
    
    // Surrogate pair (U+1D000-1F77F)
    if (0xd800 <= high && high <= 0xdbff) {
        const unichar low = [self characterAtIndex: 1];
        const int codepoint = ((high - 0xd800) * 0x400) + (low - 0xdc00) + 0x10000;
        
        return (0x1d000 <= codepoint && codepoint <= 0x1f77f);
        
        // Not surrogate pair (U+2100-27BF)
    } else {
        return (0x2100 <= high && high <= 0x27bf);
    }
}

- (BOOL)isIncludingEmoji {
    BOOL __block result = NO;
    
    [self enumerateSubstringsInRange:NSMakeRange(0, [self length])
                             options:NSStringEnumerationByComposedCharacterSequences
                          usingBlock: ^(NSString* substring, NSRange substringRange, NSRange enclosingRange, BOOL* stop) {
                              if ([substring isEmoji]) {
                                  *stop = YES;
                                  result = YES;
                              }
                          }];
    
    return result;
}

- (NSString *)safeNumbers {
    if([self isKindOfClass:[NSString class]])
        return [[self componentsSeparatedByCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet]] componentsJoinedByString:@""];
    else return @"";
    
}



@end
