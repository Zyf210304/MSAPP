//
//  NSString+quick.h
//  Car_ZJ
//
//  Created by stephen on 15/3/9.
//  Copyright (c) 2015年 qtyd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+regularExpression.h"
#import <UIKit/UIKit.h>

typedef NSString *(^ mapStrBlock)(NSString *value);

@interface NSString (quick)

@property(nonatomic, readonly) NSString *(^add)(NSObject *str);

- (id)objectAtIndexedSubscript:(NSUInteger)idx;

- (BOOL)isEmoji ;

- (BOOL)isIncludingEmoji;

+ (BOOL)isEmpty:(NSString *)str;

- (NSString *)safeNumbers;

#pragma mark 编码

- (NSString *)filterHTML;

#pragma mark tojsonString

+ (NSString *)toJsonFromNSData:(id)object;

@end
