//
//  NSDateFormatter+quick.h
//  qtyd
//
//  Created by stephendsw on 2016/11/1.
//  Copyright © 2016年 qtyd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDateFormatter (quick)

+ (instancetype)sharedInstance;

@end
