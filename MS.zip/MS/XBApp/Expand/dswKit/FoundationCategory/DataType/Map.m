//
//  Map.m
//  changfu
//
//  Created by stephen on 2017/9/13.
//  Copyright © 2017年 changfulicai. All rights reserved.
//

#import "Map.h"

@implementation Map
{
    NSDictionary *data;
}

- (instancetype)init {
    self = [super init];
    
    if (self) {
        data = [NSDictionary new];
    }
    
    return self;
}

- (instancetype)initWithData:(NSDictionary *)obj {
    self = [super init];
    
    if (self) {
        data = obj;
        
        if (!data) {
            data = [NSDictionary new];
        }
    }
    
    return self;
}

- (NSString *)str:(NSString *)keypath {
    id temp = data.str(keypath);
    
    if (temp) {
        return temp;
    } else {
        return @"";
    }
}

- (NSArray *)arr:(NSString *)keypath {
    id temp = data.arr(keypath);
    
    if (temp) {
        return temp;
    } else {
        return [NSArray new];
    }
}

- (Map *)map:(NSString *)keypath {
    id temp = [[Map alloc]initWithData:data.dic(keypath)];
    
    if (temp) {
        return temp;
    } else {
        return [Map new];
    }
}

- (NSNumber *)num:(NSString *)keypath {
    id temp = data.num(keypath);
    
    if (temp) {
        return temp;
    } else {
        return [NSNumber numberWithInt:0];
    }
}

- (float)fl:(NSString *)keypath {
    if (data.fl(keypath)) {
        return data.fl(keypath);
    } else {
        return 0;
    }
}

- (double)dou:(NSString *)keypath {
    if (data.d(keypath)) {
        return data.d(keypath);
    } else {
        return 0;
    }
}

- (NSInteger)i:(NSString *)keypath {
    if (data.i(keypath)) {
        return data.i(keypath);
    } else {
        return 0;
    }
}

- (NSDate *)date:(NSString *)keypath {
    id temp = data.date(keypath);
    
    if (temp) {
        return temp;
    } else {
        return [NSDate new];
    }
}

- (id)objectForKeyedSubscript:(NSString *)key {
    return [data valueForKeyPath:key];
}

- (void)setObject:(id)obj forKeyedSubscript:(NSString *)key {
    if ([data isKindOfClass:[NSMutableDictionary class]]) {
        [data setValue:obj forKey:(NSString *)key];
    }
}

@end
