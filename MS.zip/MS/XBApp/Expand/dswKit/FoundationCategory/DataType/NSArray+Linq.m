//
//  NSArray+Linq.m
//  linq
//
//  Created by stephendsw on 15/8/26.
//  Copyright (c) 2015年 qtyd. All rights reserved.
//

#import "NSArray+Linq.h"

@implementation NSArray (Linq)

- (BOOL)any:(NSString *)condition {
    NSArray *temp = [self where:condition];

    if (temp.count > 0) {
        return YES;
    } else {
        return NO;
    }
}

- (NSArray *)where:(NSString *)condition {
    NSPredicate *pre = [NSPredicate predicateWithFormat:condition];

    return [self filteredArrayUsingPredicate:pre];
}

- (id)single:(NSString *)condititon {
    NSArray *list = [self where:condititon];

    if (list.count > 0) {
        return list.firstObject;
    } else {
        return nil;
    }
}

/**
 *  排序
 *
 *  @param asc       yes 升序  no 降序
 *
 */
- (id)sort:(NSString *)condition ascending:(BOOL)asc {
    NSSortDescriptor    *sd1 = [NSSortDescriptor sortDescriptorWithKey:condition ascending:asc];
    NSArray             *arr1 = [self sortedArrayUsingDescriptors:[NSArray arrayWithObjects:sd1, nil]];

    return arr1;
}

- (id)min:(NSString *)condition {
    // 降序
    NSSortDescriptor    *sd1 = [NSSortDescriptor sortDescriptorWithKey:condition ascending:NO];
    NSArray             *arr1 = [self sortedArrayUsingDescriptors:[NSArray arrayWithObjects:sd1, nil]];

    return arr1.firstObject;
}

- (id)max:(NSString *)condition {
    // 降序
    NSSortDescriptor    *sd1 = [NSSortDescriptor sortDescriptorWithKey:condition ascending:NO];
    NSArray             *arr1 = [self sortedArrayUsingDescriptors:[NSArray arrayWithObjects:sd1, nil]];

    return arr1.lastObject;
}

- (NSArray *)map:(mapBlock)block {
    NSMutableArray *array = [NSMutableArray array];

    for (int i = 0; i < self.count; i++) {
        if (block(self[i])) {
            [array addObject:block(self[i])];
        }
    }

    return array;
}

- (NSArray *)getArrayForKey:(NSString *)keypath {
    NSMutableArray *array = [NSMutableArray new];

    if (!self) {
        return nil;
    }

    if (self.count == 0) {
        return nil;
    }

    for (NSDictionary *dic in self) {
        if ([dic isKindOfClass:[NSDictionary class]]) {
            if ([dic containsKey:keypath]) {
                [array addObject:[dic valueForKeyPath:keypath]];
            }
        }
    }

    return array;
}

- (NSString *)joinedString {
    return [self componentsJoinedByString:@""];
}

- (NSString *)convertToJSONData {
    NSError *error;
    NSData  *jsonData = [NSJSONSerialization    dataWithJSONObject:self
                                                          options :NSJSONWritingPrettyPrinted       // Pass 0 if you don't care about the readability of the generated string
                                                          error   :&error];
    
    NSString *jsonString = @"";
    
    if (!jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    
    jsonString = [jsonString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];  // 去除掉首尾的空白字符和换行字符
    
    [jsonString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    return jsonString;
}

@end
