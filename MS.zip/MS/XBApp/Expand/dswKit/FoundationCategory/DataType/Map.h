//
//  Map.h
//  changfu
//
//  Created by stephen on 2017/9/13.
//  Copyright © 2017年 changfulicai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Map : NSObject

- (instancetype __nonnull)initWithData:(NSDictionary *_Nullable)obj;

- (NSString *__nonnull)str:(NSString *__nonnull)keypath;

- (NSArray *__nonnull)arr:(NSString *__nonnull)keypath;

- (Map *__nonnull)map:(NSString *__nonnull)keypath;

- (NSNumber *__nonnull)num:(NSString *__nonnull)keypath;

- (float)fl:(NSString *__nonnull)keypath;

- (double)dou:(NSString *__nonnull)keypath;

- (NSInteger)i:(NSString *__nonnull)keypath;

- (NSDate *__nonnull)date:(NSString *__nonnull)keypath;

- (id _Nonnull)objectForKeyedSubscript:(NSString *_Nonnull)key;

- (void)setObject:(id _Nonnull)obj forKeyedSubscript:(NSString *_Nonnull)key;

@end
