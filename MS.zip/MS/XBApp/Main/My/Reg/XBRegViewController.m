//
//  XBRegViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/6.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBRegViewController.h"
#import <GTSDK/GeTuiSdk.h>
#import "TimeCodeButton.h"


@interface XBRegViewController ()

@property (weak, nonatomic) WTReTextField       *tfName;

@property (weak, nonatomic)  WTReTextField      *tfPhone;
@property (weak, nonatomic)  WTReTextField      *tfValidCode;

@property (weak, nonatomic)  WTReTextField      *tfpwd;

@property (weak, nonatomic)  WTReTextField      *tfMember;

@property (nonatomic, strong) TimeCodeButton    *btnCode;
@property (nonatomic, strong) UIButton          *btnClick;

@end

@implementation XBRegViewController
{
    DGridView * grid;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"手机注册";
}

-(void)initUI {
    [self initScrollView];
    [self setRefreshScrollView];
    self.scrollview.backgroundColor=[UIColor whiteColor];
    
    grid = [[DGridView alloc]initWidth:APP_WIDTH];
    
    [grid setColumn:16 height:50];
    
    grid.backgroundColor=[UIColor whiteColor];
    
    [grid addLineForHeight:10 color:[Theme backgroundColor]];
    
    self.tfName = [grid addRowInput:@"用户名" placeholder:@"请输入用户名"];
    
   self.tfPhone=  [grid addRowInput:@"手机号  " placeholder:@"请输入手机号码"];
    WEAKSELF;
    
    self.tfValidCode = [grid addRowCodeText:^(id value) {
        [weakSelf clickSendMsg:value];
    }];
    
    self.tfMember= [grid addRowInput:@"代理人  " placeholder:@"选填"];
    
    self.tfpwd = [grid addRowInput:@"密码     " placeholder:@"新密码"];
    
    [grid addLineForHeight:60];
    
    self.btnClick= [grid addRowButtonTitle:@"确定" click:^(id value) {
        [weakSelf commonJsonSubmit];
    }];
    
    [self.scrollview addSubview:grid];
    [self.scrollview autoContentSize];
    
}

-(void)initData{
    
    [self.tfPhone setPhone];
    self.tfPhone.group = 1;
    
    
    [self.tfpwd setPwd];
    self.tfpwd.group=0;

    [self.tfValidCode setValidationCode];
    self.tfValidCode.group = 1;

    for (UIView *item in self.tfValidCode.superview.subviews) {
        if ([item isKindOfClass:[TimeCodeButton class]]) {
            self.btnCode = (TimeCodeButton *)item;
        }
    }
    
    [self.view validation:1 fail:^(id value) {
        //[QTTheme btnGrayStyle:self.btnClick];
        
        if (self.tfPhone.text.length == 11) {
            self.btnCode.disabled = NO;
        } else {
            self.btnCode.disabled = YES;
        }
    } success:^(id value) {
        if ([self.view validationData:0]) {
            //[QTTheme btnThemeStyle:self.btnClick];
            self.btnCode.disabled = NO;
        }
    }];
    

}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self setWhiteNavigation];
}



// 发送验证码
- (void)clickSendMsg:(id)value {
    if (![self.view validationText:self.tfPhone]) {
        self.btnCode.enabled = YES;
        return;
    }
    
    [self.view endEditing:YES];
    
    [self commonJsonMsg];
}

#pragma mark - json

- (void)commonJsonSubmit {
    [self.view endEditing:YES];
    [self showHUD];
    [self.view endEditing:YES];
    NSMutableDictionary *dic = [NSMutableDictionary new];
    dic[@"autoCode"] =self.tfValidCode.text;
    dic[@"member_psw"] = self.tfpwd.text;
    dic[@"phone_no"] = self.tfPhone.text;
    dic[@"push_code"] = self.tfPhone.text;
    dic[@"register_ip"] = [IPHelper deviceIPAdress];
    dic[@"invite_code"] = self.tfMember.text;
    dic[@"name"] = self.tfName.text;
    if (self.tfName.text.length < 1) {
        [self showHint:@"请输入用户名"];
        return;
    }
    [service post:@"/v1/member/register" data:dic  complete:^(NSDictionary *value) {
        [self hideHUD];
        [self showHUD:@"注册成功"];
        [self.navigationController popViewControllerAnimated:YES];
    }];
    

}

- (void)commonJsonMsg {
    [self showHUD];
    NSMutableDictionary *dic = [NSMutableDictionary new];
    dic[@"phone_no"] = self.tfPhone.text;

    [service post:@"v1/member/send/message/register" data:dic complete:^(id value) {
        [self hideHUD];
        self.btnCode.enabled = NO;
    }];
}



@end
