//
//  XBAccountBillViewControllerCell.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBAccountBillViewControllerCell.h"

@interface XBAccountBillViewControllerCell  ()


@property (weak, nonatomic) IBOutlet UILabel *lbMoney;

@property (weak, nonatomic) IBOutlet UILabel *lbName;

@property (weak, nonatomic) IBOutlet UILabel *lbState;

@property (weak, nonatomic) IBOutlet UILabel *lbTime;

@end


@implementation XBAccountBillViewControllerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
}

-(void)bind:(NSDictionary *)obj{
    
    self.lbState.text=obj.str(@"change_name");
    
    NSMutableAttributedString * atr = [[NSMutableAttributedString alloc]init];
    
    [atr appendString:[NSString stringWithFormat:@"带红%@人  ",obj.str(@"red_people")]];
    [atr setColor:[Theme themeColor] string:obj.str(@"red_people")];
    
    NSMutableAttributedString * atr1 = [[NSMutableAttributedString alloc]init];
    
    [atr1 appendString:[NSString stringWithFormat:@"粉丝%@人",obj.str(@"fans")]];
    [atr1 setColor:[Theme themeColor] string:obj.str(@"fans")];
    [atr appendAttributedString:atr1];
    self.lbName.attributedText=atr;
    
    NSMutableAttributedString * atr3 = [[NSMutableAttributedString alloc]init];
    
    [atr3 appendString:[NSString stringWithFormat:@"%@ %@元",obj.str(@"fans"),obj.str(@"fans")]];
    [atr3 setColor:[Theme themeColor] string:obj.str(@"fans")];
    
    self.lbMoney.attributedText=atr1;
    
    
    self.lbTime.text=[NSDate dateWithTimeIntervalSince1970:obj.str(@"asset_time").integerValue].longTimeString;
    
}
@end
