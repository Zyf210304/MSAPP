//
//  XBAddBankViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBAddBankViewController.h"

@interface XBAddBankViewController ()

@property (weak, nonatomic)  WTReTextField      *tfName;

@property (weak, nonatomic)  WTReTextField      *tfCard;

@property (weak, nonatomic)  WTReTextField      *tfBank;

@end

@implementation XBAddBankViewController
{
    DGridView * grid;
    
    UILabel * label;
    
    NSArray * bankData;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationItem.title = _isEdit ? @"修改银行卡" : @"添加银行卡";
    
    
}

-(void)initUI{
    [self initScrollView];
    
    WEAKSELF;
    
    self.scrollview.backgroundColor = [UIColor whiteColor];
    
    grid = [[DGridView alloc]initWidth:APP_WIDTH];
    
    grid.backgroundColor = [UIColor whiteColor];
    [grid setColumn:16 height:50];
    
    
//    label=[grid addRowLabel:@"充值金额：0.01元"];
//
//    [grid addLineForHeight:10];
    self.tfBank = [grid  addRowInput:@"银行卡" placeholder:@"选择银行卡"];
    
    
    self.tfName = [grid  addRowInput:@"姓名" placeholder:@""];
    
    
    self.tfCard = [grid  addRowInput:@"卡号" placeholder:@"请填写本人银行卡号"];
    
    [grid addLineForHeight:30];
    [grid addRowButtonTitle:@"下一步" click:^(id value) {
        [weakSelf.view endEditing:YES];
        if (_isEdit) {
            [weakSelf editCardNetWork];
        } else {
            [weakSelf commonJsonSubmint];
        }
        
    }];
    
    
    
    [self.scrollview addSubview:grid];
    
    
    [self.scrollview autoContentSize];
}


- (void)initData {
    [self.tfName setRealName];
    self.tfName.group = 1;
    
    
    
    [self.tfCard setBankCard];
    self.tfCard.group=1;
    

    if (_isEdit) {
        self.tfCard.text= [NSString stringWithFormat:@"%@", _obj.str(@"bank_no")];
        self.tfBank.text= _obj.str(@"bank_name");
    }
   
    
    
    [self firstGetData];
}



- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

#pragma mark - json

//获取 银行列表
-(void)commonJson
{
    [self showHUD];
    
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    [service post:@"/v1/member/bank/card/add" data:dic complete:^(NSDictionary *value) {
        [self hideHUD];
        
        NSArray * array= [value .arr(@"bankList") getArrayForKey:@"bank_name"];
        bankData=value .arr(@"bankList");
        [self.tfBank setInputDropList:array];
        
        if (!_isEdit) {
            self.tfName.text=value.str(@"real_name");
            self.tfName.enabled=NO;
        }
        
        
    }];
}



- (void)commonJsonSubmint {
    
    
    [self showHUD];
    
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    
    dic[@"bank_no"]= [self.tfCard.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    for (NSDictionary * item in bankData) {
        if ([item.str(@"bank_name") isEqualToString:self.tfBank.text]) {
            dic[@"bank_id"]=item.str(@"id");
        }
    }
    
    [service post:@"/v1/member/bank/card/addsub" data:dic  complete:^(NSDictionary *value) {
        
        [self hideHUD];
        [self.navigationController popViewControllerAnimated:YES];
    }];
    
}

- (void)editCardNetWork {
    [self showHUD];
    
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    
    dic[@"bank_no"]=self.tfCard.text;
    for (NSDictionary * item in bankData) {
        if ([item.str(@"bank_name") isEqualToString:self.tfBank.text]) {
            dic[@"bank_id"]=item.str(@"id");
        }
    }
    dic[@"member_bank_id"] = _obj[@"member_bank_id"];
    
    
    [service post:@"v1/member/bank/card/edit/sub" data:dic  complete:^(NSDictionary *value) {
        
        [self hideHUD];
        [self.navigationController popToRootViewControllerAnimated:YES];
    }];
}



@end
