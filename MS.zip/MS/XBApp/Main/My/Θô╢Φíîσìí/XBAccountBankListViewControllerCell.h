//
//  XBAccountBankListViewControllerCell.h
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "DTableViewCell.h"

@interface XBAccountBankListViewControllerCell : DTableViewCell

@property (nonatomic, copy) void(^deleteCardBlock)(NSString *member_bank_id);

@end
