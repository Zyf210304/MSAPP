//
//  XBAccountIssueViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBAccountIssueViewController.h"
#import "XBAccountIssueViewControllerCell.h"
#import "QTBaseViewController+Table.h"

@interface XBAccountIssueViewController ()

@end

@implementation XBAccountIssueViewController
{
   
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"常见问题";
    
     TABLEReg(XBAccountIssueViewControllerCell, @"XBAccountIssueViewControllerCell");
}

-(void)initUI {
    
    self.canRefresh = YES;
    [self initTable];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor=[Theme borderColor];
    self.tableView.separatorInset=UIEdgeInsetsMake(0, 15, 0, 0);
    
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 116;
    
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, FRAME_WIDTH, 50)];
    UILabel *phoneTitle = [[UILabel alloc] init];
    phoneTitle.text = @"客服电话";
    phoneTitle.textColor = Color_title_333;
    phoneTitle.font = [UIFont systemFontOfSize:15 *SCALE_375];
    [footerView addSubview:phoneTitle];
    [phoneTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(10 *SCALE_375);
        make.centerY.equalTo(footerView.mas_centerY);
    }];
    
    UILabel *phoneNum = [[UILabel alloc] init];
    phoneNum.text = @"17857310523";
    phoneNum.textColor = Color_Main;
    phoneNum.font = [UIFont systemFontOfSize:15 *SCALE_375];
    [footerView addSubview:phoneNum];
    [phoneNum mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-10 *SCALE_375);
        make.centerY.equalTo(footerView.mas_centerY);
    }];
    self.tableView.tableFooterView = footerView;
    
}

-(void)initData{
    [self firstGetData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

#pragma  mark - table

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *Identifier = @"XBAccountIssueViewControllerCell";
    XBAccountIssueViewControllerCell   *cell = [tableView dequeueReusableCellWithIdentifier:Identifier forIndexPath:indexPath];
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    
    [cell bind:dic];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    
}


#pragma mark - json

-(NSString *)listKey
{
    return @"list";
}

- (void)commonJson {
//    NSMutableDictionary *dic = [NSMutableDictionary new];
//
//    dic[@"page_num"] = self.current_page;
//    dic[@"page_size"] = PAGES_SIZE;
//
//    [service post:@"/v1/member/findTranslationDetails" data:dic  complete:^(NSDictionary *value) {
//
//    }];
    [self hideHUD];
}


@end
