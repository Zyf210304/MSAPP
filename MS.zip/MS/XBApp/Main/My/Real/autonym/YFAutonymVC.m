//
//  YFAutonymVC.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/31.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFAutonymVC.h"

@interface YFAutonymVC ()

@property (nonatomic, strong) UIView *topView;

@property (nonatomic, strong) UILabel *namelBL;

@property (nonatomic, strong) UILabel *numberLBl;

@end

@implementation YFAutonymVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self initUI];
}


- (void)initUI  {
    [self addHeader];
    [self addAboutName];
    [self addAboutNumber];
    [self addBackLbl];
}


- (void)addHeader {
    UIView *topView = [[UIView alloc] init];
    [self.view addSubview:topView];
    _topView = topView;
    [topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(0);
        make.left.right.mas_offset(0);
        make.height.mas_offset(193 *SCALE_375);
    }];
    topView.layer.contents = (id)[UIImage imageNamed:@"accountBG"].CGImage;
    
    UIImageView *crditImg = [[UIImageView alloc] init];
    [topView addSubview:crditImg];
    crditImg.image = [UIImage imageNamed:@"credit_icon"];
    [crditImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(77 *SCALE_375);
        make.bottom.mas_offset(- 62 *SCALE_375);
        make.width.mas_offset(39 *SCALE_375);
        make.height.mas_offset(44 *SCALE_375);
    }];
    
    UILabel *title = [[UILabel alloc] init];
    [self.view addSubview:title];
    title.textColor = [UIColor whiteColor];
    title.text = @"认证成功！";
    title.font = [UIFont systemFontOfSize:38 *SCALE_375];
    [title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(crditImg.mas_right).offset(20 *SCALE_375);
        make.centerY.equalTo(crditImg.mas_centerY);
    }];
    
    
    UIImageView *backImg  = [[UIImageView alloc] init];
    [topView addSubview:backImg];
    backImg.image = [UIImage imageNamed:@"back_white"];
    [backImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(20 *SCALE_375);
        make.width.height.mas_offset(20 *SCALE_375);
        make.top.mas_offset(Statur_HEIGHT + 12);
    }];
    [backImg addTapgestureWithTarget:self action:@selector(backAction:)];
}


- (void)addAboutName {
    
    UILabel *nameTitle = [[UILabel alloc] init];
    [self.view addSubview:nameTitle];
    nameTitle.text = @"姓名:";
    nameTitle.font = [UIFont systemFontOfSize:14 *SCALE_375];
    nameTitle.textColor = Color_title_333;
    [nameTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(22 *SCALE_375);
        make.top.equalTo(_topView.mas_bottom).offset(33 *SCALE_375);
    }];
    
    UILabel *namelBL = [[UILabel alloc] init];
    [self.view addSubview:namelBL];
    _namelBL = namelBL;
    namelBL.text = _name;
    namelBL.textColor = Color_title_333;
    namelBL.font = [UIFont boldSystemFontOfSize:15 *SCALE_375];
    [namelBL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(nameTitle.mas_right).offset(25 *SCALE_375);
        make.bottom.equalTo(nameTitle.mas_bottom);
    }];
    
    UIView *lineView = [[UIView alloc] init];
    [self.view addSubview:lineView];
    lineView.backgroundColor = UIColorFromRGB(0xe5e5e5);
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_topView.mas_bottom).offset(67 *SCALE_375);
        make.height.mas_offset(SCALE_375);
        make.left.mas_offset(22 *SCALE_375);
        make.right.mas_offset(- 0 *SCALE_375);
    }];
}

- (void)addAboutNumber {
    UILabel *nameTitle = [[UILabel alloc] init];
    [self.view addSubview:nameTitle];
    nameTitle.text = @"身份证号:";
    nameTitle.font = [UIFont systemFontOfSize:14 *SCALE_375];
    nameTitle.textColor = Color_title_333;
    [nameTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(22 *SCALE_375);
        make.top.equalTo(_topView.mas_bottom).offset(87 *SCALE_375);
    }];
    
    UILabel *namelBL = [[UILabel alloc] init];
    [self.view addSubview:namelBL];
    _numberLBl = namelBL;
    namelBL.textColor = Color_title_333;
    namelBL.text = _number;
    namelBL.font = [UIFont boldSystemFontOfSize:15 *SCALE_375];
    [namelBL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(nameTitle.mas_right).offset(25 *SCALE_375);
        make.bottom.equalTo(nameTitle.mas_bottom);
    }];
    
}

- (void)addBackLbl {
    
    UILabel *backLbl = [[UILabel alloc] init];
    [self.view addSubview:backLbl];
    backLbl.backgroundColor = UIColorFromRGB(0xFF373D);
    backLbl.textColor = [UIColor whiteColor];
    backLbl.font = [UIFont systemFontOfSize:18 *SCALE_375];
    backLbl.textAlignment = NSTextAlignmentCenter;
    backLbl.text = @"返回";
    [backLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_topView.mas_bottom).offset(159 *SCALE_375);
        make.width.mas_offset(326 *SCALE_375);
        make.height.mas_offset(43 *SCALE_375);
        make.centerX.equalTo(self.view.mas_centerX);
    }];
    
    [backLbl addTapgestureWithTarget:self action:@selector(backAction:)];
}



- (void)backAction:(UITapGestureRecognizer *)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
