//
//  YFAutonymVC.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/31.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFAutonymVC : UIViewController

@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) NSString *number;

@end
