//
//  XBRealViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/6.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBRealViewController.h"

#import "YFAutonymVC.h"
@interface XBRealViewController ()

@property (strong, nonatomic) IBOutlet UIImageView *imageReal;


@property (weak, nonatomic)  WTReTextField      *tfName;

@property (weak, nonatomic)  WTReTextField      *tfCard;

@end

@implementation XBRealViewController
{
    DGridView * grid;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"实名认证";
}

-(void)initUI {
    [self initScrollView];
    [self setRefreshScrollView];
    
    grid = [[DGridView alloc]initWidth:APP_WIDTH];
    
    [grid setColumn:16 height:50];
    
    [grid addView:self.imageReal margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
   self.tfName= [grid addRowInput:@"    姓名  " placeholder:@"请输入姓名"];
    
   self.tfCard= [grid addRowInput:@"身份证  " placeholder:@"请输入身份证"];
    
    [grid addLineForHeight:30];
    
    
    [grid addRowButtonTitle:@"确定" click:^(id value) {
        [self click];
    }];
    
    [self.scrollview addSubview:grid];
    [self.scrollview autoContentSize];
    
}

-(void)initData{
    [self.tfName setRealName];
    
    [self.tfCard setIDCard];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}


-(void)click
{
    if ([self.view validation:0]) {
        [self commonJsonSubmit];
    }
    
}

#pragma mark - json

- (void)commonJsonSubmit {
     [self showHUD];

    NSMutableDictionary *dic=[NSMutableDictionary new ];
    
    dic[@"member_card"]=self.tfCard.text;
    dic[@"real_name"]=self.tfName.text;
    
   
    [service post:@"/v1/member/insertCardNum" data:dic  complete:^(NSDictionary *value) {
        [self hideHUD];
        
        [self showToast:@"实名认证成功" done:^{
            YFAutonymVC *autonym =  [[YFAutonymVC alloc] init];
            autonym.name = self.tfName.text;
            autonym.number = self.tfCard.text;
            [self.navigationController pushViewController:autonym animated:YES];
        }];
       
    }];
    
}


@end
