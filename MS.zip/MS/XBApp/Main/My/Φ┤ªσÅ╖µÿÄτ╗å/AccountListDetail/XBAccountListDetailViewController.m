//
//  XBAccountListDetailViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBAccountListDetailViewController.h"

@interface XBAccountListDetailViewController ()
@property (strong, nonatomic) IBOutlet UIImageView *bottomView;

@end

@implementation XBAccountListDetailViewController
{
    DGridView * grid;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"明细详情";
}

-(void)initUI {
    [self initScrollView];
    //[self setRefreshScrollView];
    
    grid = [[DGridView alloc]initWidth:APP_WIDTH];
    
    self.scrollview.backgroundColor=[UIColor whiteColor];
    
    grid.backgroundColor=[UIColor whiteColor];
    
    [grid setColumn:16 height:50];
    
    [grid addRowLabel:@"交易类型" text:self.obj.str(@"change_name")];
    
     [grid addRowLabel:@"支出金额" text:self.obj.strMoney(@"change_amount")];
    
     [grid addRowLabel:@"彩金抵扣" text:self.obj.strMoney(@"color_gold")];
    
     [grid addRowLabel:@"交易时间" text:[NSDate dateWithTimeIntervalSince1970:self.obj.str(@"asset_time").integerValue].longTimeString];
    
     [grid addRowLabel:@"账户总额" text:self.obj.strMoney(@"account")];
    
     [grid addRowLabel:@"备注" text:self.obj.str(@"chang_remark")];
    
    [grid addLineForHeight:20];
    
    [grid addView:self.bottomView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    [self.scrollview addSubview:grid];
    [self.scrollview autoContentSize];
    
}

-(void)initData{
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

#pragma mark - json



@end
