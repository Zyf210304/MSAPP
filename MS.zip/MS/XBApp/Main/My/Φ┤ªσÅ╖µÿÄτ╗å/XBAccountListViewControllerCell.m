//
//  XBAccountListViewControllerCell.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBAccountListViewControllerCell.h"

@interface XBAccountListViewControllerCell  ()

@property (weak, nonatomic) IBOutlet UILabel *lbName;
@property (weak, nonatomic) IBOutlet UILabel *lbTIme;
@property (weak, nonatomic) IBOutlet UILabel *lbMoney;


@end


@implementation XBAccountListViewControllerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
}

-(void)bind:(NSDictionary *)obj{
    //1 充值  3提现 2代购
    self.lbName.text=obj.str(@"change_name");
    NSNumber *change_type = obj[@"change_type"];
    switch (change_type.integerValue) {
        case 1:
            _lbName.text = @"充值";
            break;
        case 2:
            _lbName.text = @"提现";
            break;
        case 3:
            _lbName.text = @"购彩支付";
            break;
        case 4:
            _lbName.text = @"中奖";
            break;
        default:
            break;
    }
    self.lbMoney.text=obj.strMoney(@"change_amount");

    self.lbTIme.text=[NSDate dateWithTimeIntervalSince1970:obj.str(@"asset_time").integerValue / 1000].longTimeString;
    
}

@end
