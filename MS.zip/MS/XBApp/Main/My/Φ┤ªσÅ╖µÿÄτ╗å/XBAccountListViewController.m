//
//  XBAccountListViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBAccountListViewController.h"
#import "XBAccountListViewControllerCell.h"
#import "QTBaseViewController+Table.h"
#import "XBAccountListDetailViewController.h"

@interface XBAccountListViewController ()

@end

@implementation XBAccountListViewController
{
    __weak IBOutlet UILabel *lbMoney1;
    
    __weak IBOutlet UILabel *lbMoney2;
    
    IBOutlet UIView *headView;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"账户明细";
    
     TABLEReg(XBAccountListViewControllerCell, @"XBAccountListViewControllerCell");
}

-(void)initUI {
    
    self.canRefresh = YES;
    [self initTable];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor=[Theme borderColor];
    self.tableView.separatorInset=UIEdgeInsetsMake(0, 15, 0, 0);
    
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 116;
    
    [self addHeadView:headView];
    

}

-(void)initData{
    [self firstGetData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

#pragma  mark - table

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *Identifier = @"XBAccountListViewControllerCell";
    XBAccountListViewControllerCell   *cell = [tableView dequeueReusableCellWithIdentifier:Identifier forIndexPath:indexPath];
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    
    [cell bind:dic];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
//    NSDictionary *dic = self.tableDataArray[indexPath.row];
//    
//    XBAccountListDetailViewController * conroller = [XBAccountListDetailViewController controllerFromXib];
//    conroller.obj=dic;
//    
//    [NAVIGATION pushViewController:conroller animated:YES];
    
}


#pragma mark - json

-(NSString *)listKey
{
    return @"list";
}

- (void)commonJson {
    NSMutableDictionary *dic = [NSMutableDictionary new];
    
    dic[@"page_num"] = self.current_page;
    dic[@"page_size"] = PAGES_SIZE;

    
    [service post:@"v1/member/findTranslationDetails" data:dic  complete:^(NSDictionary *value) {
        
        
        NSMutableAttributedString * m1=[[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"账户总额 %@ 元",value.str(@"account")]];
        [m1 setColor:[Theme themeColor] string:value.str(@"account")];
        
        lbMoney1.attributedText=m1;
        
        NSMutableAttributedString * m2=[[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"可提现金额 %@ 元",value.str(@"amount")]];
        [m2 setColor:[Theme themeColor] string:value.str(@"amount")];
        lbMoney2.attributedText=m2;
        
        [self tableHandleValue:value];
    }];
    
    
}





@end
