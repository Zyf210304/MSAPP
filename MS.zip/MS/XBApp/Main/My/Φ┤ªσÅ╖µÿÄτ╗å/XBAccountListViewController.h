//
//  XBAccountListViewController.h
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "QTBaseViewController.h"

@interface XBAccountListViewController : QTBaseViewController

@end
