//
//  XBChangePassViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/6.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBChangePassViewController.h"

@interface XBChangePassViewController ()

@property (strong, nonatomic) IBOutlet UIView *viewForget;

@property (weak, nonatomic)  WTReTextField      *tfold;

@property (weak, nonatomic)  WTReTextField      *tfnew;

@property (weak, nonatomic)  WTReTextField      *tfnew2;


@end

@implementation XBChangePassViewController
{
    DGridView * grid;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"修改登录密码";
}

-(void)initUI {
    [self initScrollView];
    [self setRefreshScrollView];
    self.scrollview.backgroundColor=[UIColor whiteColor];
   
    
    grid = [[DGridView alloc]initWidth:APP_WIDTH];
    
    [grid setColumn:16 height:50];
    
    grid.backgroundColor=[UIColor whiteColor];
    
     [grid addLineForHeight:10];
    
    self.tfold= [grid addRowInput:@"原始密码" placeholder:@"请输入原始密码"];
    WEAKSELF;

   self.tfnew= [grid addRowInput:@"新密码    " placeholder:@"新密码"];
    
    self.tfnew2= [grid addRowInput:@"确认密码" placeholder:@"确认密码"];
    
    [grid addLineForHeight:30];
    
    [grid addRowButtonTitle:@"确定" click:^(id value) {
        [self click];
    }];
    
    [grid addView:self.viewForget margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    

    
    [self.scrollview addSubview:grid];
    [self.scrollview autoContentSize];
    
}

-(void)initData{
    
    [self.tfold setPwd];
    
     [self.tfnew2 setPwd];
    
     [self.tfnew setPwd];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self setWhiteNavigation];
}
- (IBAction)forgetClick:(id)sender {
    
     [self toPageForgetPassword];
}

-(void)click
{
    
    
    
    if ([self.view validation:0]) {
        
        if (![self.tfnew.text isEqualToString:self.tfnew2.text]) {
            [self showToast:@"新密码和确认密码不相同"];
            return;
        }
        
        [self commonJsonSubmit];
    }
    
}

#pragma mark - json

- (void)commonJsonSubmit {
    [self showHUD];
    
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    
    dic[@"member_psw"]=self.tfold.text;
    dic[@"new_member_psw"]=self.tfnew.text;
    
    
    [service post:@"/v1/member/updateMemPsw" data:dic  complete:^(NSDictionary *value) {
        [self hideHUD];
        
        [self showToast:@"修改密码成功" done:^{
            [NAVIGATION popViewControllerAnimated:YES];
        }];
        
    }];
    
}
    


@end
