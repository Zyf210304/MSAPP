//
//  XBForgetPassViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/6.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBForgetPassViewController.h"
#import "TimeCodeButton.h"

@interface XBForgetPassViewController ()

@property (weak, nonatomic)  WTReTextField      *tfPhone;
@property (weak, nonatomic)  WTReTextField      *tfValidCode;

@property (weak, nonatomic)  WTReTextField      *tfpwd;

@property (weak, nonatomic)  WTReTextField      *tfpwd2;

@property (nonatomic, strong) TimeCodeButton    *btnCode;
@property (nonatomic, strong) UIButton          *btnClick;

@end

@implementation XBForgetPassViewController
{
    DGridView * grid;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"忘记密码";
}

-(void)initUI {
    [self initScrollView];
    [self setRefreshScrollView];
     self.scrollview.backgroundColor=[UIColor whiteColor];
    
    grid = [[DGridView alloc]initWidth:APP_WIDTH];
    
    [grid setColumn:16 height:50];
    grid.backgroundColor=[UIColor whiteColor];
    
    self.tfPhone= [grid addRowInput:@"手机号   " placeholder:@"请输入手机号码"];
    WEAKSELF;
    
    self.tfValidCode = [grid addRowCodeText:^(id value) {
        [weakSelf clickSendMsg:value];
    }];
    
   self.tfpwd= [grid addRowInput:@"新密码   " placeholder:@"新密码"];
    
   self.tfpwd2=  [grid addRowInput:@"确认密码" placeholder:@"确认密码"];
    
    [grid addLineForHeight:30];
    
    self.btnClick= [grid addRowButtonTitle:@"确定" click:^(id value) {
        [self click];
    }];
    
    [self.scrollview addSubview:grid];
    [self.scrollview autoContentSize];
    
}

-(void)initData{
    
    [self.tfPhone setPhone];
    self.tfPhone.group = 1;
    
    [self.tfValidCode setValidationCode];
    self.tfValidCode.group = 1;
    
    [self.tfpwd setPwd];
    self.tfpwd.group=0;
    
    [self.tfpwd2 setPwd];
    self.tfpwd.group=0;
    
   
    

    
    for (UIView *item in self.tfValidCode.superview.subviews) {
        if ([item isKindOfClass:[TimeCodeButton class]]) {
            self.btnCode = (TimeCodeButton *)item;
        }
    }
    
    [self.view validation:1 fail:^(id value) {
        //[QTTheme btnGrayStyle:self.btnClick];
        
        if (self.tfPhone.text.length == 11) {
            self.btnCode.disabled = NO;
        } else {
            self.btnCode.disabled = YES;
        }
    } success:^(id value) {
        if ([self.view validationData:0]) {
            //[QTTheme btnThemeStyle:self.btnClick];
            self.btnCode.disabled = NO;
        }
    }];
    
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self setWhiteNavigation];
}



// 发送验证码
- (void)clickSendMsg:(id)value {
    if (![self.view validationText:self.tfPhone]) {
        self.btnCode.enabled = YES;
        return;
    }
    
    [self.view endEditing:YES];
    
    [self commonJsonMsg];
}


-(void)click
{
    
    if ([self.view validation:1]) {
        
        if (![self.tfpwd2.text isEqualToString:self.tfpwd.text]) {
            [self showToast:@"新密码和确认密码不相同"];
            return;
        }
        
        [self commonJsonSubmit];
    }
    
}

#pragma mark - json

- (void)commonJsonSubmit {
    [self showHUD];
    NSMutableDictionary *dic = [NSMutableDictionary new];
    dic[@"autoCode"] =self.tfValidCode.text;
    dic[@"member_psw"] = self.tfpwd.text;
    dic[@"phone_no"] = self.tfPhone.text;

    [service post:@"/v1/member/findPassword" data:dic  complete:^(NSDictionary *value) {
        [self hideHUD];
        
        [self showToast:@"修改密码成功" done:^{
            [NAVIGATION popViewControllerAnimated:YES];
        }];
    }];
    
    
}

- (void)commonJsonMsg {
    [self showHUD];
    NSMutableDictionary *dic = [NSMutableDictionary new];
    dic[@"phone_no"] = self.tfPhone.text;
    
    [service post:@"/v1/member/send/message/foget/psd" data:dic complete:^(id value) {
        [self hideHUD];
        self.btnCode.enabled = NO;
    }];
}



@end
