//
//  XBSchoolCardView.swift
//  XBApp
//
//  Created by stephen on 2018/5/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

import Foundation

import UIKit

class XBSchoolCardView: UIView {
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var lbTitle: UILabel!
    
    @IBOutlet weak var topConstraint: NSLayoutConstraint!
    func setText(_ text: String, img imageName: String) {
        lbTitle.text = text
        image.image = UIImage(named: imageName)
    }
}
