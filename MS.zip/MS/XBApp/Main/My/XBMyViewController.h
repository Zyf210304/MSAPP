//
//  XBMyViewController.h
//  XBApp
//
//  Created by stephen on 2018/1/9.
//Copyright © 2018年 stephen. All rights reserved.
//

#import "QTBaseViewController.h"

@interface XBMyViewController : QTBaseViewController

@end
