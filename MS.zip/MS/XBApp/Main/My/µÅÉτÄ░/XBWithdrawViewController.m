//
//  XBWithdrawViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/6.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBWithdrawViewController.h"

#import "XBAccountBankListViewController.h"
@interface XBWithdrawViewController ()

@property (strong, nonatomic) IBOutlet UIView *headView;

@property (strong, nonatomic) IBOutlet UIView *bottomView;

@property (strong, nonatomic) IBOutlet UILabel *lbbank;

@property (strong, nonatomic) IBOutlet UILabel *lbcard;

@property (weak, nonatomic)  WTReTextField      *tfMoney;

@end

@implementation XBWithdrawViewController
{
    DGridView * grid;
    
    UILabel * label;
    
    UILabel *lat_label;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"提现";
    
//    [self setRightBarTitle:@"提现记录" block:^{
//
//    }];
}

-(void)initUI {
    [self initScrollView];
    [self setRefreshScrollView];
    
    WEAKSELF;
    self.scrollview .backgroundColor=[UIColor whiteColor];
    
    grid = [[DGridView alloc]initWidth:APP_WIDTH];
    
    [grid setColumn:16 height:50];
    grid .backgroundColor=[UIColor whiteColor];
    
    
    [grid addView:self.headView margin:UIEdgeInsetsMake(10, 10, 10, 10)];
    [self.headView addTapGesture:^{
        XBAccountBankListViewController *listVC = [[XBAccountBankListViewController alloc] init];
        listVC.isChooseCard = YES;
        listVC.changeCard = ^(NSDictionary *dic) {
            weakSelf.lbbank.text= dic.str(@"bank_name");
            
            weakSelf.lbcard.text= dic.str(@"bank_no");
        };
        [weakSelf.navigationController pushViewController:listVC animated:YES];
    }];
    
    
    
    label=  [grid addRowLabel:@"可提现金额：--元"];
    
    self.tfMoney=  [grid addRowInputWithplaceholder:@"输入提现金额"];
    
   lat_label= [grid addRowLabel:@"100元起提"];
    
    [grid addRowButtonTitle:@"确认提现" click:^(id value) {
        [weakSelf clickSumbit];
    }];
    
    [grid addView:self.bottomView margin:UIEdgeInsetsMake(30, 10, 0, 10)];
    
    [self.scrollview addSubview:grid];
    [self.scrollview autoContentSize];
    
}

-(void)initData{
    
    [self.tfMoney setMoney];
    self.tfMoney.isNeed=YES;
    
    [self firstGetData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

-(void)clickSumbit
{
    
    //
    
    if ([self.view validation:0]) {
        [self commonJsonSubmit];
    }
    
    
}

#pragma mark - json

-(void)commonJson
{
    [self showHUD];
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    [service post:@"/v1/member/cash/result" data:dic  complete:^(NSDictionary *value) {
        
        [super commonJson];
        [self hideHUD];
        
        NSString *creditAvailableAmount =[NSString stringWithFormat:@"可提现金额：%@元",value.strMoney(@"get_account")];
        NSMutableAttributedString * attCreditAvailableAmount = [[NSMutableAttributedString alloc]initWithString:creditAvailableAmount];
        [attCreditAvailableAmount setColor:[Theme themeColor] string:value.strMoney(@"get_account")];
        label.attributedText=attCreditAvailableAmount;
        
        lat_label.text=value.strMoney(@"cash_last").add(@"起提");
        
        self.lbbank.text=value.str(@"bank_name");
        
        self.lbcard.text=value.str(@"bank_no");
        
    }];
    
    
}

- (void)commonJsonSubmit {
    
    [self showHUD];
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    
    dic[@"amount"]=[NSString stringWithFormat:@"%@",@(self.tfMoney.text.floatValue)];
    dic[@"bank_name"]=self.lbbank.text;
    dic[@"bank_no"]= self.lbcard.text;
    
    [service post:@"/v1/member/cash/sub" data:dic  complete:^(NSDictionary *value) {
        [self hideHUD];
        [self showToast:@"提现成功" done:^{
            [self.navigationController popToRootViewControllerAnimated:YES];
        }];

    }];
    
}



@end
