//
//  XBAccountOrderViewControllerCell.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBAccountOrderViewControllerCell.h"

@interface XBAccountOrderViewControllerCell  ()
@property (weak, nonatomic) IBOutlet UILabel *lbMoney;

@property (weak, nonatomic) IBOutlet UILabel *lbName;

@property (weak, nonatomic) IBOutlet UILabel *lbState;

@property (weak, nonatomic) IBOutlet UILabel *lbTime;

@end


@implementation XBAccountOrderViewControllerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
}

-(void)bind:(NSDictionary *)obj{
    
    
    NSMutableAttributedString * atr1 = [[NSMutableAttributedString alloc]init];
    
    [atr1 appendString:[NSString stringWithFormat:@"%@ %@元",obj.str(@"lottery_name"),obj.str(@"buy_amount")]];
    [atr1 setColor:[Theme themeColor] string:obj.str(@"buy_amount")];
    
    self.lbMoney.attributedText=atr1;
    self.lbTime.text = obj.str(@"end_time");
    
    if (obj.str(@"if_win")) {
        self.lbState.text=[NSString stringWithFormat:@"中奖%@元",obj.str(@"win_amount")];
    }
    else{
        self.lbState.text=@"未中奖";
    }
    
    
    {
        
        if ([obj.str(@"buy_way") isEqualToString:@"0"]) {
            //自购
            
            if ([obj.str(@"if_start") isEqualToString:@"1"]) {
                NSMutableAttributedString * atr1 = [[NSMutableAttributedString alloc]init];
                
                [atr1 appendString:[NSString stringWithFormat:@"跟单%@人",obj.str(@"name")]];
                [atr1 setColor:[Theme themeColor] string:obj.str(@"followCount")];
                
                self.lbName.attributedText= atr1;
            }
            else{
                self.lbName.text=@"自购订单";
            }
            
            
        }
        
        else{
            //跟单
            NSMutableAttributedString * atr1 = [[NSMutableAttributedString alloc]init];
            
            [atr1 appendString:[NSString stringWithFormat:@"发单人:%@",obj.str(@"name")]];
           
            
            self.lbName.attributedText= atr1;
        }
        
       
    }
    
    if (obj.str(@"ticket_time").length) {
        self.lbTime.text= [NSString stringWithFormat:@"%@发单",obj.dateMS(@"ticket_time").longTimeString];
    } else {
        self.lbTime.text =  @"尚未出票";
    }
    
    
}


@end
