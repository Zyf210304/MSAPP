//
//  XBAccountOrderViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBAccountOrderViewController.h"
#import "XBAccountOrderViewControllerCell.h"
#import "QTBaseViewController+Table.h"
#import "DSegmentedControl.h"

#import "YFOrderDetailVC.h"

@interface XBAccountOrderViewController ()<DSegmentedControlDelegate>



@end

@implementation XBAccountOrderViewController
{
    NSInteger type;
    DSegmentedControl * segmentedControl;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"订单记录";
    
     TABLEReg(XBAccountOrderViewControllerCell, @"XBAccountOrderViewControllerCell");
}

-(void)initUI {
    
    self.canRefresh = YES;
    [self initTable];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor=[Theme borderColor];
    self.tableView.separatorInset=UIEdgeInsetsMake(0, 15, 0, 0);
    
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 116;
    
    segmentedControl = [[DSegmentedControl alloc]initWithFrame:CGRectMake(0, 0, APP_WIDTH, 40)];
    [QTTheme segmentStyle1:segmentedControl];
    segmentedControl.delegate = self;
    [segmentedControl addGesture:self.view];
    [segmentedControl AddSegumentArray:@[@"全部订单",@"我的跟单", @"我的发单"]];
    
    self.tableView.tableHeaderView=segmentedControl;
    
}

-(void)initData{
    [self firstGetData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)segumentSelectionChange:(NSInteger)selection
{
    
    type=selection;
    [self commonJson];
}

#pragma  mark - table

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *Identifier = @"XBAccountOrderViewControllerCell";
    XBAccountOrderViewControllerCell   *cell = [tableView dequeueReusableCellWithIdentifier:Identifier forIndexPath:indexPath];
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    
    [cell bind:dic];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    
    YFOrderDetailVC *orderDetail = [[YFOrderDetailVC alloc] init];
    [self.navigationController pushViewController:orderDetail animated:YES];
}


#pragma mark - json

-(NSString *)listKey
{
    return @"list";
}

- (void)commonJson {
    NSMutableDictionary *dic = [NSMutableDictionary new];
    
    dic[@"page_num"] = self.current_page;
    dic[@"page_size"] = PAGES_SIZE;

    
    NSString * url;
    
    if (type==0) {
       
        url=@"/v1/order/selectMyAllOrderInfo";
    }
    else if (type==1){
        url=@"/v1/member/myDocumentary";
    }
    else if (type==2){
        url=@"/v1/member/myOwn";
    }
    
    
    [service post:url data:dic  complete:^(NSDictionary *value) {
        [self tableHandleValue:value];
    }];
    
    
    
}


@end
