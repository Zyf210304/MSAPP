//
//  XBMyViewController.m
//  XBApp
//
//  Created by stephen on 2018/1/9.
//Copyright © 2018年 stephen. All rights reserved.
//

#import "XBMyViewController.h"
//#import "XBMessageViewController.h"
#import "QTWebViewController.h"
#import "FSMediaPicker.h"

#import "YFNewAccountListVC.h"


#import "YFBillProfitVC.h"
#import "YFColourShop.h"
#import "YFMineRedPacketVC.h"
#import "YFRedpacketVC.h"
@interface XBMyViewController ()<FSMediaPickerDelegate>

@property (strong, nonatomic) IBOutlet UIView *headView;

@property (weak, nonatomic) IBOutlet UIImageView *imageHeadView;
@property (weak, nonatomic) IBOutlet UILabel *lbName;

@property (weak, nonatomic) IBOutlet UILabel *lbTime;

@property (strong, nonatomic) IBOutlet UIView *secondView;

@property (weak, nonatomic) IBOutlet UILabel *lbAllMoney;

@property (weak, nonatomic) IBOutlet UILabel *lbHasMoney;

@property (weak, nonatomic) IBOutlet UILabel *lbMoney;

@property (strong, nonatomic) IBOutlet UIView *thridView;

@property (weak, nonatomic) IBOutlet UIButton *btnGetMoney;

@property (weak, nonatomic) IBOutlet UIButton *btnBuyMoney;


@property (weak, nonatomic)  WTReTextField      *tfBaby;
@property (weak, nonatomic)  WTReTextField      *tfBuyRecord;
@property (weak, nonatomic)  WTReTextField      *tfCollect;
@property (weak, nonatomic)  WTReTextField      *tfCourseRecord;
@property (weak, nonatomic)  WTReTextField      *tfSet;
@property (weak, nonatomic)  WTReTextField      *tfCoupon;




@property (nonatomic) BOOL haveRed;

@end

@implementation XBMyViewController{
    DGridView * grid;
    
    DWrapView * wrap;
    
    BOOL real;
    
    BOOL isBank;
    
    BOOL isAutonym;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我的";

    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(firstGetData) name:NOTICE_ENTER object:nil];
    
}

-(void)initUI{
    [self initScrollView];
    [self setRefreshScrollView];
    
    self.scrollview.backgroundColor = [UIColor whiteColor];
    grid = [[DGridView alloc]initWidth:APP_WIDTH];
    
    grid.backgroundColor = [UIColor whiteColor];
    [grid setColumn:16 height:50];
    grid.lineType=2;
    grid.offsetX=20;
    
    WEAKSELF;
    
    [grid addView:self.headView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    [grid addView:self.secondView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    [grid addView:self.thridView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
   
    wrap = [[DWrapView alloc]initWidth:APP_WIDTH columns:3];
    wrap.backgroundColor =  [UIColor whiteColor];
    wrap.subHeight = 100;
    NSArray *textArray = @[@"帐号明细", @"我的订单", @"中奖记录",@"实名认证",@"发单收益",@"彩店信息",@"常用问题",@"帐号设置", @"红包"];
    NSArray *imageArray = @[@"my1", @"my2", @"my3", @"my4", @"my5", @"my6", @"my7", @"my8", @"my9"];
    
    NSArray *months = @[@"toPageAccountList",@"toPageAccountOrderList",@"toPageWinList",@"toPageReal",@"toPageAccountBillList",@"",@"toPageAccountIssueList",@"toPageSetting", @"toPageSetting"];
    
    
    
    for (int i = 0; i < textArray.count; i++) {
        XBSchoolCardView *item = [XBSchoolCardView viewNib];
        item.width = wrap.subHeight;
        item.height = wrap.subHeight;
        item.borderColor=[Theme backgroundColor];
        item.borderWidth=0.5;
        [item setText:textArray[i] img:imageArray[i]];
        [item addTapGesture:^{
            
            
            if (i==3) {
                if (real) {
                    [self showToast:@"用户已实名"];
                     return ;
                }
            }
            
            if (i==4) {
//                [self showToast:@"即将上线"];
                YFBillProfitVC *profitVC = [[YFBillProfitVC alloc] init];
                [weakSelf.navigationController pushViewController:profitVC animated:YES];
                return ;
            }
            
            if (i==5) {
//                [self showToast:@"即将上线"];
                
                YFColourShop *shopVC = [[YFColourShop alloc] init];
                [weakSelf.navigationController pushViewController:shopVC animated:YES];
                
                return ;
            }
            
            if (i == 8) {
                if (_haveRed) {
                    YFMineRedPacketVC *redVC = [[YFMineRedPacketVC alloc] init];
                    [weakSelf.navigationController pushViewController:redVC animated:YES];
                } else {
                    YFRedpacketVC *redVC = [[YFRedpacketVC alloc] init];
                    [weakSelf.navigationController pushViewController:redVC animated:YES];
                }
                
                return;
            }
         
                [self performSelector:NSSelectorFromString(months[i])];

            
        }];
        [wrap addView:item margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    }
    
    [grid addView:wrap margin:UIEdgeInsetsMake(0, 0, 10, 0)];
    
   
    [self.scrollview addSubview:grid];
    [self.scrollview autoContentSize];
    
   
    
}

-(void)initData{
    

    [self.btnBuyMoney click:^(id control) {
        [self toPageRecharge];
    }];
    
    [self.btnGetMoney click:^(id control) {
        if (isAutonym) {
            if (isBank) {
                [self toPageWithdraw];
            } else {
                [self toPageAccountBankList];
            }
        } else {
            [self toPageReal];
        }
        
        
    }];
    
    WEAKSELF;
    UIView *redAbout = [self.view viewWithTag:2333];
    [redAbout addTapGesture:^{
        YFMineRedPacketVC *redAbout = [[YFMineRedPacketVC alloc] init];
        redAbout.isChange = YES;
        [self.navigationController pushViewController:redAbout animated:YES];
    }];
    
    
    
    
    [self firstGetData];

    [self.imageHeadView addTapGesture:^{
        FSMediaPicker *mediaPicker = [[FSMediaPicker alloc] init];
        mediaPicker.mediaType = FSMediaTypePhoto;
        mediaPicker.editMode = FSEditModeCircular;
        mediaPicker.delegate = weakSelf;
        [mediaPicker showFromView:weakSelf.view];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self hideNavigationBar];
    
    self.view.height= APP_HEIGHT - self.tabBarHeight;
    
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    dic[NSFontAttributeName]=[UIFont boldSystemFontOfSize:18];
    dic[NSForegroundColorAttributeName]=[UIColor colorHex:@"333333"];
    [NAVIGATION.navigationBar setTitleTextAttributes:dic];
    
    self.tabBarController.navigationItem.title = @"";
    
    self.tabBarController.navigationItem.titleView=nil;
    
    self.tabBarController.navigationItem.leftBarButtonItem=nil;

    self.tabBarController.navigationItem.rightBarButtonItem=nil;
    
    self.tabBarController.navigationItem.rightBarButtonItems=nil;
    
    [self commonJson];
    [self getColorGod];
    [self getReIDNetWork];
    if (!USER_DATA.isLogin) {
        [self toPageLogin];
    }
    
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

#pragma mark - json

-(void)commonJson{
    
    if (USER_DATA.isLogin) {
        NSMutableDictionary *dic=[NSMutableDictionary new ];
        [service post:@"v1/member/findPersonCenter" data:dic  complete:^(NSDictionary *value) {

            
            [super commonJson];
            [self hideHUD];
            
            self.lbAllMoney.text= value.strMoney(@"account");
             self.lbHasMoney.text= value.strMoney(@"get_account");
//             self.lbMoney.text= value.strMoney(@"color_gold");
            
            self.lbName.text = value.str(@"name").length ? value.str(@"name") : [NSString stringWithFormat:@"米神用户%@", value.str(@"id")];
            
            [self.imageHeadView setImageWithURLString:value.str(@"member_logo") placeholderImageString:@"default_item_small"];
            
            self.lbTime.text=[NSString stringWithFormat:@"ID：%@",value.str(@"id")];
            
            real= value.i(@"state");

            isBank = value.i(@"bank_state");
            isAutonym = value.i(@"state");
            
            
            
            
        }];
        
    }
    else{
        [self hideHUD];
        [super commonJson];
    }
}

#pragma mark - delegate
- (void)mediaPicker:(FSMediaPicker *)mediaPicker didFinishWithMediaInfo:(NSDictionary *)mediaInfo {
    if (mediaInfo.mediaType == FSMediaTypePhoto) {
        self.imageHeadView.image = mediaInfo.editedImage;
        
        
        [self showHUD];
        
        NSMutableDictionary *dic=[NSMutableDictionary new ];
        
        
        
        dic[@"filename"]=  @"png";
        
        dic[@"key"] = @"member_logo";
        
        dic[@"file"] = [UIImage zipNSDataWithImage:mediaInfo.editedImage];
        
        service.dataType = DataTypeFile;
        [service post:@"v1/member/updateMemberLogo" data:dic  complete:^(NSDictionary *value) {
            [self hideHUD];
            self.imageHeadView.image = mediaInfo.editedImage;
        }];
        
        
    }
}




#pragma mark   ---- 彩金
- (void)getColorGod {
    [[YFNetBaseManager sharedConnect] postWithPortName:@"/v1/amount/money/color/cold" parameters:nil hud:HUDStyle_hidden success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
            NSString *color_gold = responseObject[@"data"];
            self.lbMoney.text= [NSString stringWithFormat:@"%.2lf", color_gold.floatValue];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}

#pragma mark  --- 红包id ---
- (void)getReIDNetWork {
    [[YFNetBaseManager sharedConnect] postWithPortName:@"/v1/red/envelopes/my/red/envelopes/id" parameters:nil hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
            _haveRed = ![[responseObject[@"data"] class] isEqual:[NSNull class]];
        } else {
//            [self showHint:responseObject[@"tip"]];
        }
        
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        _haveRed = NO;
    }];
}


@end
