//
//  MYIntroductionPanel.m
//  MYBlurIntroductionView-Example
//
//  Created by Matthew York on 10/16/13.
//  Copyright (c) 2013 Matthew York. All rights reserved.
//

#import "MYIntroductionPanel.h"

@implementation MYIntroductionPanel

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];

    if (self) {
        self.backgroundColor = [UIColor clearColor];
    }

    return self;
}

- (id)initWithFrame:(CGRect)frame nibNamed:(NSString *)nibName {
    self = [super init];

    if (self) {
        // Initialization code
        self = [[NSBundle mainBundle] loadNibNamed:nibName owner:nil options:nil][0];
        self.frame = frame;
    }

    return self;
}

+ (BOOL)runningiOS7 {
    NSString *currSysVer = [[UIDevice currentDevice] systemVersion];

    if (currSysVer.floatValue >= 7.0) {
        return YES;
    }

    return NO;
}

#pragma mark - Interaction Methods

- (void)panelDidAppear {
    // Implemented by subclass
}

- (void)panelDidDisappear {
    // Implemented by subclass
}

@end
