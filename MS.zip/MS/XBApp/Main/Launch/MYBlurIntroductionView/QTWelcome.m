//
//  QTWelcomeSecond.m
//  qtyd
//
//  Created by stephendsw on 15/12/1.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import "QTWelcome.h"
#import "MYBlurIntroductionView.h"
#import "QTTheme.h"
#import <QuartzCore/QuartzCore.h>
#import <AVFoundation/AVFoundation.h>

@interface QTWelcome ()

@end

@implementation QTWelcome
{
    AVPlayer *player;
}

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setContentImg:(NSString *)contentImg {
//    NSURL *URL = [[NSBundle mainBundle] URLForResource:contentImg withExtension:@"mov"];
//
//    player = [AVPlayer playerWithURL:URL];
//    AVPlayerLayer *playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
//
//    playerLayer.frame = self.bounds;
//    [self.layer addSublayer:playerLayer];
    
    UIImageView * imageview = [[UIImageView alloc]initWithImage:[UIImage imageNamed:contentImg]];
    imageview.frame=APP_FRAEM;
    imageview.contentMode=UIViewContentModeScaleAspectFit;
    [self addSubview:imageview];
    
}

- (void)setIsLast:(BOOL)isLast {
    __weak typeof(self) weakSelf = self;
    if (isLast) {
        [self addTapGesture:^{
            [weakSelf.parentIntroductionView didPressSkipButton];
        }];
    }
}

- (void)play {
    //[player play];
}

+ (id)welcome1 {
    QTWelcome *wel = [[QTWelcome alloc] initWithFrame:APP_FRAEM nibNamed:@"QTWelcome"];

    wel.contentImg = @"welcome_one.jpeg";
    wel.isLast = NO;
    return wel;
}

+ (id)welcome2 {
    QTWelcome *wel = [[QTWelcome alloc] initWithFrame:APP_FRAEM nibNamed:@"QTWelcome"];

    wel.contentImg = @"welcome_two.jpeg";
    wel.isLast = NO;
    return wel;
}

+ (id)welcome3 {
    QTWelcome *wel = [[QTWelcome alloc] initWithFrame:APP_FRAEM nibNamed:@"QTWelcome"];

    wel.contentImg = @"welcome_three.jpeg";
    wel.isLast = YES;
    return wel;
}

@end
