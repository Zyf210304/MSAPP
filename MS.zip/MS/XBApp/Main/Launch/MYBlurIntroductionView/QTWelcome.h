//
//  QTWelcomeSecond.h
//  qtyd
//
//  Created by stephendsw on 15/12/1.
//  Copyright © 2015年 qtyd. All rights reserved.
//

#import "MYIntroductionPanel.h"

@interface QTWelcome : MYIntroductionPanel

@property (nonatomic, strong) NSString  *contentImg;
@property (nonatomic, assign) BOOL      isLast;

-(void)play;

+ (id)welcome1;
+ (id)welcome2;
+ (id)welcome3;

@end
