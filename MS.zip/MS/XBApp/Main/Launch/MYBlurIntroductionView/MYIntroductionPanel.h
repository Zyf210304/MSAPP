//
//  MYIntroductionPanel.h
//  MYBlurIntroductionView-Example
//
//  Created by Matthew York on 10/16/13.
//  Copyright (c) 2013 Matthew York. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MYBlurIntroductionView;

@interface MYIntroductionPanel : UIView

@property (nonatomic, retain) MYBlurIntroductionView *parentIntroductionView;

// @property (nonatomic, assign) BOOL  isCustomPanel;
// @property (nonatomic, assign) BOOL  hasCustomAnimation;

// Init Methods
- (id)initWithFrame:(CGRect)frame nibNamed:(NSString *)nibName;

// Support Methods
+ (BOOL)runningiOS7;

// Interaction Methods
- (void)panelDidAppear;
- (void)panelDidDisappear;

@end
