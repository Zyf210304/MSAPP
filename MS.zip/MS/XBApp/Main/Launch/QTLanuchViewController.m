//
//  QTLanuchViewController.m
//  qtyd
//
//  Created by stephendsw on 16/2/26.
//  Copyright © 2016年 qtyd. All rights reserved.
//

#import "QTLanuchViewController.h"
#import "QTNavigationController.h"

#import "QTWebViewController.h"
//#import "UIViewController+location.h"

@interface QTLanuchViewController ()

@end

@implementation QTLanuchViewController
{
    UIImageView *launchView;
    NSTimer     *timer;
    UIButton    *btn;
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)initUI {
    launchView = [[UIImageView alloc] init];
    launchView.frame = APP_FRAEM;
    launchView.contentMode = UIViewContentModeScaleAspectFit;
    [self.view addSubview:launchView];
    launchView.userInteractionEnabled=YES;
    
    btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(APP_WIDTH - 60, 30, 50, 35);
    [btn setTitle:@"跳过" forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:10];
    btn.backgroundColor = [UIColor colorWithWhite:1 alpha:0.7];
    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    btn.cornerRadius = 1;
    
    [launchView addSubview:btn];
}

- (void)initData {
    
    [self initImage];
    
    btn.hidden = YES;
    
    [btn click:^(id value) {
        [timer invalidate];
        [self  HomePage];
    }];
}

- (void)initImage {
    CGSize      viewSize = APP_FRAEM.size;
    NSString    *viewOrientation = @"Portrait"; // 横屏请设置成 @"Landscape"
    NSString    *launchImage = nil;
    NSArray     *imagesDict = [[[NSBundle mainBundle] infoDictionary] valueForKey:@"UILaunchImages"];
    
    for (NSDictionary *dict in imagesDict) {
        CGSize imageSize = CGSizeFromString(dict[@"UILaunchImageSize"]);
        
        if (CGSizeEqualToSize(imageSize, viewSize) && [viewOrientation isEqualToString:dict[@"UILaunchImageOrientation"]]) {
            launchImage = dict[@"UILaunchImageName"];
        }
    }
    
    launchView.image = [UIImage imageNamed:launchImage];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
  
    
    [self initImage];
    btn.hidden = YES;
    
    [self commonJsonPage];
    
}

- (void)HomePage {
    [timer invalidate];
    timer = nil;
    
    [self.view removeFromSuperview];
    
    APPDELEGATE.window.rootViewController = APPDELEGATE.navController;

}

#pragma mark json

- (void)commonJsonPage {
    if (![AppUtil isConnectedToNetwork]) {
        dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 /*延迟执行时间*/ * NSEC_PER_SEC));
        
        dispatch_after(delayTime, dispatch_get_main_queue(), ^{
            [self HomePage];
        });
        
        return;
    }
    
    [self HomePage];

//    [service get:@"front/unAuth/security/AppVersion/getVersion" data:nil complete:^(NSDictionary *value) {
//        [self hideHUD];
//        
//        [[NSUserDefaults standardUserDefaults] setValue:value.str(@"wapUrl") forKey:@"cf_web_host"];
//
//        NSDictionary *dic;
//
//        for (NSDictionary *item  in value.arr(@"launchAdvImgUrl")) {
//            if ([item.str(@"status") isEqualToString:@"online"]) {
//                dic = item;
//            }
//        }
//
//        WEAKSELF;
//
//        if (dic) {
//            timer = [NSTimer timerExecuteCountPerSecond:4 done:^(NSInteger value) {
//                btn.hidden = NO;
//                [btn setTitle:[NSString stringWithFormat:@"跳过%ld", (long)value] forState:UIControlStateNormal];
//
//                if (value == 0) {
//                    [self HomePage];
//                }
//            }];
//
//            [launchView sd_setImageWithURL:[NSURL URLWithString:dic.str(@"image")] placeholderImage:launchView.image];
//
//            if (![NSString isEmpty:dic.str(@"href")]) {
//                [launchView addTapGesture:^{
//                    QTWebViewController *webcontroller = [QTWebViewController controllerFromXib];
//                    webcontroller.isNeedLogin = YES;
//                    webcontroller.url = dic.str(@"href");
//
//                    [weakSelf HomePage];
//                    [APPDELEGATE.navController pushViewController:webcontroller animated:YES];
//                }];
//            }
//        } else {
//            [self HomePage];
//        }
//    }];
}

- (void)jsonFailure:(NSDictionary *)dic {
    [super jsonFailure:dic];
    [self HomePage];
}

- (void)netFailure {
    [super netFailure];
    [self HomePage];
}

@end

