//
//  QTLanuchViewController.h
//  qtyd
//
//  Created by stephendsw on 16/2/26.
//  Copyright © 2016年 qtyd. All rights reserved.
//

#import "QTBaseViewController.h"
#import "QTNavigationController.h"

@interface QTLanuchViewController : QTBaseViewController

@end
