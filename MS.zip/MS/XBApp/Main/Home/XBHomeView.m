//
//  XBHomeView.m
//  MSApp
//
//  Created by stephen on 2018/9/10.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBHomeView.h"

@interface XBHomeView ()

@property (weak, nonatomic) IBOutlet UIImageView *imageLogo;

@property (weak, nonatomic) IBOutlet UILabel *lbName;

@property (weak, nonatomic) IBOutlet UILabel *lbtip2;

@property (weak, nonatomic) IBOutlet UILabel *lbComment;


@property (weak, nonatomic) IBOutlet UILabel *lbzu;
@property (weak, nonatomic) IBOutlet UILabel *lbzi;
@property (weak, nonatomic) IBOutlet UILabel *lbYI;

@end

@implementation XBHomeView

-(void)bind:(NSDictionary *)obj
{
    [self.imageLogo setImageWithURLString:obj.str(@"member_logo") placeholderImageString:@"default_item_small"];
    
    self.lbName.text=obj.str(@"member_name");
    
    if (obj.str(@"followCount").integerValue < 1) {
        self.lbComment.text= @"0人跟单";
    } else {
        self.lbComment.text= [NSString stringWithFormat:@"%@人跟单",obj.str(@"followCount")] ;
    }
    
    
    //self.lbtip1.text= [NSString stringWithFormat:@" %@连红 ",obj.str(@"consecutive")];  ;
    
    self.lbtip2.text= [obj.str(@"end_time") substringToIndex:16];
    
    self.lbzu.text= obj.str(@"pass_way");
    
    self.lbzi.text= [NSString stringWithFormat:@"%@元", obj.strMoney(@"buy_amount")];
    
    self.lbYI.text=obj.str(@"lottery_name");
}

@end
