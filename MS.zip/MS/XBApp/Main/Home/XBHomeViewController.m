//
//  XBSchoolViewController.m
//  XBApp
//
//  Created by stephen on 2018/1/9.
//Copyright © 2018年 stephen. All rights reserved.
//

#import "XBHomeViewController.h"
#import "AdView.h"
#import "QTWebViewController.h"
#import "QTBaseViewController+Activity.h"
#import "XBHomeView.h"

#import "YFChooseMatchVC.h"
#import "YFPlaceOrderVC.h"

#import "YFBasketBallMatchVC.h"



@interface XBHomeViewController ()

@property (strong, nonatomic) IBOutlet UIView *headView;
@property (strong, nonatomic) IBOutlet UIView *msgView;
@property (strong, nonatomic) IBOutlet UIView *saiView;

@property (strong, nonatomic) IBOutlet UIView *tipView;

@property (strong, nonatomic) IBOutlet UIScrollView *secondView;

@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;
@property (weak, nonatomic) IBOutlet UILabel *lbNotice;

@property (strong, nonatomic) IBOutlet UIView *topMessage;
@property (strong, nonatomic) IBOutlet UIView *topOnline;

@end

@implementation XBHomeViewController
{
    
    AdView              *_adView;
    DStackView * stack;
    
    NSInteger type;
    
    DWrapView * wrap;
    
    NSDictionary * dataSource;
    
    UIView * adcontentview;
    

}


- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void)initUI {
    
    [self initScrollView];
    
    ///
    stack= [[DStackView alloc]initWidth:APP_WIDTH];
    
    float heightAd = APP_WIDTH / 375 * 175;

    adcontentview=[[UIView alloc]initWithFrame:CGRectMake(0, 0, APP_WIDTH, heightAd)];
    [stack addView:adcontentview margin:UIEdgeInsetsMake(0, 0, 10, 0)];
    
    
    [stack addView:self.headView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
     [stack addView:self.msgView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    wrap = [[DWrapView alloc]initWidth:APP_WIDTH columns:4];
    wrap.backgroundColor =  [UIColor whiteColor];
    wrap.subHeight = 80;
    NSArray *textArray = @[@"竞彩足球", @"竞彩篮球", @"竞足单关",@"胜负彩",@"竞篮单关",@"任九",@"排列3",@"排列5"];
    NSArray *imageArray = @[@"home1", @"home2", @"home3", @"home4", @"home5", @"home6", @"home7", @"home8"];
    for (int i = 0; i < textArray.count; i++) {
        XBSchoolCardView *item = [XBSchoolCardView viewNib];
        item.width = wrap.subHeight;
        item.height = wrap.subHeight;
        item.topConstraint.constant=10;
        [item setText:textArray[i] img:imageArray[i]];
        [item addTapGesture:^{
            
            if (i==0) {

                if (!USER_DATA.isLogin) {
                    [self toPageLogin];
                }
                else{
                    YFChooseMatchVC *controller = [YFChooseMatchVC controllerFromXib];
                    [NAVIGATION pushViewController:controller animated:YES];
                }
            }
            
            else if (i==1)
            {
                YFBasketBallMatchVC *basketballVC = [[YFBasketBallMatchVC alloc] init];
                [self.navigationController pushViewController:basketballVC animated:YES];
//                [self showToast:@"即将上线"];
            }
            else{
                [self showToast:@"即将上线"];
            }
            
        }];
        [wrap addView:item margin:UIEdgeInsetsMake(0, 0, 10, 0)];
    }
    
    [stack addView:wrap margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    [stack addLineForHeight:10 color:[UIColor whiteColor]];
    
    [stack addLineForHeight:10];
    
    //[stack addView:self.saiView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    [stack addView:self.tipView margin:UIEdgeInsetsMake(0, 0, 0, 0)];

    [stack addView:self.secondView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    [stack addView:self.pageControl margin:UIEdgeInsetsMake(0, 100, 0, 100)];
    
    [self.scrollview addSubview:stack];
    [self.scrollview autoContentSize];
    
    WEAKSELF;
    [_topOnline addTapGesture:^{
        [weakSelf showHint:@"即将上线"];
    }];
    [_topMessage addTapGesture:^{
        [weakSelf showHint:@"即将上线"];
    }];
}

- (void)initData {
    
   // [self firstGetData];
    
    WEAKSELF;
    
    [self.tipView addTapGesture:^{
        [weakSelf toPageBill];
    }];
    
  
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self hideNavigationBar];
    
    self.view.height= APP_HEIGHT -self.tabBarHeight;
    
//    [AppUtil openApp:@"itms-services:///?action=download-manifest&url=https://github.com/Zyf210304/MSAPP/blob/master/main.plist"];
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-services:///?action=download-manifest&url=https://github.com/Zyf210304/-/blob/master/main.plist"]];


    [self checkVersion];
    [self commonJson];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}


- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}


#pragma  mark - json

- (NSString *)listKey {
    return @"content";
}

- (void)commonJson {
    
    if (USER_DATA.isLogin) {
        
//        [service get:@"front/auth/message/unReadCount" data:nil complete:^(NSDictionary *value) {
//            if (self.tabBarController.selectedIndex==HOME_TAG) {
//                if ([value isKindOfClass:[NSNumber class]] && ((NSNumber *)value).integerValue>0  ) {
//                    
//                    NSArray<UIBarButtonItem *> *items  =  self.tabBarController.navigationItem.rightBarButtonItems;
//                    UIBarButtonItem * item=  items .firstObject;
//                    item.image=[[UIImage imageNamed:@"icon_msg_num"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
//                    
//                } else {
//                    
//                    NSArray<UIBarButtonItem *> *items  =  self.tabBarController.navigationItem.rightBarButtonItems;
//                    UIBarButtonItem * item=  items .firstObject;
//
//                    item.image=[[UIImage imageNamed:@"icon_msg_num"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
//                    
//                }
//            }
//            
//        }];
    }
    
    NSMutableDictionary *dic = [NSMutableDictionary new];
    

    [service post:@"/v1/member/getHomePageInfo" data:dic complete:^(NSDictionary *value) {
        [self hideHUD];

        
        NSString * string =  [value.arr(@"announcements") getArrayForKey:@"arti_name"].firstObject;
        
        self.lbNotice.text=string;
        
        dataSource=value;
        
        NSMutableArray * array=[[NSMutableArray alloc]init];
//        if ([value.dic(@"sentimentOrder") isKindOfClass:[NSDictionary class]])
//        {
//             [array addObject:value.dic(@"sentimentOrder")];
//        }
//       
        if  ([value.dic(@"orderInfo") isKindOfClass:[NSDictionary class]])
        {
             [array addObject:value.dic(@"orderInfo")];
        }
        
        
        int i =0;
        for (NSDictionary * item  in array) {
            XBHomeView * homeview=[XBHomeView viewNib];
            [homeview bind:item];
            homeview.frame=CGRectMake(i*APP_WIDTH, 0, APP_WIDTH, self.scrollview.height);
            [self.secondView addSubview:homeview];
            i++;
            
            [homeview addTapGesture:^{
                [self toPageOrder:item.str(@"id")];
            }];
            
        }
        
        [self.pageControl bindScrollView:self.secondView];
        self.secondView.contentSize=CGSizeMake(APP_WIDTH*i, 0);

        

        if (_adView) {
            [_adView removeFromSuperview];
        }
        
        _adView = [[AdView alloc]initWithFrame:CGRectMake(0, 0, APP_WIDTH, adcontentview.height)];
        _adView.placeHoldImage = [UIImage imageNamed:@"default_banner"];
        [_adView setPageControlShowStyle:UIPageControlShowStyleCenter];
        [QTTheme pageControlStyle:_adView.pageControl];
        
        [adcontentview addSubview:_adView];
        
        NSArray *picList =value.arr(@"img_src");
        
        if (picList.count > 0) {
            if (picList.count == 1) {
                _adView.isNeedCycleRoll = NO;
                _adView.adScrollView.scrollEnabled = NO;
                _adView.pageControl.hidden = YES;
            } else {
                _adView.isNeedCycleRoll = YES;
                _adView.adScrollView.scrollEnabled = YES;
                _adView.pageControl.hidden = NO;
            }
            
            [_adView setimageLinkURL:picList];
            [QTTheme pageControlStyle:_adView.pageControl];
//            [_adView click:^(NSInteger index, NSString *imageURL) {
//                NSDictionary *dic = value.arr(@"cmsBannerPojoList")[index];
//
//                NSString *url = dic.str(@"href");
//
//                if (url) {
//                    PAGE_NET_ERROR;
//
//                    if ([url containsString:@"cflc://jsbridge"]) {
//                        NSDictionary *webdic = [url getUrlParameter];
//
//                        [self webToAppPage:webdic];
//                    } else {
//                        QTWebViewController *webcontroller = [QTWebViewController controllerFromXib];
//                        webcontroller.isNeedLogin = YES;
//                        webcontroller.url = url;
//                        [webcontroller bindShare:dic];
//                        [NAVIGATION pushViewController:webcontroller animated:YES];
//                    }
//                }
//            }];
        } else {
            _adView.isNeedCycleRoll = NO;
            _adView.userInteractionEnabled = NO;
        }
        
    }];
    
}


#pragma mark  ---- 检测更新 -----
- (void)checkVersion {
    [[YFNetBaseManager sharedConnect] postWithPortName:@"v2/version/findIosVersion" parameters:nil hud:HUDStyle_hidden success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        NSNumber *netVersion = responseObject[@"ios_version"];
        if (netVersion.integerValue > 2) {
            [self gotoUpLoad];
        } else {
            NSLog(@"当前最新版本");
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
    
}

- (void)gotoUpLoad {
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"请更新最新版本" message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self gotoSafi];
    }];

    [alertC addAction:alertAction1];
    
    //将alertController 显示
    [self presentViewController:alertC animated:YES completion:nil];
}




- (void)gotoSafi {
//    return;
    //    NSString * urlStr = [NSString stringWithFormat:@"http://%@",@""];
    NSURL *url = [NSURL URLWithString:@"itms-services://?action=download-manifest&url=https://raw.githubusercontent.com/Zyf210304/MSAPP/master/manifest.plist"];
    if([[UIDevice currentDevice].systemVersion floatValue] >= 10.0){
        if ([[UIApplication sharedApplication] respondsToSelector:@selector(openURL:options:completionHandler:)]) {
            if (@available(iOS 10.0, *)) {
                [[UIApplication sharedApplication] openURL:url options:@{}
                                         completionHandler:^(BOOL success) {
                                             NSLog(@"Open %d",success);
                                         }];
            } else {
                // Fallback on earlier versions
            }
        } else {
            BOOL success = [[UIApplication sharedApplication] openURL:url];
            NSLog(@"Open  %d",success);
        }
        
    } else{
        bool can = [[UIApplication sharedApplication] canOpenURL:url];
        if(can){
            [[UIApplication sharedApplication] openURL:url];
        }
    }
    
}



@end
