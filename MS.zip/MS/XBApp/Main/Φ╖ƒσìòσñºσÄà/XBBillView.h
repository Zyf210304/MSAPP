//
//  XBBillView.h
//  MSApp
//
//  Created by stephen on 2018/9/10.
//Copyright © 2018 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XBBillView : UIView

-(void)bind:(NSDictionary *)obj;
@end
