//
//  XBBillViewControllerCell.h
//  MSApp
//
//  Created by stephen on 2018/9/6.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "DTableViewCell.h"

@interface XBBillViewControllerCell : DTableViewCell

@end
