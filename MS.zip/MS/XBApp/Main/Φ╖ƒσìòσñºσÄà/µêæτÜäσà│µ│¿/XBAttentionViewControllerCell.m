//
//  XBAttentionViewControllerCell.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBAttentionViewControllerCell.h"

@interface XBAttentionViewControllerCell  ()
@property (weak, nonatomic) IBOutlet UIImageView *images;

@property (weak, nonatomic) IBOutlet UILabel *lbName;


@property (weak, nonatomic) IBOutlet UILabel *lbSub;
@property (weak, nonatomic) IBOutlet UILabel *lbTip;

@end


@implementation XBAttentionViewControllerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
}

-(void)bind:(NSDictionary *)obj{
    
   
    self.lbTip.text=[NSString stringWithFormat:@" %@连红 ",obj.str(@"keep_red")];
        
    
    [self.images setImageWithURLString:obj.str(@"member_logo") placeholderImageString:@"default_item_small"];
    
    self.lbName.text=obj.str(@"name");
    
    NSMutableAttributedString * atr = [[NSMutableAttributedString alloc]init];
   
    [atr appendString:[NSString stringWithFormat:@"带红%@人  ",obj.str(@"red_people")]];
    [atr setColor:[Theme themeColor] string:obj.str(@"red_people")];
    
      NSMutableAttributedString * atr1 = [[NSMutableAttributedString alloc]init];
    
     [atr1 appendString:[NSString stringWithFormat:@"粉丝%@人",obj.str(@"fans")]];
     [atr1 setColor:[Theme themeColor] string:obj.str(@"fans")];
    [atr appendAttributedString:atr1];
    self.lbSub.attributedText=atr;
    
  
    
    
}

@end
