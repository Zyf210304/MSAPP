//
//  XBBillDetailViewController.h
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "QTBaseViewController.h"

@interface XBBillDetailViewController : QTBaseViewController

@property (nonatomic , strong ) NSString *oid;

@property (nonatomic) BOOL isSee;

@end
