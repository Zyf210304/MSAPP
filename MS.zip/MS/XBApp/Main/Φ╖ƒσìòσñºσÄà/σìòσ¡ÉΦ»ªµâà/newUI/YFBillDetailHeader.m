//
//  YFBillDetailHeader.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/15.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBillDetailHeader.h"

@implementation YFBillDetailHeader

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}


- (void)initUI {
   
    for (int i = 0; i < 2; i ++) {
        [self addTypeView:i];
    }
    
    UIView *centerLine = [[UIView alloc] init];
    [self addSubview:centerLine];
    centerLine.backgroundColor = [UIColor lightGrayColor];
    [centerLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_offset(1);
        make.centerX.equalTo(self.mas_centerX);
        make.centerY.equalTo(self.mas_centerY);
        make.height.mas_offset(20);
    }];
    
    UIView *lineView = [[UIView alloc] init];
    [self addSubview:lineView];
    lineView.backgroundColor = Color_Base_BG;
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(2);
        make.height.mas_offset( 2 * SCALE_375);
        make.left.right.mas_offset(0);
    }];
}

- (void)addTypeView:(NSInteger)count {
    
    UIView *TypeView = [[UIView alloc] init];
    [self addSubview:TypeView];
    TypeView.tag = 500 + count;
    TypeView.backgroundColor = [UIColor whiteColor];
    CGFloat left = count == 0 ? 0 : FRAME_WIDTH / 2;
    [TypeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(left);
        make.width.mas_offset(FRAME_WIDTH / 2);
        make.top.bottom.mas_offset(0);
    }];
    [TypeView addTapgestureWithTarget:self action:@selector(typeDidSelct:)];
    
    
    UILabel *title = [[UILabel alloc] init];
    [TypeView addSubview:title];
    title.text = count == 0 ? @"方案详情" : @"跟单用户";
    title.textAlignment = NSTextAlignmentCenter;
    title.tag = 200 + count;
    title.textColor = count == 0 ?  [UIColor redColor] : Color_title_333;
    [title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.bottom.mas_offset(0);
    }];
    
    UIView *lineView = [[UIView alloc] init];
    [self addSubview:lineView];
    lineView.tag = 300 + count;
    lineView.backgroundColor = count == 0 ?  [UIColor redColor] : [UIColor clearColor];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_offset(0);
        make.height.mas_offset( 2 * SCALE_375);
        make.left.mas_offset(left);
        make.width.mas_offset(FRAME_WIDTH /2);
    }];
    
}

- (void)typeDidSelct:(UITapGestureRecognizer *)sender {
    
    [self setVlaueWith:sender.view.tag % 100];
    
    
    self.typeDidSelect(sender.view.tag % 100);
}

- (void)setVlaueWith:(NSInteger)count {
    NSInteger tag = count;
    UILabel *leftTitle = [self viewWithTag:200];
    UILabel *rightTitle = [self viewWithTag:201];
    UIView *leftLine = [self viewWithTag:300];
    UIView *rightLine = [self viewWithTag:301];
    
    
    leftTitle.textColor = tag == 0 ? [UIColor redColor] : Color_title_333;
    rightTitle.textColor = tag == 0 ? Color_title_333 :[UIColor redColor];
    leftLine.backgroundColor = tag == 0 ?  [UIColor redColor] : [UIColor whiteColor];
    rightLine.backgroundColor = tag != 0 ?  [UIColor redColor] : [UIColor whiteColor];
    

}













/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
