//
//  YFBillDetailFellowHeaderCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/18.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBillDetailFellowHeaderCell.h"

@implementation YFBillDetailFellowHeaderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFBillDetailFellowHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFBillDetailFellowHeaderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        
        [cell initUI];
    }
    return cell;
}


- (void)initUI {
    
    UILabel *contentLbl = [[UILabel alloc] init];
    [self addSubview:contentLbl];
    contentLbl.text = @"发单者获得佣金0.00元（默认显示前五条）";
    contentLbl.tag = 400;
    contentLbl.font = [UIFont systemFontOfSize:14];
    [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_offset(16 *SCALE_375);
    }];
    
    NSArray *titleArr = @[@"跟单用户", @"金额(元)", @"奖金(元)", @"佣金"];
    for (int i = 0; i < 4; i ++) {
        UILabel *titleLBl = [[UILabel alloc] init];
        [self addSubview:titleLBl];
        titleLBl.text = titleArr[i];
        titleLBl.textColor = Color_title_333;
        titleLBl.textAlignment = NSTextAlignmentCenter;
        titleLBl.font = [UIFont systemFontOfSize:14];
        [titleLBl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(FRAME_WIDTH / 4 *  i);
            make.width.mas_offset(FRAME_WIDTH / 4);
            make.bottom.mas_offset(0);
            make.height.mas_offset(42 *SCALE_375);
        }];
    }
    
    UIView *lineView = [[UIView alloc] init];
    [self addSubview:lineView];
    lineView.backgroundColor = UIColorFromRGB(0xe5e5e5);
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_offset(0);
        make.height.mas_offset(SCALE_375);
        make.left.mas_offset(0 *SCALE_375);
        make.right.mas_offset(- 0 *SCALE_375);
    }];
}

- (void)setPractica_amount:(NSString *)practica_amount {
    if (practica_amount == nil) {
        practica_amount = @"0,00";
    }
    UILabel *contentLbl = [self viewWithTag:400];
    contentLbl.text = [NSString stringWithFormat:@"发单者获得佣金%@元（默认显示前五条）", practica_amount];
    [contentLbl changeStringArr:@[practica_amount] andAllColor:Color_title_333 andMarkColor:[UIColor redColor] andMarkFondSize:13 *SCALE_375];
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
