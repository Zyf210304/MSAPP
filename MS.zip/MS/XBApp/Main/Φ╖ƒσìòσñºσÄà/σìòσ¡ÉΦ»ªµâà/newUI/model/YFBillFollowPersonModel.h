//
//  YFBillFollowPersonModel.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/18.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFBillFollowPersonModel : NSObject

@property (nonatomic, strong) NSNumber *buy_amount;

@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) NSNumber *practica_amount;

@property (nonatomic, strong) NSNumber *win_amount;

@end
