//
//  YFBillDetailHeader.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/15.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFBillDetailHeader : UIView

@property (nonatomic, copy) void(^typeDidSelect)(NSInteger count);

- (void)setVlaueWith:(NSInteger)count;

@end
