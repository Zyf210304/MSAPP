//
//  YFBillDetailFellowPersonCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/18.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBillDetailFellowPersonCell.h"
#import "YFBillFollowPersonModel.h"

@implementation YFBillDetailFellowPersonCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFBillDetailFellowPersonCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFBillDetailFellowPersonCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        
        [cell initUI];
    }
    return cell;
}



- (void)initUI {

    
    NSArray *titleArr = @[@"跟单用户", @"金额(元)", @"奖金(元)", @"佣金"];
    for (int i = 0; i < 4; i ++) {
        UILabel *titleLBl = [[UILabel alloc] init];
        [self addSubview:titleLBl];
        titleLBl.tag = 400 + i;
        titleLBl.text = titleArr[i];
        titleLBl.font = [UIFont systemFontOfSize:14];
        titleLBl.textColor = Color_title_333;
        titleLBl.textAlignment = NSTextAlignmentCenter;
        [titleLBl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(FRAME_WIDTH / 4 *  i);
            make.width.mas_offset(FRAME_WIDTH / 4);
            make.bottom.mas_offset(0);
            make.top.mas_offset(0);
        }];
    }
    
}

- (void)setValueWith:(YFBillFollowPersonModel *)personModel {
    NSArray *titleArr = @[personModel.name ? [NSString stringWithFormat:@"%@", personModel.name] : @"",
                          personModel.buy_amount ? [NSString stringWithFormat:@"%.2lf元", personModel.buy_amount.floatValue] : @"",
                          personModel.win_amount ? [NSString stringWithFormat:@"%.2lf元", personModel.win_amount.floatValue] : @"",
                          personModel.practica_amount ?[NSString stringWithFormat:@"%.2lf元", personModel.practica_amount.floatValue] : @""];
    for (int i = 0; i < 4; i ++) {
        UILabel *titleLBl = [self viewWithTag:400 + i];
        titleLBl.text = titleArr[i];
        titleLBl.textColor = i == 3 ? [UIColor redColor] : Color_title_333;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
