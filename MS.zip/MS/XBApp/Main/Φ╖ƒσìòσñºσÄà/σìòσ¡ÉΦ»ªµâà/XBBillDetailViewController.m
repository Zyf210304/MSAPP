//
//  XBBillDetailViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBBillDetailViewController.h"
#import "XBBillDetailViewControllerCell.h"
#import "QTBaseViewController+Table.h"

#import "YFBillDetailHeader.h"
#import "YFOrderSuccessVC.h"

#import "YFOrderStateBaseSchemeCell.h"


#import "YFBillDetailFellowHeaderCell.h"
#import "YFBillDetailFellowPersonCell.h"
#import "YFMatchModel.h"
#import "YFBillFollowPersonModel.h"
@interface XBBillDetailViewController ()<UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UIView *headVIEW;
@property (weak, nonatomic) IBOutlet UIImageView *imagehead;
@property (weak, nonatomic) IBOutlet UILabel *lbname;
@property (weak, nonatomic) IBOutlet UILabel *lbred;
@property (weak, nonatomic) IBOutlet UIButton *btnFollow;
@property (weak, nonatomic) IBOutlet UILabel *lbzhong;


@property (strong, nonatomic) IBOutlet UIView *View2;

@property (weak, nonatomic) IBOutlet UILabel *lbbillname;
@property (weak, nonatomic) IBOutlet UILabel *lbchuang;
@property (weak, nonatomic) IBOutlet UILabel *lbbao;
@property (weak, nonatomic) IBOutlet UILabel *lbordernum;



@property (strong, nonatomic) IBOutlet UIView *view3;

@property (weak, nonatomic) IBOutlet UILabel *lbzigou;
@property (weak, nonatomic) IBOutlet UILabel *lbtime;
@property (weak, nonatomic) IBOutlet UILabel *lbqitou;

@property (weak, nonatomic) IBOutlet UILabel *lbendtime;


@property (strong, nonatomic) IBOutlet UIView *bottomView;

@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *btns;

@property (weak, nonatomic) IBOutlet UIButton *btncut;

@property (weak, nonatomic) IBOutlet UITextField *lbshownum;
@property (weak, nonatomic) IBOutlet UIButton *btnadd;
@property (weak, nonatomic) IBOutlet UILabel *lbtip;

@property (weak, nonatomic) IBOutlet UIButton *btnbuy;

@property (strong, nonatomic) IBOutlet UIView *sessionView;

@property (weak, nonatomic) IBOutlet UILabel *lbSessionTip;

@property (strong, nonatomic) IBOutlet UIView *emptyView;

@property (nonatomic, strong) NSString *start_amount;

@property (nonatomic, strong) NSMutableDictionary *memberDic;


@property (nonatomic) NSInteger currentType;
@property (nonatomic, strong) NSMutableArray *SchemeArr;
@property (nonatomic, strong) NSMutableArray *memberArr;

@property (nonatomic, strong) UILabel *footerLbl;
@property (nonatomic, strong) NSString *practica_amount;


@property (nonatomic, strong) NSString *lottery_name;

@end

@implementation XBBillDetailViewController
{
    DGridView * grid;
}

- (NSMutableDictionary *)memberDic {
    if (_memberDic == nil) {
        self.memberDic = [NSMutableDictionary dictionary];
    }
    return _memberDic;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = _isSee ? @"订单详情" : @"发单详情";
    
    TABLEReg(XBBillDetailViewControllerCell, @"XBBillDetailViewControllerCell");
}

-(void)initUI {
    _currentType = 0;
    self.canRefresh = YES;
    [self initTable];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor=[Theme borderColor];
    self.tableView.separatorInset=UIEdgeInsetsMake(0, 15, 0, 0);
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 116;
    
    UILabel *footer = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, FRAME_WIDTH, 100)];
    _footerLbl = footer;
    footer.text = @"开赛可见";
    footer.textColor = Color_title_666;
    footer.font = [UIFont systemFontOfSize:20 *SCALE_375];
    footer.textAlignment = NSTextAlignmentCenter;
    self.tableView.tableFooterView = footer;
    
    
    [_btnadd addTapGesture:^{
        self.lbshownum.text=[NSString stringWithFormat:@"%zd" ,self.lbshownum.text.integerValue + 1];
        _lbtip.text = [NSString stringWithFormat:@"倍    %zd元", _start_amount.integerValue *self.lbshownum.text.integerValue];
        [_lbtip changeStringArr:@[[NSString stringWithFormat:@"%zd", _start_amount.integerValue *self.lbshownum.text.integerValue]] andAllColor:Color_title_333 andMarkColor:[UIColor redColor] andMarkFondSize:12];
    }];
    [_btncut addTapGesture:^{
        self.lbshownum.text=[NSString stringWithFormat:@"%zd" ,self.lbshownum.text.integerValue - 1];
        if (self.lbshownum.text.integerValue < 1) {
            self.lbshownum.text = @"1";
        }
        _lbtip.text = [NSString stringWithFormat:@"倍    %zd元", _start_amount.integerValue *self.lbshownum.text.integerValue];
        [_lbtip changeStringArr:@[[NSString stringWithFormat:@"%zd", _start_amount.integerValue *self.lbshownum.text.integerValue]] andAllColor:Color_title_333 andMarkColor:[UIColor redColor] andMarkFondSize:12];
    }];
    
    _lbshownum.delegate = self;

}

-(void)initData{
    
    NSArray * data=@[@"10",@"20",@"50",@"100"];
    
    for (UIButton * item in self.btns) {
        
        [item setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        item.backgroundColor=[UIColor whiteColor];
        item.borderColor=[UIColor lightGrayColor];
        item.borderWidth=1;
    }
    
    for (UIButton * btn in self.btns) {
        
        [btn click:^(id control) {
            for (UIButton * item in self.btns) {
                
                [item setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                item.backgroundColor=[UIColor whiteColor];
                item.borderColor=[UIColor lightGrayColor];
                item.borderWidth=1;
            }
            
            btn.borderColor=[UIColor lightGrayColor];
            btn.borderWidth=0;
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            btn.backgroundColor=[Theme themeColor];
            
            self.lbshownum.text=[NSString stringWithFormat:@"%@" ,data[btn.tag]];
            _lbtip.text = [NSString stringWithFormat:@"倍    %zd元", _start_amount.integerValue *self.lbshownum.text.integerValue];
            [_lbtip changeStringArr:@[[NSString stringWithFormat:@"%zd", _start_amount.integerValue *self.lbshownum.text.integerValue]] andAllColor:Color_title_333 andMarkColor:[UIColor redColor] andMarkFondSize:12];
        }];
        
    }
    
    
    
    
    
    [self.btns.firstObject setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    ((UIButton *)self.btns.firstObject).backgroundColor=[Theme themeColor];
     ((UIButton *)self.btns.firstObject).borderColor=[UIColor lightGrayColor];
     ((UIButton *)self.btns.firstObject).borderWidth=0;
    
    [self firstGetData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

#pragma  mark - table

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//    _
//    return 0;
    if (_currentType == 0) {
        if (_SchemeArr.count) {
            _footerLbl.text = @"";
            return _SchemeArr.count + 1;
        } else {
            _footerLbl.text = @"开赛可见";
            return 0;
        }
    }
    
    
    
    
    if (_currentType == 1) {
        if (self.memberArr.count) {
            _footerLbl.text = @"";
            return _memberArr.count + 1 > 6 ? 6 : _memberArr.count + 1;
        } else {
            _footerLbl.text = @"暂时无人跟单";
            return 0;
        }

    }
    return 0;
    return self.tableDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    if (_currentType == 0) {
        YFOrderStateBaseSchemeCell *cell = [YFOrderStateBaseSchemeCell cellWithTableView:tableView];
        NSNumber  *lottery_type_id = [_lottery_name isEqualToString:@"竞彩足球"] ? @1 : @2;
        [cell setVlaueWith:_SchemeArr andTypeId:lottery_type_id andCellRow:indexPath.row];
        return cell;
    }
    
    if (_currentType == 1) {
        if (indexPath.row == 0) {
            YFBillDetailFellowHeaderCell *cell = [YFBillDetailFellowHeaderCell cellWithTableView:tableView];
            cell.practica_amount = _practica_amount;
            return cell;
        } else {
            YFBillDetailFellowPersonCell *cell = [YFBillDetailFellowPersonCell cellWithTableView:tableView];
            [cell setValueWith:_memberArr[indexPath.row - 1]];
            return cell;
        }
    }

    static NSString *Identifier = @"XBBillDetailViewControllerCell";
    XBBillDetailViewControllerCell   *cell = [tableView dequeueReusableCellWithIdentifier:Identifier forIndexPath:indexPath];
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    
    [cell bind:dic];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_currentType == 0) {
        return  indexPath.row == 0 ? 40 *SCALE_375 : 60 *SCALE_375;
    }
    if (_currentType == 1) {
        return  indexPath.row == 0 ? 79 *SCALE_375 : 36 *SCALE_375;
    }
    
    return UITableViewAutomaticDimension;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
//    NSDictionary *dic = self.tableDataArray[indexPath.row];
    
}


#pragma mark - json

- (void)commonJson {
    
    
    [self showHUD];
    
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    dic[@"order_id"]=self.oid;
    [service post:@"/v1/documentary/sendOrderInfo" data:dic  complete:^(NSDictionary *value) {
        [super commonJson];
        
        [self hideHUD];
        
        self.memberDic[@"id"] = value[@"member_id"];
        self.memberDic[@"member_logo"] = value[@"member_logo"];
        self.memberDic[@"name"] = value[@"name"];
        
        
        self.lottery_name = value[@"lottery_name"];
        
        _practica_amount = value.str(@"practica_amount");
        //点击头像跳转
        WEAKSELF;
        [self.imagehead addTapGesture:^{
            [weakSelf toPagePersonBillDetail:_memberDic];
        }];
        
        self.SchemeArr = [NSMutableArray array];
        

            for (NSDictionary *schemDic in value[@"orderPackageList"]) {
                YFMatchModel *model = [[YFMatchModel alloc] init];
                [model setValuesForKeysWithDictionary:schemDic];
                
                if([[NSDate date] timeIntervalSince1970] > model.matchtime.integerValue / 1000) {
                    [self.SchemeArr addObject:model];
                }
                
            }

       
        
        
        
        self.memberArr = [NSMutableArray array];
        for (NSDictionary *remberDic in value[@"memberDocumenList"]) {
            YFBillFollowPersonModel *model = [[YFBillFollowPersonModel alloc] init];
            [model setValuesForKeysWithDictionary:remberDic];
            [self.memberArr addObject:model];
        }
        
        
        [self.btnbuy click:^(id control) {
            if (!USER_DATA.isLogin) {
                [self toPageLogin];
            }
            
            if (value.str(@"start_amount").integerValue *self.lbshownum.text.integerValue < 10) {
                [self showHint:@"下单不能低于10块"];
                return;
            }
            
            [self tureActioin:value.str(@"start_amount").integerValue];
            
        }];
        
        //张三
        grid = [[DGridView alloc] initWidth:APP_WIDTH];
        
        [grid setColumn:16 height:40];
        
        
        [grid addView:self.headVIEW margin:UIEdgeInsetsMake(0, 0, 0, 0)];
        
        [self.imagehead setImageWithURLString:value.str(@"member_logo") placeholderImageString:@"default_item_small"];
        

        
        
        
        
        if ([value.str(@"atten_status") isEqualToString:@"1"]) {
            [self.btnFollow setTitleColor:[Theme themeColor] forState:UIControlStateNormal];
            self.btnFollow.borderColor=[Theme themeColor];
        }
        else{
            [self.btnFollow setTitleColor:[UIColor colorHex:@"9A9A9A"] forState:UIControlStateNormal];
            self.btnFollow.borderColor=[UIColor colorHex:@"9A9A9A"];
            
        }
        
        
        [self.btnFollow click:^(id control) {
            
            [self loginedAction:^{
                NSMutableDictionary *dic=[NSMutableDictionary new ];
                dic[@"manito_member_id"]= value.num(@"member_id");
                service.dataType=DataTypeJson;
                [service post:@"/v1/member/attention" data:dic  complete:^(NSDictionary *value) {
                    
                    if ([value.str(@"atten_status") isEqualToString:@"1"]) {
                        [self.btnFollow setTitleColor:[Theme themeColor] forState:UIControlStateNormal];
                        self.btnFollow.borderColor=[Theme themeColor];
                    }
                    else{
                        [self.btnFollow setTitleColor:[UIColor colorHex:@"9A9A9A"] forState:UIControlStateNormal];
                        self.btnFollow.borderColor=[UIColor colorHex:@"9A9A9A"];
                        
                    }
                    
                    
                    
                }];
            }];
            
            
        }];
        
        
        self.lbname.text=value.str(@"name");
        self.lbred.text=[NSString stringWithFormat:@" %@连红 ",value.str(@"consecutive")];

        self.lbzhong.text=[NSString stringWithFormat:@" %@投%@中 ",value.str(@"order_count"),value.str(@"win_count")];
        self.lbordernum.text = [NSString stringWithFormat:@"订单编号%@", value.str(@"order_info_member")];
       
     
        [grid addView:self.View2 margin:UIEdgeInsetsMake(0, 0, 0, 0)];
        
           //修改部分
//        UILabel *desLbl2 = [[UILabel alloc] init];
//        [grid addSubview:desLbl2];
//        desLbl2.text = value.str(@"description");
//        [desLbl2 mas_makeConstraints:^(MASConstraintMaker *make) {
//            
//        }];
        
        UILabel *desLbl = [grid addhalfRowLabel:value.str(@"description")];
        desLbl.numberOfLines = 0;
        
        
        if (_isSee) {
            UIImageView *resulutImg = [[UIImageView alloc] init];
            [grid addSubview:resulutImg];
            [resulutImg mas_makeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(grid.mas_right).offset(-20);
                make.bottom.equalTo(desLbl.mas_bottom).offset(- 5);
                make.width.mas_offset(76);
                make.height.mas_offset(57);
            }];
            if ([value[@"if_win"]  isEqual: @1]) {
                resulutImg.image = [UIImage imageNamed:@"if_win_1"];
            } else if([value[@"if_win"]  isEqual: @0] ){
                
                resulutImg.image = [UIImage imageNamed:@"if_win_0"];
                
            } else {
                resulutImg.hidden = YES;
            }
        }
        
        
        
        self. lbbillname.text=value.str(@"lottery_name");
         self.lbchuang.text = value.str(@"pass_way");
        //            lbbao;
        //            lbordernum;
        
        [grid addView:self.view3 margin:UIEdgeInsetsMake(0, 0, 0, 0)];
        
        //
        self.lbzigou.text = [NSString stringWithFormat:@"自购 %@元  跟单%@人", value.str(@"buy_amount"), value.str(@"documentaryCount")];
        self.lbtime.text = [[value.str(@"create_tiem") substringWithRange:NSMakeRange(5, 11)] stringByAppendingString:@" 发单"];
        self.lbqitou.text= [NSString stringWithFormat:@"%@元起投",value.str(@"start_amount")];
        _start_amount = value.str(@"start_amount");
        _lbtip.text = [NSString stringWithFormat:@"倍    %zd元", _start_amount.integerValue *10];
        
        //
        self.lbendtime.text= [[value.str(@"end_tiem") substringWithRange:NSMakeRange(5, 11)] stringByAppendingString:@" 截止"];
        
        [self addBottomView:self.bottomView];
        
        self.tableView.tableHeaderView= grid;
        
        
        self.tableDataArray= value.arr(@"memberDocumenList");
        
        
        [self tableHandle];
        
        [_lbtip changeStringArr:@[[NSString stringWithFormat:@"%zd", _start_amount.integerValue *self.lbshownum.text.integerValue]] andAllColor:Color_title_333 andMarkColor:[UIColor redColor] andMarkFondSize:12];
    
        //判断  能不能跟单
        NSInteger endTime = [NSString timeSwitchTimestamp:value[@"end_tiem"] andFormatter:@"YYYY-MM-dd HH:mm:ss"];
        
        _bottomView.hidden = [[NSDate date] timeIntervalSince1970] > endTime;
        if ([value[@"if_win"] isEqual:@0] || [value[@"if_win"] isEqual:@1]) {
            _bottomView.hidden = YES;
        }
        
    }];
    
    
}

#pragma mark ----- 新UI
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    YFBillDetailHeader *header = [[YFBillDetailHeader alloc] init];
    WEAKSELF;
    [header setVlaueWith:_currentType];
    header.typeDidSelect = ^(NSInteger count) {
        _currentType = count;
        [weakSelf.tableView reloadData];
    };
    return header;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 40 *SCALE_375;
}


- (void)textFieldDidEndEditing:(UITextField *)textField {
    _lbtip.text = [NSString stringWithFormat:@"倍    %zd元", _start_amount.integerValue *self.lbshownum.text.integerValue];
    [_lbtip changeStringArr:@[[NSString stringWithFormat:@"%zd", _start_amount.integerValue *self.lbshownum.text.integerValue]] andAllColor:Color_title_333 andMarkColor:[UIColor redColor] andMarkFondSize:12];
}

#pragma mark  确认下单
- (void)tureActioin:(NSInteger)start_amount {
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"确认跟单" message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self sendOrederNetWork:start_amount];
    }];
    UIAlertAction *alertAction2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSLog(@"取消");
    }];
    //将两个按钮与alertController相关联
    [alertC addAction:alertAction2];
    [alertC addAction:alertAction1];
    
    //将alertController 显示
    [self presentViewController:alertC animated:YES completion:nil];
}



- (void)sendOrederNetWork:(NSInteger)start_amount {
    if (!USER_DATA.isLogin) {
        [self toPageLogin];
    }
    
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    
    dic[@"buy_amount"]= [NSString stringWithFormat:@"%zd", start_amount *self.lbshownum.text.integerValue];
    dic[@"mulriple"]=self.lbshownum.text;
    dic[@"orderId"]= _oid;
    
    [service post:@"v1/order/documentaryOrder" data:dic complete:^(NSDictionary *value) {
        [self gotoSuccessVC];
    }];
}

- (void)gotoSuccessVC {
    
    YFOrderSuccessVC *successVC = [[YFOrderSuccessVC alloc] init];
    successVC.buyAmount = @(_start_amount.integerValue *self.lbshownum.text.integerValue);
    [self.navigationController pushViewController:successVC animated:YES];
}

@end
