//
//  XBPersonBillDetailViewControllerCell.h
//  MSApp
//
//  Created by stephen on 2018/9/17.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "DTableViewCell.h"

@interface XBPersonBillDetailViewControllerCell : DTableViewCell

@property (nonatomic, copy) void(^followBlock)(void);

@end
