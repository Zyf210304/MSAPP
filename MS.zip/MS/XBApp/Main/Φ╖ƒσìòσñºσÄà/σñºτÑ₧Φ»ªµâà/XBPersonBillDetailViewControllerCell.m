//
//  XBPersonBillDetailViewControllerCell.m
//  MSApp
//
//  Created by stephen on 2018/9/17.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "XBPersonBillDetailViewControllerCell.h"

@interface XBPersonBillDetailViewControllerCell  ()


@property (weak, nonatomic) IBOutlet UIImageView *imageHead;
@property (weak, nonatomic) IBOutlet UILabel *lbname;

@property (weak, nonatomic) IBOutlet UILabel *lbContent;
@property (weak, nonatomic) IBOutlet UILabel *lbTime;

@property (weak, nonatomic) IBOutlet UILabel *lbSub;

@property (weak, nonatomic) IBOutlet UIImageView *lbImage2;

@property (strong, nonatomic) IBOutlet UILabel *followLbl;

@property (strong, nonatomic) IBOutlet UILabel *winAmountLbl;

@end


@implementation XBPersonBillDetailViewControllerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
    WEAKSELF;
    _followLbl.hidden = YES;
    [_followLbl addTapGesture:^{
        weakSelf.followBlock();
    }];
}

-(void)bind:(NSDictionary *)obj{
    
     [self.imageHead setImageWithURLString:obj.str(@"logo_url") placeholderImageString:@"default_item_small"];
    
    self.lbname.text=obj.str(@"lottery_name");
    
//    self.lbTime.text=[NSString stringWithFormat:@"%@ 截止",obj.dateMS(@"ticket_time").shortTimeString];
    self.lbTime.text = obj[@"create_time"];
    self.lbContent.text=obj.str(@"description");
    
    if ([obj.str(@"buy_way") isEqualToString:@"0"]) {
         self.lbSub.text=[NSString stringWithFormat:@"自购%@元 跟单%@人",obj.str(@"buy_amount"),obj.str(@"documentary_cout")];
    }
    else{
        self.lbSub.text=[NSString stringWithFormat:@"跟单%@元 跟单%@人",obj.str(@"buy_amount"),obj.str(@"documentary_cout")];
    }
    

    _followLbl.hidden = ([obj[@"if_win"]  isEqual: @0] || [obj[@"if_win"]  isEqual: @1]);
    
    if ([[NSDate date] timeIntervalSince1970] > obj.str(@"end_time").integerValue / 1000) {
        _followLbl.text  = @"已截止";
    } else {
        _followLbl.text  = @"立即跟单";
    }
    
    
    
    _lbImage2.hidden = !([obj[@"if_win"]  isEqual: @0] || [obj[@"if_win"]  isEqual: @1]);
    _winAmountLbl.hidden  = !([obj[@"if_win"]  isEqual: @0]);
    if ([obj[@"if_win"]  isEqual: @1]) {
        _lbImage2.image = [UIImage imageNamed:@"if_win_1"];
    } else {
        
        _lbImage2.image = [UIImage imageNamed:@"if_win_0"];
        _winAmountLbl.text = [[NSString stringWithFormat:@"中奖:%@", obj[@"win_amount"]] stringByAppendingString:@"元"];


    }
}

@end
