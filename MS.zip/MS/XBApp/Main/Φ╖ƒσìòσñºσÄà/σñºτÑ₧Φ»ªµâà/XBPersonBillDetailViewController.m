//
//  XBPersonBillDetailViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/17.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "XBPersonBillDetailViewController.h"
#import "XBPersonBillDetailViewControllerCell.h"
#import "QTBaseViewController+Table.h"
#import "XBBillDetailViewController.h"

#import "DSegmentedControl.h"

@interface XBPersonBillDetailViewController ()<DSegmentedControlDelegate>

@property (strong, nonatomic) IBOutlet UIView *headView;

@property (weak, nonatomic) IBOutlet UIImageView *imagehead;
@property (weak, nonatomic) IBOutlet UILabel *lbname;

@property (weak, nonatomic) IBOutlet UILabel *lbRenqiFensi;



@property (weak, nonatomic) IBOutlet UIButton *btnFollow;


@property (strong, nonatomic) IBOutlet UIView *secondView;

@property (weak, nonatomic) IBOutlet UILabel *lb2tip1;

@property (weak, nonatomic) IBOutlet UILabel *lb2tip2;


@property (weak, nonatomic) IBOutlet UILabel *lb2tip3;



@property (strong, nonatomic) IBOutlet UIView *thirdView;

@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *lbItems;



@end

@implementation XBPersonBillDetailViewController
{
    DGridView * grid;
    
    NSInteger type;
    
      DSegmentedControl * segmentedControl;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"";
    //用户详情
     TABLEReg(XBPersonBillDetailViewControllerCell, @"XBPersonBillDetailViewControllerCell");
}

-(void)initUI {
    
    //七日发单
    
    
    self.canRefresh = YES;
    [self initTable];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor=[Theme borderColor];
    self.tableView.separatorInset=UIEdgeInsetsMake(0, 15, 0, 0);
    
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 116;
    
}

-(void)initData{
    [self firstGetData];
    
    [self commonJsonInit];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)segumentSelectionChange:(NSInteger)selection
{
    
    type=selection;
    [self commonJson];
}

#pragma  mark - table

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *Identifier = @"XBPersonBillDetailViewControllerCell";
    XBPersonBillDetailViewControllerCell   *cell = [tableView dequeueReusableCellWithIdentifier:Identifier forIndexPath:indexPath];
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    
    [cell bind:dic];
    cell.followBlock = ^{
         [self toPageOrder:dic.str(@"id")];
        NSLog(@"跟单");
    };
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 120;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    XBBillDetailViewController *controller = [XBBillDetailViewController controllerFromXib];
    controller.oid = dic.str(@"id");
    controller.isSee = YES;
    [self.navigationController pushViewController:controller animated:YES];

    
}


#pragma mark - json


-(NSString *)listKey
{
    return @"list";
}

- (void)commonJson {
    
    [self showHUD];
    
    

    NSMutableDictionary *dic = [NSMutableDictionary new];
    
    dic[@"page_num"] = self.current_page;
    dic[@"page_size"] = PAGES_SIZE;
    dic[@"member_id"]=self.data.str(@"id");
    dic[@"if_win"] = @0;
    NSString * url;
    
    if (type==0) {
//        dic[@"documentaryOrderType"]= @(type);
        url=@"v1/order/selectQiRiSendOrder";
    }
    else{
        dic[@"if_win"] = @1;
        url=@"/v1/order/selectHistoryRedOrder";
    }
    

    [service post:url data:dic  complete:^(NSDictionary *value) {
        [self tableHandleValue:value];
    }];
    
}

- (void)commonJsonInit {
    

    
    [self showHUD];
    
    [service post:@"v1/member/findPersonCenter" data:nil  complete:^(NSDictionary *value2) {
        
        NSMutableDictionary *dic=[NSMutableDictionary new ];
        dic[@"manito_member_id"]=self.data.str(@"id");
        dic[@"member_id"]=value2.str(@"id");
    
        [service post:@"/v1/member/selectManitoOrderInfo" data:dic  complete:^(NSDictionary *value) {
            [super commonJson];
            
            [self hideHUD];
            
            self.navigationItem.title=self.data.str(@"name");
            
            grid = [[DGridView alloc]initWidth:APP_WIDTH];
            
            [grid setColumn:16 height:40];
            
            
            [grid addView:self.headView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
            
            [self.headView setBottomLine:[Theme borderColor]];
            
            [self.imagehead setImageWithURLString:self.data.str(@"member_logo") placeholderImageString:@"default_item_small"];
            
            self.lbname.text=self.data.str(@"name");
           
            NSMutableAttributedString * subString = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"人气:%@ | 粉丝:%@",value.str(@"popularity"),value.str(@"fans")]];
            
            [subString setColor:[Theme themeColor] string:value.str(@"popularity")];
            [subString setColor:[Theme themeColor] string:value.str(@"fans")];
            
            self.lbRenqiFensi.attributedText=subString;
            
            if ([value.str(@"atten_status") isEqualToString:@"1"]) {
                [self.btnFollow setTitleColor:[Theme themeColor] forState:UIControlStateNormal];
                self.btnFollow.borderColor=[Theme themeColor];
            }
            else{
                [self.btnFollow setTitleColor:[UIColor colorHex:@"9A9A9A"] forState:UIControlStateNormal];
                self.btnFollow.borderColor=[UIColor colorHex:@"9A9A9A"];
                
            }
            
            NSMutableAttributedString * t1=[[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@投%@中\n7日命中",value.str(@"order_count"),value.str(@"win_count")]];
            [t1 setParagraphStyle:^(NSMutableParagraphStyle * _Nonnull paragraph) {
                paragraph.lineSpacing=5;
            }];
            self.lb2tip1.attributedText=t1;
            self.lb2tip1.textAlignment=NSTextAlignmentCenter;
            
             NSMutableAttributedString * t2=[[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%.2lf元\n7日奖金",value.str(@"bonus").floatValue]];
            
            [t2 setParagraphStyle:^(NSMutableParagraphStyle * _Nonnull paragraph) {
                paragraph.lineSpacing=5;
            }];
            self.lb2tip2.attributedText=t2;
             self.lb2tip2.textAlignment=NSTextAlignmentCenter;
            
              NSMutableAttributedString * t3=[[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@连红\n连续红单",value.str(@"consecutive")]];
            [t3 setParagraphStyle:^(NSMutableParagraphStyle * _Nonnull paragraph) {
                paragraph.lineSpacing=5;
            }];
            self.lb2tip3.attributedText=t3;
             self.lb2tip3.textAlignment=NSTextAlignmentCenter;
            
            
            [self.btnFollow click:^(id control) {
                
                [self loginedAction:^{
                    NSMutableDictionary *dic=[NSMutableDictionary new ];
                    dic[@"manito_member_id"]=self.data.str(@"id");
                    service.dataType=DataTypeJson;
                    [service post:@"/v1/member/attention" data:dic  complete:^(NSDictionary *value) {
                        
                        if ([value.str(@"atten_status") isEqualToString:@"1"]) {
                            [self.btnFollow setTitleColor:[Theme themeColor] forState:UIControlStateNormal];
                            self.btnFollow.borderColor=[Theme themeColor];
                        }
                        else{
                            [self.btnFollow setTitleColor:[UIColor colorHex:@"9A9A9A"] forState:UIControlStateNormal];
                            self.btnFollow.borderColor=[UIColor colorHex:@"9A9A9A"];
                            
                        }
                        
                        
                        
                    }];
                }];
                
                
            }];
            
            
            //进五期
            NSArray *billArr = value[@"list"];
            NSInteger showCount = billArr.count > 5 ?  5 : billArr.count;

            for (int i = 0; i < showCount; i ++) {
                NSDictionary *billDic = billArr[i];
                UILabel *showLbl = [_thirdView viewWithTag:300 + i];
                showLbl.hidden = NO;
                if ([billDic[@"if_win"] isEqual:@0]) {
                    showLbl.text = @"中";
                    showLbl.backgroundColor = [UIColor redColor];
                } else {
                    showLbl.text = @"未";
                    showLbl.backgroundColor = [UIColor grayColor];
                }
            }
            
            
            [grid addView:self.secondView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
            
            [self.secondView setBottomLine:[Theme borderColor]];
            
            [grid addView:self.thirdView margin:UIEdgeInsetsMake(0, 0, 0, 0)];
            
            [grid addLineForHeight:10 color:[Theme borderColor]];
            
            segmentedControl = [[DSegmentedControl alloc]initWithFrame:CGRectMake(0, 0, APP_WIDTH, 40)];
            [QTTheme segmentStyle1:segmentedControl];
            segmentedControl.delegate = self;
            [segmentedControl addGesture:self.view];
            [segmentedControl AddSegumentArray:@[@"七日发单", @"历史红单"]];
            
            [grid addView:segmentedControl margin:UIEdgeInsetsMake(0, 0, 0, 0)];
            
            self.tableView.tableHeaderView=grid;
            
        }];
        
    }];
    
    
   
    
    
}




@end
