//
//  XBPersonBillDetailViewController.h
//  MSApp
//
//  Created by stephen on 2018/9/17.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "QTBaseViewController.h"

@interface XBPersonBillDetailViewController : QTBaseViewController


@property (nonatomic , strong ) NSDictionary *data;

@end
