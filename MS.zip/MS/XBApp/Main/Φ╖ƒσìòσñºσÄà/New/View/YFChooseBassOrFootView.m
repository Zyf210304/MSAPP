//
//  YFChooseBassOrFootView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/25.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFChooseBassOrFootView.h"

@implementation YFChooseBassOrFootView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}


- (void)initUI {
    UIImageView *bgImg = [[UIImageView alloc] init];
    [self addSubview:bgImg];
    bgImg.image = [UIImage imageNamed:@"choose_BG"];
    [bgImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
    }];
    
    [self addFootball];
    [self addBasketBall];
}

- (void)addFootball {
    UIView *footerView = [[UIView alloc] init];
    [self addSubview:footerView];
    [footerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(11 *SCALE_375);
        make.left.right.mas_offset(0);
        make.height.mas_offset(47 *SCALE_375);
    }];
    footerView.tag = 200;
    [footerView addTapgestureWithTarget:self action:@selector(chooseDidSelect:)];
    
    UIImageView *picImg = [[UIImageView alloc] init];
    [footerView addSubview:picImg];
    picImg.image = [UIImage imageNamed:@"foot_icon"];
    [picImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(14 *SCALE_375);
        make.width.height.mas_offset(30 *SCALE_375);
        make.centerY.equalTo(footerView.mas_centerY);
    }];
    
    UILabel *titleLbl = [[UILabel alloc] init];
    [footerView addSubview:titleLbl];
    titleLbl.text = @"竞彩足球";
    titleLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    titleLbl.textColor = Color_title_333;
    [titleLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(picImg.mas_right).offset(17 *SCALE_375);
        make.centerY.equalTo(footerView.mas_centerY);
    }];
    
    UIView *lineView = [[UIView alloc] init];
    [self addSubview:lineView];
    lineView.backgroundColor = UIColorFromRGB(0xe5e5e5);
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_offset(0);
        make.height.mas_offset(SCALE_375);
        make.left.mas_offset(0 *SCALE_375);
        make.right.mas_offset(- 0 *SCALE_375);
    }];
}


- (void)addBasketBall {
    UIView *basketView = [[UIView alloc] init];
    [self addSubview:basketView];
    [basketView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_offset(0 *SCALE_375);
        make.left.right.mas_offset(0);
        make.height.mas_offset(47 *SCALE_375);
    }];
    basketView.tag = 201;
    [basketView addTapgestureWithTarget:self action:@selector(chooseDidSelect:)];
    
    UIImageView *picImg = [[UIImageView alloc] init];
    [basketView addSubview:picImg];
    picImg.image = [UIImage imageNamed:@"basket_icon"];
    [picImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(14 *SCALE_375);
        make.width.height.mas_offset(30 *SCALE_375);
        make.centerY.equalTo(basketView.mas_centerY);
    }];
    
    UILabel *titleLbl = [[UILabel alloc] init];
    [basketView addSubview:titleLbl];
    titleLbl.text = @"竞彩篮球";
    titleLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    titleLbl.textColor = Color_title_333;
    [titleLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(picImg.mas_right).offset(17 *SCALE_375);
        make.centerY.equalTo(basketView.mas_centerY);
    }];
}

- (void)chooseDidSelect:(UITapGestureRecognizer *)sender {
    self.hidden = YES;
    self.typeDidChoose(sender.view.tag - 200);
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
