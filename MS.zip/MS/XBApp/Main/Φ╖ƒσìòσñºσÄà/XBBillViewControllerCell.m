
//
//  XBBillViewControllerCell.m
//  MSApp
//
//  Created by stephen on 2018/9/6.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBBillViewControllerCell.h"

@interface XBBillViewControllerCell  ()
@property (weak, nonatomic) IBOutlet UIImageView *imageLogo;

@property (weak, nonatomic) IBOutlet UILabel *lbName;

@property (weak, nonatomic) IBOutlet UILabel *lbtip1;
@property (weak, nonatomic) IBOutlet UILabel *lbtip2;

@property (weak, nonatomic) IBOutlet UILabel *lbComment;
@property (strong, nonatomic) IBOutlet UILabel *endTime;


@property (weak, nonatomic) IBOutlet UILabel *lbzu;
@property (weak, nonatomic) IBOutlet UILabel *lbzi;
@property (weak, nonatomic) IBOutlet UILabel *lbYI;

@property (strong, nonatomic) IBOutlet UILabel *lbType;

@end


@implementation XBBillViewControllerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
}

-(void)bind:(NSDictionary *)obj{
      [self.imageLogo setImageWithURLString:obj.str(@"member_logo") placeholderImageString:@"default_item_small"];
    
    self.imageLogo.layer.masksToBounds = YES;
    self.imageLogo.layer.cornerRadius = 25;
    
    self.lbName.text=obj.str(@"name");
    self.lbComment.text=obj.str(@"description");
    
    self.lbtip1.text= [NSString stringWithFormat:@" %@连红 ",obj.str(@"consecutive")];  ;
    
    self.lbtip2.text=[NSString stringWithFormat:@" %@中%@ ",obj.str(@"order_count") ,obj.str(@"win_count")];  ;
    
    self.lbzu.text= obj.str(@"pass_way"); //obj.str(@"documentaryCount");
    
    self.lbzi.text= [obj.str(@"buy_amount") stringByAppendingString:@"元"];
    
    self.lbYI.text= [NSString stringWithFormat:@"%@人", obj[@"documentaryCount"]];
    
    self.endTime.text = [NSString stringWithFormat:@"截止时间\n%@", [NSString getThisTime:@(obj.str(@"end_time").integerValue)]];
    
    self.lbType.text = obj[@"lottery_name"];
    //猫狮虎
}

@end
