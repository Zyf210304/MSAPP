//
//  XBBillViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/6.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBBillViewController.h"
#import "XBBillViewControllerCell.h"
#import "QTBaseViewController+Table.h"
#import "DSegmentedControl.h"
#import "XBBillView.h"
#import "XBHallofFameViewController.h"
#import "XBAttentionViewController.h"
#import "XBAttentionViewControllerCell.h"
#import "XBAccountBillViewController.h"

#import "YFChooseMatchVC.h"
#import "YFBasketBallMatchVC.h"

#import "YFOrderListChildVC.h"

#import "YFChooseBassOrFootView.h"


#import "YFSearchUserAboutVC.h"

@interface XBBillViewController ()<DSegmentedControlDelegate>

@property (strong, nonatomic) IBOutlet UIView *head1;
@property (strong, nonatomic) IBOutlet UIView *head2;
@property (weak, nonatomic) IBOutlet UILabel *lbNotice;



@property (strong, nonatomic) IBOutlet UIView *head3;


@property (weak, nonatomic) IBOutlet UIView *view1;

@property (weak, nonatomic) IBOutlet UIView *view2;
@property (weak, nonatomic) IBOutlet UIView *view3;


@property (nonatomic, strong) YFChooseBassOrFootView *chooseView;

@end

@implementation XBBillViewController
{
    NSInteger type;
    
    DStackView * stack;
    
    DSegmentedControl * segmentedControl;
    
    
     DWrapView * wrap;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"";
    
     TABLEReg(XBBillViewControllerCell, @"XBBillViewControllerCell");
    
     TABLEReg(XBAttentionViewControllerCell, @"XBAttentionViewControllerCell");
    
}


-(void)initUI {
    
    WEAKSELF;
    
    self.canRefresh = YES;
    [self initTable];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor=[Theme borderColor];
    self.tableView.separatorInset=UIEdgeInsetsMake(0, 15, 0, 0);
    
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 116;
    
    
    stack = [[DStackView alloc]initWidth:APP_WIDTH];
    
    
    [stack addView:self.head1 margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    [self.head1 setBottomLine:[Theme backgroundColor]];
    
    [stack addView:self.head2 margin:UIEdgeInsetsMake(0, 0, 0, 0)];

    [stack addLineForHeight:10 color:[Theme backgroundColor]];
    
    [stack addView:self.head3 margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    [_head3 addTapGesture:^{
        YFSearchUserAboutVC *aboutVC = [[YFSearchUserAboutVC alloc] init];
        [weakSelf.navigationController pushViewController:aboutVC animated:YES];
    }];
    
    
    
    
    [self.head3 setBottomLine:[Theme backgroundColor]];
    
    wrap = [[DWrapView alloc]initWidth:APP_WIDTH columns:4];
    wrap.backgroundColor =  [UIColor whiteColor];
    wrap.subHeight = 100;
    
    [stack addView:wrap margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    [stack addLineForHeight:10 color:[Theme backgroundColor]];
    
    
    segmentedControl = [[DSegmentedControl alloc]initWithFrame:CGRectMake(0, 0, APP_WIDTH, 40)];
    [QTTheme segmentStyle1:segmentedControl];
    segmentedControl.delegate = self;
    [segmentedControl addGesture:self.view];
    [segmentedControl AddSegumentArray:@[@"热门跟单", @"人气跟单",@"我的关注"]];


    
    [stack addView:segmentedControl margin:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    self.tableView.tableHeaderView=stack;
    
}

-(void)initData{
    
    
    [self.view1 addTapGesture:^{
        XBHallofFameViewController *controller = [XBHallofFameViewController controllerFromXib];
        
        [NAVIGATION pushViewController:controller animated:YES];
    }
    ];
    [self.view2 addTapGesture:^{
        XBAttentionViewController *controller = [XBAttentionViewController controllerFromXib];
        
        [NAVIGATION pushViewController:controller animated:YES];
    }
     ];
    [self.view3 addTapGesture:^{
//        XBAccountBillViewController *controller = [XBAccountBillViewController controllerFromXib];
//
//        [NAVIGATION pushViewController:controller animated:YES];
        YFOrderListChildVC *childVC = [[YFOrderListChildVC alloc] init];
        childVC.TypeCount = 1;
        [self.navigationController pushViewController:childVC animated:YES];
    }];
    
    
    [self firstGetData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
      self.view.height= APP_HEIGHT -self.tabBarHeight-self.navegationBarHeight;
    
    self.tabBarController.navigationItem.title = @"跟单大厅";
    
    WEAKSELF;
    [self.tabBarController setLeftBarImage:[UIImage imageNamed:@"bill_left"] block:^{
        [weakSelf toSharepage];
    }];
    

    [self.tabBarController setRightBarImage:[UIImage imageNamed:@"bill_right"] block:^{
        if (!USER_DATA.isLogin) {
            [weakSelf toPageLogin];
        }
        else{
            weakSelf.chooseView.hidden = !weakSelf.chooseView.isHidden;
        }
    }];
    
    
    if (!USER_DATA.isLogin) {
        [self toPageLogin];
    } else {
        [self commonJson];
    }
    
    
}

- (void)segumentSelectionChange:(NSInteger)selection
{
    
    type=selection;
    [self commonJson];
}

#pragma  mark - table

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
//    if (type==2) {
//        static NSString *Identifier = @"XBAttentionViewControllerCell";
//        XBAttentionViewControllerCell   *cell = [tableView dequeueReusableCellWithIdentifier:Identifier forIndexPath:indexPath];
//
//        NSDictionary *dic = self.tableDataArray[indexPath.row];
//
//        [cell bind:dic];
//
//        return cell;
//    }
//    else{
        static NSString *Identifier = @"XBBillViewControllerCell";
        XBBillViewControllerCell   *cell = [tableView dequeueReusableCellWithIdentifier:Identifier forIndexPath:indexPath];
        
        NSDictionary *dic = self.tableDataArray[indexPath.row];
        
        [cell bind:dic];
        
        return cell;
//    }
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (type==2) {
//        return 80;
//    }
    return 160;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
//    if (type == 2) {
//        NSMutableDictionary * memberDic = [NSMutableDictionary dictionary];
//        memberDic[@"id"] = dic[@"member_id"];
//        memberDic[@"member_logo"] = dic[@"member_logo"];
//        memberDic[@"name"] = dic[@"name"];
//        [self toPagePersonBillDetail:memberDic];
//    } else {
    
        [self toPageOrder:dic.str(@"id")];
//    }
   
    
}


#pragma mark - json


-(NSString *)listKey
{
    return @"list";
}

- (void)commonJson {
    
    [self showHUD];
    
    {
    NSMutableDictionary *dic=[NSMutableDictionary new ];
    
    [service post:@"/v1/documentary/hall" data:dic  complete:^(NSDictionary *value) {
        
       NSString * string =  [value.arr(@"announcements")getArrayForKey:@"arti_name"].firstObject;
        
        self.lbNotice.text=string;
        
        
        NSArray * array = value.arr(@"myGoldLists");
       

        [wrap clearSubviews];
        
        for (int i = 0; i < array.count; i++) {
            
            XBBillView *item = [XBBillView viewNib];
            item.width = wrap.subHeight;
            item.height = wrap.subHeight;
           
            [item bind:array[i]];
            
            WEAKSELF;
            [item addTapGesture:^{
                NSDictionary * dic = array[i];
                [weakSelf toPagePersonBillDetail:dic];
            }];

            [wrap addView:item margin:UIEdgeInsetsMake(0, 0, 40, 0)];
        }
        
        [stack updateView];
        
        self.tableView.tableHeaderView=stack;

        
    }];
    }
    
    NSMutableDictionary *dic = [NSMutableDictionary new];
    
    dic[@"page_num"] = self.current_page;
    dic[@"page_size"] = PAGES_SIZE;
    
    NSString * url;
    
//    if (type==1||type==0) {
        dic[@"documentaryOrderType"]= @(type);
        url=@"/v1/documentary/hotAndPopulaDocumentaryOrder";
//    }
//    else{
//          url=@"/v1/member/FansList";
//    }
    
    
    [service post:url data:dic  complete:^(NSDictionary *value) {
       
        
//        if (type==2) {
//            self.tableDataArray= value.arr(@"list");
//            [self tableHandle];
//        }
//        else{
             [self tableHandleValue:value];
//        }
    }];

}


- (YFChooseBassOrFootView *)chooseView {
    if (_chooseView == nil) {
        
        self.chooseView = [[YFChooseBassOrFootView alloc] init];
        [self.view addSubview:_chooseView];
        [_chooseView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_offset(139 *SCALE_375);
            make.height.mas_offset(105 *SCALE_375);
            make.top.mas_offset(3 *SCALE_375);
            make.right.mas_offset(- 13 *SCALE_375);
        }];
        
        _chooseView.hidden = YES;
        
        
        _chooseView.typeDidChoose = ^(NSInteger Count) {
            if (Count == 0) {
                YFChooseMatchVC *controller = [[YFChooseMatchVC alloc] init];
                controller.isSend = YES;
                [NAVIGATION pushViewController:controller animated:YES];
            } else {
                YFBasketBallMatchVC *basketVC = [[YFBasketBallMatchVC alloc] init];
                basketVC.isSend = YES;
                [NAVIGATION pushViewController:basketVC animated:YES];
            }
        };
    }
    
    return _chooseView;
}


@end
