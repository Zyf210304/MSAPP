//
//  XBBillView.m
//  MSApp
//
//  Created by stephen on 2018/9/10.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBBillView.h"

@interface XBBillView ()

@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UILabel *lbTitle;

@property (weak, nonatomic) IBOutlet UILabel *lbNUm;

@end

@implementation XBBillView
-(void)bind:(NSDictionary *)obj
{
     [self.image setImageWithURLString:obj.str(@"member_logo") placeholderImageString:@"default_item_small"];
    
    
    self.lbTitle.text=obj.str(@"name");
    
    self.lbNUm.hidden = YES;
    if ([obj.str(@"documentary_state") isEqualToString:@"0"]) {
         self.lbNUm.hidden=YES;
    }
    else
    {


        self.lbNUm.text=obj.str(@"documentary_state");
        self.lbNUm.hidden=NO;
    }
    
   
}


@end
