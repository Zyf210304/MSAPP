//
//  XBHallofFameViewControllerCell.h
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "DTableViewCell.h"

@interface XBHallofFameViewControllerCell : DTableViewCell

@property (nonatomic , assign ) NSInteger row;

@end
