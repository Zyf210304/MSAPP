//
//  XBHallofFameViewControllerCell.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBHallofFameViewControllerCell.h"

@interface XBHallofFameViewControllerCell  ()

@property (weak, nonatomic) IBOutlet UILabel *lbNum;
@property (weak, nonatomic) IBOutlet UIImageView *images;
@property (weak, nonatomic) IBOutlet UILabel *lbName;

@property (weak, nonatomic) IBOutlet UILabel *lbOff;


@end


@implementation XBHallofFameViewControllerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
}

-(void)bind:(NSDictionary *)obj
{
    
    if (self.row==0) {
        NSMutableAttributedString * atr = [[NSMutableAttributedString alloc]init];
        [atr appendImageName:@"bill_1"];
        self.lbNum.attributedText=atr;
    }
   else if (self.row==1) {
       NSMutableAttributedString * atr = [[NSMutableAttributedString alloc]init];
       [atr appendImageName:@"bill_2"];
       self.lbNum.attributedText=atr;
    }
   else if (self.row==2) {
       NSMutableAttributedString * atr = [[NSMutableAttributedString alloc]init];
       [atr appendImageName:@"bill_3"];
       self.lbNum.attributedText=atr;
    }
    else{
        self.lbNum.text=[NSString stringWithFormat:@"%ld",(long)self.row+1];

    }
    [self.images setImageWithURLString:obj.str(@"member_logo") placeholderImageString:@"default_item_small"];
    
    self.lbName.text=obj.str(@"name");
    
    if (obj.str(@"documentary_state").floatValue > 0) {
        self.lbOff.text= obj.str(@"documentary_state");
        self.lbOff.hidden = NO;
    } else {
        self.lbOff.hidden = YES;
    }
    
    
}

@end
