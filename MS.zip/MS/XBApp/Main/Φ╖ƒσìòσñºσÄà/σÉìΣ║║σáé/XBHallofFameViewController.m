//
//  XBHallofFameViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/11.
//  Copyright © 2018 stephen. All rights reserved.
//

#import "XBHallofFameViewController.h"
#import "XBHallofFameViewControllerCell.h"
#import "QTBaseViewController+Table.h"

@interface XBHallofFameViewController ()

@end

@implementation XBHallofFameViewController
{
   
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"米神榜";
    
     TABLEReg(XBHallofFameViewControllerCell, @"XBHallofFameViewControllerCell");
}

-(void)initUI {
    
    self.canRefresh = YES;
    [self initTable];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor=[Theme borderColor];
    self.tableView.separatorInset=UIEdgeInsetsMake(0, 15, 0, 0);
    
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 116;
    
}

-(void)initData{
    [self firstGetData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
     [self setBalckNavigation];
}

#pragma  mark - table

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tableDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *Identifier = @"XBHallofFameViewControllerCell";
    XBHallofFameViewControllerCell   *cell = [tableView dequeueReusableCellWithIdentifier:Identifier forIndexPath:indexPath];
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    
    cell.row=indexPath.row;
    
    [cell bind:dic];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary *dic = self.tableDataArray[indexPath.row];
    [self toPagePersonBillDetail:dic];
}


#pragma mark - json

-(NSString *)listKey
{
    return @"list";
}

- (void)commonJson {
    NSMutableDictionary *dic = [NSMutableDictionary new];
    
    dic[@"page_num"] = self.current_page;
    dic[@"page_size"] = PAGES_SIZE;
    
    [service post:@"/v1/member/hallOfFameList" data:dic  complete:^(NSDictionary *value) {
        [self tableHandleValue:value];
    }];
}


@end
