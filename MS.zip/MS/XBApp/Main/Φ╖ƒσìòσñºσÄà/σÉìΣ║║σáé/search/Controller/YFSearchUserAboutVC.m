//
//  YFSearchUserAboutVC.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFSearchUserAboutVC.h"
#import "UIViewController+page.h"

#import "YFSearchView.h"
#import "YFSearchPersonCell.h"

#import "YFSearchPersonModel.h"
@interface YFSearchUserAboutVC ()<UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *dataSource;

@end

@implementation YFSearchUserAboutVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataSource = [NSMutableArray array];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setBalckNavigation];
    self.title = @"搜索";
    [self initUI];
}


- (void)initUI {
    YFSearchView *searchView = [[YFSearchView alloc] init];
    [self.view addSubview:searchView];
    searchView.searchTF.delegate = self;
    [searchView.searchTF addTarget:self action:@selector(textFieldDidChanged:) forControlEvents:(UIControlEventEditingChanged)];
    searchView.searchTF.returnKeyType = UIReturnKeySearch;
    [searchView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(40 *SCALE_375);
        if (@available(iOS 11.0,*)) {
            make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
        }else{
            make.top.mas_equalTo(Statur_HEIGHT + NAVIBAR_HEIGHT);
        }
    }];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    [self.view addSubview:tableView];
    self.tableView = tableView;
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(searchView.mas_bottom);
        make.left.right.mas_offset(0);
        if (@available(iOS 11.0,*)) {
            make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        }else{
            make.bottom.mas_equalTo(0);
        }
    }];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
    
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataSource.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFSearchPersonCell *cell = [YFSearchPersonCell cellWithTableView:tableView];
    [cell setValueWith:_dataSource[indexPath.row]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSMutableDictionary *memberDic = [NSMutableDictionary dictionary];
    YFSearchPersonModel *modle = _dataSource[indexPath.row];
    memberDic[@"id"] = modle.ID;
    memberDic[@"member_logo"] = modle.member_logo;
    memberDic[@"name"] = modle.name;
    [self toPagePersonBillDetail:memberDic];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self searchUserNetWork:textField.text];
    [self.view endEditing:YES];
    return YES;
}


- (void)textFieldDidChanged:(UITextField *)textField {
    NSLog(@"%@", textField.text);
    [self searchUserNetWork:textField.text];
}



- (void)searchUserNetWork:(NSString *)keyWord {

    NSDictionary *paramters = @{@"manito_member_name":keyWord,};
    [[YFNetBaseManager sharedConnect] postWithPortName:@"/v1/documentary/findGodInfo" parameters:paramters hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        [self.dataSource removeAllObjects];
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
            NSArray *listArr = responseObject[@"myGoldLists"];
            for (NSDictionary *dataDic in listArr) {
                YFSearchPersonModel *model = [[YFSearchPersonModel alloc] init];
                [model setValuesForKeysWithDictionary:dataDic];
                [self.dataSource addObject:model];
            }
            [self.tableView reloadData];
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
