//
//  YFSearchPersonModel.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFSearchPersonModel : NSObject

@property (nonatomic, strong) NSNumber *ID;

@property (nonatomic, strong) NSString *member_logo;

@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) NSNumber *buyOrderCount;

@property (nonatomic, strong) NSNumber *countWinOrder;

@property (nonatomic, strong) NSNumber *documentary_state;

@property (nonatomic, strong) NSNumber *recentKeepRedCounts;


@end
