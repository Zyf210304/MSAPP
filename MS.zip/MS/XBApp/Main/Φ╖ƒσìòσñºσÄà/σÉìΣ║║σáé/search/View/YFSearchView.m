//
//  YFSearchView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFSearchView.h"

@implementation YFSearchView

- (instancetype)initWithFrame:(CGRect)frame {
    self =[super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}


- (void)initUI {
    
    UIImageView *searchImg = [[UIImageView alloc] init];
    [self addSubview:searchImg];
    searchImg.image = [UIImage imageNamed:@"search_icon"];
    [searchImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(5);
        make.width.height.mas_offset(20);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    UITextField *searchTF = [[UITextField alloc] init];
    [self addSubview:searchTF];
    _searchTF = searchTF;
    [searchTF mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(searchImg.mas_right).offset(5 *SCALE_375);
        make.top.bottom.mas_offset(0);
        make.right.mas_offset(- 20 *SCALE_375);
    }];
    searchTF.font = [UIFont systemFontOfSize:14 *SCALE_375];
    searchTF.textColor = Color_title_333;
    searchTF.placeholder = @"请输入您要查找的名字";
    
    UIView *lineView = [[UIView alloc] init];
    [self addSubview:lineView];
    lineView.backgroundColor = UIColorFromRGB(0xe5e5e5);
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_offset(0);
        make.height.mas_offset(SCALE_375);
        make.left.mas_offset(0 *SCALE_375);
        make.right.mas_offset(- 0 *SCALE_375);
    }];
}





/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
