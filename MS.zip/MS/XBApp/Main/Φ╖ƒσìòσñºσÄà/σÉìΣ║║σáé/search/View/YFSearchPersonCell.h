//
//  YFSearchPersonCell.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YFSearchPersonModel;

@interface YFSearchPersonCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;

- (void)setValueWith:(YFSearchPersonModel *)personModel;

@end
