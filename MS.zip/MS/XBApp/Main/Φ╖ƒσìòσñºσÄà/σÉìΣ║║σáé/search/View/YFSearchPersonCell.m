//
//  YFSearchPersonCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFSearchPersonCell.h"
#import "YFSearchPersonModel.h"

@interface YFSearchPersonCell()

@property (nonatomic, strong) UIImageView *leftImg;

@property (nonatomic, strong) UILabel *leftLbl;

@property (nonatomic, strong) UILabel *rightWinLbl;

@property (nonatomic, strong) UILabel *rightConLbl;

@end

@implementation YFSearchPersonCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFSearchPersonCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFSearchPersonCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        
        [cell initUI];
    }
    return cell;
}


- (void)initUI {
    
    UIImageView *leftImg = [[UIImageView alloc] init];
    [self addSubview:leftImg];
    _leftImg = leftImg;
    leftImg.image = [UIImage imageNamed:@"default_item_small"];
    leftImg.layer.masksToBounds = YES;
    leftImg.layer.cornerRadius = 17.5 *SCALE_375;
    [leftImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(10 *SCALE_375);
        make.width.height.mas_offset(35 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    UILabel *leftLbl = [[UILabel alloc] init];
    [self addSubview:leftLbl];
    _leftLbl = leftLbl;
    leftLbl.text = @"用户姓名";
    leftLbl.textColor = Color_title_333;
    leftLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [leftLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(leftImg.mas_right).offset(4 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    UILabel *rightWinLbl = [[UILabel alloc] init];
    [self addSubview:rightWinLbl];
    _rightWinLbl = rightWinLbl;
    rightWinLbl.text = @"0中0";
    rightWinLbl.textColor = [UIColor whiteColor];
    rightWinLbl.textAlignment = NSTextAlignmentCenter;
    rightWinLbl.backgroundColor = [UIColor redColor];
    rightWinLbl.font = [UIFont systemFontOfSize: 11 *SCALE_375];
    rightWinLbl.layer.masksToBounds = YES;
    rightWinLbl.layer.cornerRadius = 2;
    [rightWinLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-20 *SCALE_375);
        make.height.mas_offset(20 *SCALE_375);
        make.width.mas_offset(70 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    UILabel *rightConLbl = [[UILabel alloc] init];
    [self addSubview:rightConLbl];
    _rightConLbl = rightConLbl;
    rightConLbl.text = @"0连红";
    rightConLbl.textColor = Color_title_333;
    rightConLbl.textAlignment = NSTextAlignmentCenter;
    rightConLbl.backgroundColor = [UIColor whiteColor];
    rightConLbl.font = [UIFont systemFontOfSize: 11 *SCALE_375];
    rightConLbl.layer.masksToBounds = YES;
    rightConLbl.layer.cornerRadius = 2;
    rightConLbl.layer.borderWidth = 1;
    rightConLbl.layer.borderColor = [UIColor redColor].CGColor;
    [rightConLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-88 *SCALE_375);
        make.height.mas_offset(20 *SCALE_375);
        make.width.mas_offset(70 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    
    
    UIView *lineView = [[UIView alloc] init];
    [self addSubview:lineView];
    lineView.backgroundColor = UIColorFromRGB(0xe5e5e5);
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_offset(0);
        make.height.mas_offset(SCALE_375);
        make.left.mas_offset(0 *SCALE_375);
        make.right.mas_offset(- 0 *SCALE_375);
    }];
}


- (void)setValueWith:(YFSearchPersonModel *)personModel {
    [_leftImg setImageWithURLString:personModel.member_logo placeholderImageString:@"default_item_small"];
    _leftLbl.text = personModel.name;
    _rightConLbl.text = [NSString stringWithFormat:@"%@连红", personModel.recentKeepRedCounts];
    _rightWinLbl.text = [NSString stringWithFormat:@"%@中%@", personModel.buyOrderCount, personModel.countWinOrder];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
