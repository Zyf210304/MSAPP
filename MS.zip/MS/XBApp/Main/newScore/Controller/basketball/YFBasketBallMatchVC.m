//
//  YFBasketBallMatchVC.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBasketBallMatchVC.h"

#import "YFBasketBallMatchMoreVC.h"
#import "YFBasketBallSendMatchVC.h"

#import "YFScrore_Nav.h"
#import "YFBasketBallTypeVIew.h"
#import "YFScore_SectionHeader.h"
#import "YFScore_bottomView.h"

#import "YFBasketPopSFCView.h"

#import "YFBasketBallNormalCell.h"
#import "YFBasketballSFCell.h"
#import "YFBasketballRFCell.h"
#import "YFBasketballSFCCell.h"

#import "YFJCLQModel.h"

#import "YFMatchScreenView.h"
@interface YFBasketBallMatchVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) YFScrore_Nav *score_nav;
@property (nonatomic, strong) YFScore_bottomView *score_bottom;

@property (nonatomic, strong) YFBasketBallTypeVIew *typeView;
@property (nonatomic)         NSInteger Typecount;

@property (nonatomic, strong) NSMutableArray *todayDataSource;
@property (nonatomic)         BOOL todayIsOpen;
@property (nonatomic, strong) NSMutableArray *tomorrowDataSource;
@property (nonatomic)         BOOL tomorrowIsOpen;
@property (nonatomic)         NSInteger chooseCount;
@property (nonatomic)         BOOL isCanDG;

@property (nonatomic, strong) YFBasketPopSFCView *sfcView;

//筛选
@property (nonatomic, strong) NSMutableArray *screenArr;
@property (nonatomic, strong) YFMatchScreenView *ScreenView;
@property (nonatomic)         CGFloat chooseOdd;

@end

@implementation YFBasketBallMatchVC

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    [_tableView reloadData];
    [self BottomViewCount];
  
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = Color_Base_BG;
    _Typecount = 4;
    self.todayDataSource = [NSMutableArray array];
    self.tomorrowDataSource = [NSMutableArray array];
    self.screenArr = [NSMutableArray array];
    [self initUI];
    [self getDataNetwork];
    
}


- (void)initUI {
    _todayIsOpen = YES;
    _tomorrowIsOpen = YES;
    [self addNAV];
    [self addBottom];
    [self addTableView];
    [self addTypeView];
}

- (void)addNAV {
    WEAKSELF;
    YFScrore_Nav *score_nav = [[YFScrore_Nav alloc] init];
    [self.view addSubview:score_nav];
    _score_nav = score_nav;
    score_nav.goBack = ^{
        [weakSelf.navigationController popViewControllerAnimated:YES];
    };
    score_nav.changeType = ^{
        
        _typeView.hidden = !_typeView.hidden;
    };
    [_score_nav mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_equalTo(0);
        make.height.mas_equalTo(Statur_HEIGHT + NAVIBAR_HEIGHT);
    }];
    
    _score_nav.screenShow = ^{
        weakSelf.typeView.hidden = YES;
        weakSelf.ScreenView.hidden = !weakSelf.ScreenView.isHidden;
    };
    
}

- (void)addBottom {
    
    YFScore_bottomView *bottomV = [[YFScore_bottomView alloc] init];
    [self.view addSubview:bottomV];
    _score_bottom = bottomV;
    bottomV.leftBlock = ^{
        [self refreshData];
        [self.tableView reloadData];
        [self BottomViewCount];
    };
    bottomV.rightBlock = ^{
        if (_isCanDG && _chooseCount > 0) {
            [self gotoSendMatchVC];
        } else {
            if (_chooseCount < 2 ) {
                [self showHint:@"至少选择两次比赛"];
            } else {
                [self gotoSendMatchVC];
            }
        }
    };
    [bottomV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(56 *SCALE_375);
        if (@available(iOS 11.0,*)) {
            make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        }else{
            make.bottom.mas_equalTo(0);
        }
    }];
    
}

- (void)addTableView {
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, FRAME_WIDTH, FRAME_HEIGHT) style:UITableViewStylePlain];
    [self.view addSubview:tableView];
    _tableView = tableView;
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.top.equalTo(_score_nav.mas_bottom).offset(SCALE_375);
        make.bottom.equalTo(_score_bottom.mas_top).offset(- SCALE_375);
    }];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
    
}

- (void)addTypeView {
    YFBasketBallTypeVIew *typeView = [[YFBasketBallTypeVIew alloc] initWithFrame:CGRectMake(0, 100, FRAME_WIDTH, 160)];
    [self.view addSubview:typeView];
    _typeView = typeView;
    typeView.hidden = YES;
    [typeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_score_nav.mas_bottom);
        make.left.right.mas_offset(0);
        make.height.mas_offset(FRAME_HEIGHT);
    }];
    WEAKSELF;
    typeView.changeLotteryType = ^(NSInteger typeCount, NSString *typeName) {
        weakSelf.score_nav.typeLbl.text = typeName;
        weakSelf.Typecount = typeCount;
        [self refreshData];
        [_tableView reloadData];
        [self BottomViewCount];
    };
    
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return _tomorrowDataSource.count ? 2 : 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        return _todayIsOpen ? [self getCurrentArr:section].count : 0;
    } else {
        return _tomorrowIsOpen ? [self getCurrentArr:section].count : 0;
    }
    return [self getCurrentArr:section].count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFJCLQModel *model = [self getCurrentArr:indexPath.section][indexPath.row];
    
    if (_Typecount == 0) {
        YFBasketballSFCell *cell = [YFBasketballSFCell cellWithTableView:tableView];
        [cell setValueWith:model];
        cell.dataDidChanged = ^{
             [self BottomViewCount];
        };
        cell.hidden = !model.isHave;
        return cell;
    }
    
    if (_Typecount == 2) {
        YFBasketballSFCCell *cell = [YFBasketballSFCCell cellWithTableView:tableView];
        [cell setValueWith:model];
        cell.chooseLotteryBlock = ^{
            _sfcView.hidden = NO;
            [self.sfcView setValueWith:model];
        };
        cell.hidden = !model.isHave;
        return cell;
    }
    
    if (_Typecount > 0 && _Typecount < 4) {
        YFBasketballRFCell *cell = [YFBasketballRFCell cellWithTableView:tableView];
        model.isRF = _Typecount == 1;
        [cell setValueWith:model];
        cell.dataDidChanged = ^{
             [self BottomViewCount];
        };
        cell.hidden = !model.isHave;
        return cell;
    }
    

    YFBasketBallNormalCell *cell = [YFBasketBallNormalCell cellWithTableView:tableView];
    cell.gotoDeatil = ^{
        YFBasketBallMatchMoreVC *moreVC = [[YFBasketBallMatchMoreVC alloc] init];
        moreVC.currentModel = model;
        [self.navigationController pushViewController:moreVC animated:YES];
    };
    cell.dataDidChanged = ^{
         [self BottomViewCount];
    };
    [cell setValueWith:model];
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFJCLQModel *model = [self getCurrentArr:indexPath.section][indexPath.row];
    if (!model.isHave) {
        return 0;
    }
    
    NSLog(@"%@筛选", model);
    
    if (_Typecount == 0 ) {
        return 73 *SCALE_375;
    }
    
    if (_Typecount > 0 && _Typecount < 4) {
        return 98 *SCALE_375;
    }
    
    return 165 *SCALE_375;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    YFScore_SectionHeader *header = [[YFScore_SectionHeader alloc] initWithFrame:CGRectMake(0, 0, FRAME_HEIGHT, 27 *SCALE_375)];
    header.tag = 400 + section;
    if (section == 0) {
        NSLog(@"%@", [NSString getCurrentTimes]);
        header.titleStr = [NSString stringWithFormat:@"%@  %zd场比赛", [NSString getAboutTime:[NSString getNowTimeTimestamp]],  [self getCurrentArr:section].count];
    } else {
        header.titleStr = [NSString stringWithFormat:@"%@  %zd场比赛", [NSString getAboutTime:[NSString stringWithFormat:@"%ld", [NSString getNowTimeTimestamp].integerValue + 60 * 60  *24]], [self getCurrentArr:section].count];
    }
    [header addTapgestureWithTarget:self action:@selector(changeTableState:)];
    return header;
}

- (void)changeTableState:(UITapGestureRecognizer *)sender {
    if (sender.view.tag ==  400) {
        _todayIsOpen = !_todayIsOpen;
    } else {
        _tomorrowIsOpen = !_tomorrowIsOpen;
    }
    [self.tableView reloadData];
}




- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 27 *SCALE_375;
}

#pragma mark  ---- 网络请求 ----
- (void)getDataNetwork {
    
    [[YFNetBaseManager sharedConnect] postWithPortName:@"/v2/date/leiSuDate" parameters:nil hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        
        NSArray *DATASOURCE = responseObject[@"jclq"];
        for (NSDictionary *dataDic in DATASOURCE) {
            YFJCLQModel *model = [[YFJCLQModel alloc] init];

            [model setValuesForKeysWithDictionary:dataDic];

            if (![model.sell_status isEqualToString:@"0,0,0,0"] && model.sfc.length && model.sf.length && model.dxf.length && model.rf.length) {

                if([[NSDate date] timeIntervalSince1970] > model.matchtime.integerValue - 60  *30) {
                    continue;
                }
                
                if (![self.screenArr containsObject:model.event]) {
                    [self.screenArr addObject:model.event];
                }

                [model initData];

                if ([[model.issue_num substringToIndex:1] isEqualToString:[NSString getCurrentWeek]]) {
                    [self.todayDataSource addObject:model];
                    model.endtime = @(model.matchtime.integerValue - 60 * 60).stringValue;
                    if ([[NSString getmatichTime:model.matchtime.integerValue] isEqualToString:@"24:00"]) {
                        model.endtime = [NSString get24Color:model.matchtime.integerValue];
                    } else {
                        model.endtime = @(model.matchtime.integerValue - 60 * 60).stringValue;
                    }
                    NSLog(@"%@", model.endtime);
                }

                if ([[NSString getCurrentWeek] isEqualToString:@"7"]) {
                    if ([[model.issue_num substringToIndex:1] isEqualToString:@"1"]) {
                        [self.tomorrowDataSource addObject:model];
                        if ([[NSString getmatichTime:model.matchtime.integerValue] isEqualToString:@"24:00"]) {
                            model.endtime = [NSString get24Color:model.matchtime.integerValue];
                        } else {
                            model.endtime = @(model.matchtime.integerValue - 60 * 60).stringValue;
                        }
                    }

                } else {
                    if ([model.issue_num substringToIndex:1].integerValue - 1 ==  [NSString getCurrentWeek].integerValue) {
                        [self.tomorrowDataSource addObject:model];
                        if ([[NSString getmatichTime:model.matchtime.integerValue] isEqualToString:@"24:00"]) {
                            model.endtime = [NSString get24Color:model.matchtime.integerValue];

                        } else {
                            model.endtime = @(model.matchtime.integerValue - 60 * 60).stringValue;
                        }
                    }
                }

            }

        }

        //数组排序

        [_todayDataSource sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
            YFJCLQModel *model = obj1;
            YFJCLQModel *model2 = obj2;
            if ([model.issue_num integerValue] < [model2.issue_num integerValue])
                return NSOrderedAscending;
            return NSOrderedDescending;
        }];
        [_tomorrowDataSource sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
            YFJCLQModel *model = obj1;
            YFJCLQModel *model2 = obj2;
            if ([model.issue_num integerValue] < [model2.issue_num integerValue])
                return NSOrderedAscending;
            return NSOrderedDescending;
        }];
        
        [self.tableView reloadData];
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
}

- (NSMutableArray *)getCurrentArr:(NSInteger)section {
    return section == 0 ? _todayDataSource : _tomorrowDataSource;
}

#pragma mark ---- 弹框
- (YFBasketPopSFCView *)sfcView {
    if (_sfcView == nil) {
        self.sfcView = [[YFBasketPopSFCView alloc] init];
        [self.view addSubview:_sfcView];
        [_sfcView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.bottom.mas_offset(0);
        }];
        WEAKSELF;
        _sfcView.trueBlock = ^{
            [weakSelf.tableView reloadData];
            [weakSelf BottomViewCount];
        };
    }
    return _sfcView;
}


#pragma mark  ----- 数据处理 ----
#pragma mark  ----- 数据还原
- (void)refreshData {
    for (YFJCLQModel *model in self.todayDataSource) {
        [model refreshData];
        model.isRF = _Typecount == 1;
        model.isDG = _Typecount == 5 ? YES : NO;
        
        if (_ScreenView.minOddIsChoose) {
            model.isHave = NO;
            if (model.canjudgeOdd < _chooseOdd) {
                model.isHave = YES;
            }
            if (_ScreenView.ChooseArr.count > 0) {
                model.isHave = [self.ScreenView.ChooseArr containsObject:model.event];
            } else {
                model.isHave = model.canjudgeOdd < _chooseOdd;
            }
            
        } else {
            if (_ScreenView.ChooseArr.count > 0) {
                model.isHave = [self.ScreenView.ChooseArr containsObject:model.event];
            } else {
                model.isHave = YES;
            }
        }
        
    }
    for (YFJCLQModel *model in self.tomorrowDataSource) {
        [model refreshData];
        model.isRF = _Typecount == 1;
        model.isDG = _Typecount == 5 ? YES : NO;
        
        if (_ScreenView.minOddIsChoose) {
            model.isHave = NO;
            if (model.canjudgeOdd < _chooseOdd) {
                model.isHave = YES;
            }
            if (_ScreenView.ChooseArr.count > 0) {
                model.isHave = [self.ScreenView.ChooseArr containsObject:model.event];
            } else {
                model.isHave = model.canjudgeOdd < _chooseOdd;
            }
            
        } else {
            if (_ScreenView.ChooseArr.count > 0) {
                model.isHave = [self.ScreenView.ChooseArr containsObject:model.event];
            } else {
                model.isHave = YES;
            }
        }
    }
}


#pragma mark  ----- 数据统计  下面视图显示改变
- (void)BottomViewCount {
    NSInteger chooseCount = 0;
    BOOL isCanDG = YES;
    for (YFJCLQModel *model in self.todayDataSource) {
        if (model.chooseCount) {
            chooseCount ++;
            if (!model.isCanDG) {
                isCanDG = NO;
            }
        }
    }
    for (YFJCLQModel *model in self.tomorrowDataSource) {
        if (model.chooseCount) {
            chooseCount ++;
            if (!model.isCanDG) {
                isCanDG = NO;
            }
        }
        
    }
    _chooseCount = chooseCount;
    _isCanDG = isCanDG;
    [_score_bottom changeStateWith:chooseCount addIsCanDG:isCanDG];
    
}

#pragma  Mark  ----  整理数据 &&&&&&&&& 跳转
- (void)gotoSendMatchVC {
    if (_chooseCount > 8) {
        [self showHint:@"最多选8场比赛"];
        return;
    }
    
    
    NSMutableArray *dataSoure = [NSMutableArray array];
    for (YFJCLQModel *model in self.todayDataSource) {
        if (model.chooseCount) {
            [dataSoure addObject:model];
        }
    }
    for (YFJCLQModel *model in self.tomorrowDataSource) {
        if (model.chooseCount) {
            [dataSoure addObject:model];
        }
    }
    
    YFBasketBallSendMatchVC  *sendVC = [[YFBasketBallSendMatchVC alloc] init];
    sendVC.dataSorce = dataSoure;
    sendVC.Typecount = _Typecount;
    if (_isSend) {
        sendVC.isSend = YES;
    }
    if (_isCanDG) {
        sendVC.Typecount = 5;
    }
    [self.navigationController pushViewController:sendVC animated:YES];
    
}


#pragma mark --- 筛选
- (YFMatchScreenView *)ScreenView {
    if (_ScreenView == nil) {
        self.ScreenView = [[YFMatchScreenView alloc] init];
        [self.view addSubview:_ScreenView];
        self.ScreenView.ScreenArr = _screenArr;
        [_ScreenView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.bottom.mas_offset(0);
        }];
        [_ScreenView initUI];
        WEAKSELF;
        _ScreenView.trueBlock = ^{
            NSLog(@"%@", weakSelf.ScreenView.ChooseArr);
            if (weakSelf.ScreenView.minOddIsChoose) {
                weakSelf.chooseOdd = weakSelf.ScreenView.centerTF.text.floatValue;
            } else {
                weakSelf.chooseOdd = 0.0;
            }
            
            [weakSelf refreshData];
            [weakSelf.tableView reloadData];
        };
        _ScreenView.hidden = YES;
    }
    return _ScreenView;
}

- (void)screenAction:(UIButton *)sender {
    self.ScreenView.hidden = !self.ScreenView.isHidden;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
