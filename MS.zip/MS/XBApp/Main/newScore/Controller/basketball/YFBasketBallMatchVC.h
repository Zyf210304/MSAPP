//
//  YFBasketBallMatchVC.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFBasketBallMatchVC : UIViewController

@property (nonatomic) BOOL isSend;

@end
