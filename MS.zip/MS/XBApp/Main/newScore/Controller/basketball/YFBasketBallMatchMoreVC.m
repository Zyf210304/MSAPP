//
//  YFBasketBallMatchMoreVC.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBasketBallMatchMoreVC.h"

#import "YFScore_SectionHeader.h"
#import "YFBasketballMoreCell.h"
#import "YFScoreMore_Bottom.h"
#import "YFJCLQModel.h"
@interface YFBasketBallMatchMoreVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) UILabel *titleLBl;
@property (nonatomic, strong) YFScoreMore_Bottom *score_bottom;

@end

@implementation YFBasketBallMatchMoreVC

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = Color_Base_BG;
    [self initUI];
}


- (void)initUI {
    
    [self addTilteLbl];
    [self addBottomView];
    [self addTableView];
    
}

- (void)addTilteLbl {
    UIView *topView = [[UIView alloc] init];
    [self.view addSubview:topView];
    topView.backgroundColor = [UIColor whiteColor];
    [topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(NAVIBAR_HEIGHT + Statur_HEIGHT);
        make.top.mas_offset(0);
    }];
    
    
    UILabel *titleLBl = [[UILabel alloc] init];
    [topView addSubview:titleLBl];
    _titleLBl = titleLBl;
    titleLBl.backgroundColor = [UIColor whiteColor];
    titleLBl.textColor = Color_title_333;
    titleLBl.textAlignment = NSTextAlignmentCenter;
    titleLBl.text =  [NSString stringWithFormat:@"%@ VS %@", _currentModel.home, _currentModel.away];
    [titleLBl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(44);
        make.top.mas_offset(Statur_HEIGHT);
    }];
    
}


- (void)addBottomView {
    
    YFScoreMore_Bottom *bottomV = [[YFScoreMore_Bottom alloc] init];
    [self.view addSubview:bottomV];
    _score_bottom = bottomV;
    [bottomV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(44 *SCALE_375);
        if (@available(iOS 11.0,*)) {
            make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        }else{
            make.bottom.mas_equalTo(0);
        }
    }];
    
}


- (void)addTableView {
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, FRAME_WIDTH, FRAME_HEIGHT) style:UITableViewStylePlain];
    [self.view addSubview:tableView];
    _tableView = tableView;
    _tableView.backgroundColor = Color_Base_BG;
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.top.equalTo(_titleLBl.mas_bottom).offset(SCALE_375);
        make.bottom.equalTo(_score_bottom.mas_top).offset(- SCALE_375);
    }];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
    
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFBasketballMoreCell *cell = nil;
    
    if (indexPath.row == 0) {
        cell = [YFBasketballMoreCell cellWithTableView:tableView addType:Match_Result];
    }  else {
        cell = [YFBasketballMoreCell cellWithTableView:tableView addType:Match_Score];
    }
    
    [cell setValueWithModel:_currentModel];
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return  indexPath.row == 0 ? 150 *SCALE_375 : 193 *SCALE_375;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
