//
//  YFSendMatchVC.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/11.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFSendMatchVC.h"
#import "YFChooseMatch_MoreVC.h"
#import "YFPlaceOrderVC.h"
#import "YFOrderSuccessVC.h"

#import "YFScrore_Nav.h"
#import "YFScore_TypeView.h"
#import "YFScore_SectionHeader.h"
#import "YFScore_bottomView.h"
#import "YFSendMatch_chooseNumberView.h"
#import "YFSendMatch_chooseTypeView.h"

#import "YFScore_NormalCell.h"
#import "YFScore_VSCell.h"
#import "YFScore_ScoreCell.h"
#import "YFScore_TwoChooseOneCell.h"

#import "YFScorePop_allBallsView.h"
#import "YFScorePop_DoubleResultView.h"
#import "YFScorePop_ScoreView.h"

#import "YFNetBaseManager.h"
#import "YFJCZQ_model.h"

#import "YFCalculate.h"
#import "UIViewController+nav.h"

@interface YFSendMatchVC ()<UITableViewDelegate, UITableViewDataSource>


@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) YFScore_bottomView *score_bottom;
@property (nonatomic, strong) YFSendMatch_chooseNumberView *chooseNumberView;
@property (nonatomic, strong) YFSendMatch_chooseTypeView *typeView;
@property (nonatomic)         BOOL typeIsHidden;
@property (nonatomic, strong) NSMutableArray *TypeArr;


@property (nonatomic)         NSInteger chooseCount;
//场次
@property (nonatomic)         NSMutableArray *chooseSectionArr;
//最大赔率
@property (nonatomic)         NSMutableArray *chooseSectionMaxArr;
//最小赔率
@property (nonatomic)         NSMutableArray *chooseSectionMinArr;
@property (nonatomic)         BOOL isMoreFour;
@property (nonatomic)         NSInteger stacks;

//弹窗
@property (nonatomic, strong) YFScorePop_allBallsView *allBallView;
@property (nonatomic, strong) YFScorePop_DoubleResultView *doubleResView;
@property (nonatomic, strong) YFScorePop_ScoreView *ScoreView;

@end

@implementation YFSendMatchVC

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [_tableView reloadData];
    [self BottomViewCount];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setBalckNavigation];
    // Do any additional setup after loading the view.
    self.view.backgroundColor =  Color_Base_BG;
    self.title  = @"确认方案";
    _chooseSectionArr = [NSMutableArray array];
    _chooseSectionMaxArr = [NSMutableArray array];
    _chooseSectionMinArr = [NSMutableArray array];
    _typeIsHidden = YES;
    self.TypeArr = [NSMutableArray arrayWithArray:@[@0,@0,@0,@0,@0,@0,@0]];
    if (_dataSorce.count >= 2) {
        self.TypeArr[_dataSorce.count - 2] = @1;
    }
    [self initUI];
    
}


- (void)initUI {
    [self addBottom];
    [self addTableView];
}


- (void)addBottom {
    
    YFScore_bottomView *bottomV = [[YFScore_bottomView alloc] init];
    [self.view addSubview:bottomV];
    _score_bottom = bottomV;
    [bottomV setIsSendUI];
    bottomV.leftBlock = ^{
        [self.navigationController popViewControllerAnimated:YES];
    };
    bottomV.rightBlock = ^{
        [self sendMatchNetWork];
    };
    [bottomV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(56 *SCALE_375);
        if (@available(iOS 11.0,*)) {
            make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        }else{
            make.bottom.mas_equalTo(0);
        }
    }];
    
    
    YFSendMatch_chooseNumberView *chooseView = [[YFSendMatch_chooseNumberView alloc] init];
    [self.view addSubview:chooseView];
    _chooseNumberView = chooseView;
    if (_Typecount == 7) {
        _chooseNumberView.chooseTypeStr  = @"单关";
        _chooseNumberView.chooseTypeLbl.userInteractionEnabled = NO;
    } else {
        _chooseNumberView.chooseTypeStr  = [NSString stringWithFormat:@"%zd串1",_dataSorce.count];
    }
    
    chooseView.showTypeViewBlock = ^{
        [self BottomViewCount];
        if (_chooseCount > 1) {
            
            NSInteger typeNum = _isMoreFour ? (_chooseCount > 4 ? 4 : _chooseCount) : _chooseCount;
            [self.typeView setValueWith:typeNum with:_TypeArr];
            self.typeView.hidden = NO;
            
        } else {
            [self showHint:@"至少选两场"];
        }
        
    };
    chooseView.changeBottomBlock = ^{
        [self BottomViewCount];
    };
    [chooseView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(bottomV.mas_top);
        make.left.right.mas_offset(0);
        make.height.mas_offset(56 *SCALE_375);
    }];
    
}

- (void)addTableView {
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, FRAME_WIDTH, FRAME_HEIGHT) style:UITableViewStylePlain];
    [self.view addSubview:tableView];
    _tableView = tableView;
    tableView.backgroundColor = Color_Base_BG;
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        if (@available(iOS 11.0,*)) {
            make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
        }else{
            make.top.mas_equalTo(Statur_HEIGHT + NAVIBAR_HEIGHT);
        }
        make.bottom.equalTo(_chooseNumberView.mas_top).offset(- SCALE_375);
    }];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataSorce.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    YFJCZQ_model *model = _dataSorce[indexPath.row];
    if (_Typecount < 2) {
        YFScore_VSCell *cell = [YFScore_VSCell cellWithTableView:tableView];
        model.isSFP = _Typecount == 0;
        [cell setValueWithModel:model];
        cell.dataDidChanged = ^{
             [self BottomViewCount];
             [self.typeView setValueWith:_chooseCount with:_TypeArr];
            _chooseNumberView.chooseTypeStr = _typeView.chooseTypeStr;
        };
        return cell;
    }
    
    if (_Typecount > 1 && _Typecount < 5) {
        YFScore_ScoreCell *cell = [YFScore_ScoreCell cellWithTableView:tableView];
        [cell setValueWithModel:model];
        cell.chooseLotteryBlock = ^{
            [self showPopUp:model];
            [self.typeView setValueWith:_chooseCount with:_TypeArr];
            _chooseNumberView.chooseTypeStr = _typeView.chooseTypeStr;
        };
        return cell;
    }
    
    if (_Typecount == 5) {
        YFScore_TwoChooseOneCell *cell = [YFScore_TwoChooseOneCell cellWithTableView:tableView];
        [cell setValueWithModel:model];
        return cell;
    }
    
    YFScore_NormalCell *cell = [YFScore_NormalCell cellWithTableView:tableView];
    model.isDG = _Typecount == 7 ? YES : NO;
    [cell setValueWithModel:model];
    cell.gotoDeatil = ^(NSDictionary *dataDic) {
        YFChooseMatch_MoreVC *moreVC = [[YFChooseMatch_MoreVC alloc] init];
        moreVC.zqModel = model;
        [self.navigationController pushViewController:moreVC animated:YES];
    };
    cell.dataDidChanged = ^{
        [self BottomViewCount];
        [self.typeView setValueWith:_chooseCount with:_TypeArr];
        _chooseNumberView.chooseTypeStr = _typeView.chooseTypeStr;

    };
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_Typecount < 2) {
        return 92 *SCALE_375;
    }
    
    if (_Typecount > 1 && _Typecount < 5) {
        return 102 *SCALE_375;
    }
    
    if (_Typecount == 5) {
        return 100 *SCALE_375;
    }
    return 117 *SCALE_375;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark   ---- 弹窗 ----

- (YFSendMatch_chooseTypeView *)typeView {
    if (_typeView == nil) {
        self.typeView = [[YFSendMatch_chooseTypeView alloc] init];
        [self.view addSubview:_typeView];
        [_typeView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.bottom.mas_offset(0);
        }];
        WEAKSELF;
        self.typeView.changeTypeChoose = ^(NSString *chooseTypeStr) {
            weakSelf.chooseNumberView.chooseTypeStr = chooseTypeStr;
            [weakSelf BottomViewCount];
        };
        _typeView.hidden = YES;
    }
    return _typeView;
}

- (YFScorePop_allBallsView *)allBallView {
    if (_allBallView == nil) {
        self.allBallView = [[YFScorePop_allBallsView alloc] init];
        [self.view addSubview:_allBallView];
        [_allBallView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.bottom.mas_offset(0);
        }];
        WEAKSELF;
        _allBallView.trueBlock = ^{
            [weakSelf.tableView reloadData];
            [weakSelf BottomViewCount];
        };
    }
    return _allBallView;
}

- (YFScorePop_DoubleResultView *)doubleResView {
    if (_doubleResView == nil) {
        self.doubleResView = [[YFScorePop_DoubleResultView  alloc] init];
        [self.view addSubview:_doubleResView];
        [_doubleResView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.bottom.mas_offset(0);
        }];
        WEAKSELF;
        _doubleResView.trueBlock = ^{
            [weakSelf.tableView reloadData];
            [weakSelf BottomViewCount];
        };
    }
    return _doubleResView;
}

- (YFScorePop_ScoreView *)ScoreView {
    if (_ScoreView == nil) {
        self.ScoreView = [[YFScorePop_ScoreView alloc] init];
        [self.view addSubview:_ScoreView];
        [_ScoreView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.bottom.mas_offset(0);
        }];
        WEAKSELF;
        _ScoreView.trueBlock = ^{
            [weakSelf.tableView reloadData];
            [weakSelf BottomViewCount];
        };
    }
    return _ScoreView;
}

- (void)showPopUp:(YFJCZQ_model *)model {
    if (_Typecount == 2) {
        self.ScoreView.hidden = NO;
        [self.ScoreView setValueWithModel:model];
    }
    if (_Typecount == 3) {
        self.allBallView.hidden = NO;
        [self.allBallView setValueWithModel:model];
    }
    if (_Typecount == 4) {
        self.doubleResView.hidden = NO;
        [self.doubleResView setValueWithModel:model];
    }
    
}



#pragma mark  ----- 数据处理 ----
#pragma mark  ----- 数据统计  下面视图显示改变
- (void)BottomViewCount {
    NSInteger chooseCount = 0;
    _isMoreFour = NO;
    [_chooseSectionArr removeAllObjects];
    [_chooseSectionMinArr removeAllObjects];
    [_chooseSectionMaxArr removeAllObjects];
    
    for (YFJCZQ_model *model in _dataSorce) {
        if (model.chooseCount) {
            chooseCount ++;
            [_chooseSectionArr addObject:[NSString stringWithFormat:@"%zd", model.chooseCount]];
            [_chooseSectionMaxArr addObject:[NSString stringWithFormat:@"%lf", model.maxOdd]];
            [_chooseSectionMinArr addObject:[NSString stringWithFormat:@"%lf", model.minOdd]];
        }
        if (model.isMoreFour) {
            _isMoreFour = YES;
        }
    }
    _chooseCount = chooseCount;
    
    [self countStakesNumber];
}

#pragma mark  ----- 数据统计  计算注数
-  (void)countStakesNumber {
    if (_Typecount == 7) {
        NSInteger stracts = 0;
        CGFloat maxOdd = 0;
        CGFloat minOdd = 0;
        for (YFJCZQ_model *model in _dataSorce) {
            if (model.chooseCount) {
                stracts += model.chooseCount;
                maxOdd += model.maxOdd;
                minOdd += model.minOdd;
            }
        }
        _stacks = stracts;
        [_score_bottom changeStateWithStack:stracts addMult:_chooseNumberView.multiTF.text.floatValue minBouns:minOdd maxBouns:maxOdd] ;
    } else {
        NSInteger stracts = 0;
        CGFloat maxbonus = 0;
        CGFloat minbonus = 0;
        for (int i = 0; i < _TypeArr.count; i ++) {
            if ([_TypeArr[i] isEqual:@1]) {
                NSArray *allReslut = [YFCalculate getResultAboutChoosesession:_chooseCount andChooseNum:i + 2 andCorrespondingArr:_chooseSectionArr addMaxOddArr:_chooseSectionMaxArr addMinOddArr:_chooseSectionMinArr];
                NSNumber *thisStract = allReslut[0];
                NSNumber *thisMaxBouns = allReslut[1];
                NSNumber *thisMinBouns = allReslut[2];
                
                stracts += thisStract.integerValue;
                maxbonus += thisMaxBouns.floatValue;
                if (minbonus > 0) {
                    minbonus = minbonus > thisMinBouns.floatValue ? thisMinBouns.floatValue : minbonus;
                } else {
                    minbonus = thisMinBouns.floatValue;
                }
                
            }
        }
        _stacks = stracts;
        [_score_bottom changeStateWithStack:stracts addMult:_chooseNumberView.multiTF.text.floatValue minBouns:minbonus maxBouns:maxbonus];
    }
   
}




#pragma mark  --- 下单 ---
- (void)sendMatchNetWork {
    //判断场次
    if ([_chooseNumberView.chooseTypeStr isEqualToString:@"请选择过关类型"] ||[_chooseNumberView.chooseTypeStr isEqualToString:@"场次不足"] ) {
        [self showHint:_chooseNumberView.chooseTypeStr ];
        return;
    }
    if (_stacks > 100) {
        [self showHint:@"最多100注"];
        return;
    }
    if (_stacks * 2 * _chooseNumberView.multiTF.text.integerValue < 10) {
        [self showHint:@"下单至少10元"];
        return;
    }
    
    
    NSNumber *pass_type = _Typecount == 7 ?  @0 : @1;
    NSDictionary *postDic = @{@"buy_amount":@(_stacks * 2* _chooseNumberView.multiTF.text.integerValue),
                              @"number":@(_stacks),
                              @"lottery_type_id":@1,
                              @"member_id":@0,
                              @"mulriple":_chooseNumberView.multiTF.text,
                              @"pass_type":pass_type,
                              @"pass_way":_chooseNumberView.chooseTypeStr};
    NSMutableArray *rquestDataSorurce = [NSMutableArray array];
    for (YFJCZQ_model *model in _dataSorce) {
        [model addDataWith:rquestDataSorurce];
    }
    
    NSMutableDictionary *paramters = [NSMutableDictionary dictionaryWithDictionary:postDic];
    [paramters setValue:rquestDataSorurce forKey:@"requestOrderPackages"];
    
    
    if (_isSend) {
        YFPlaceOrderVC *placeVC = [[YFPlaceOrderVC alloc] init];
        placeVC.paramters = paramters;
        placeVC.Amount = @(_stacks * 2 * _chooseNumberView.multiTF.text.integerValue).stringValue;
        [self.navigationController pushViewController:placeVC animated:YES];
        return;
    }
    
    
    [[YFNetBaseManager sharedConnect] postWithPortName:@"v1/order/placeOrder" parameters:paramters hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
            NSNumber *payID = responseObject[@"orderInfo"][@"id"];
            if (payID) {
                [self PayAction:payID];
            } else {
                [self showHint:@"获取订单失败"];
            }
            
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}

- (void)PayAction:(NSNumber *)payID {
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"确认付款" message:nil preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self payNetWork:payID];
    }];
    UIAlertAction *alertAction2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSLog(@"取消");
    }];
    //将两个按钮与alertController相关联
    [alertC addAction:alertAction2];
    [alertC addAction:alertAction1];
    
    //将alertController 显示
    [self presentViewController:alertC animated:YES completion:nil];
    
}

- (void)payNetWork:(NSNumber *)payID {
    
    [[YFNetBaseManager sharedConnect] postWithPortName:@"/v1/order/payOrder" parameters:@{@"orderId":payID} hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        NSLog(@"%@", responseObject);
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
//            [self.navigationController popToRootViewControllerAnimated:YES];
//            [self showHint:responseObject[@"tip"]];
            [self gotoSuccessVC];
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
}

- (void)gotoSuccessVC {
    

    YFOrderSuccessVC *successVC = [[YFOrderSuccessVC alloc] init];
    successVC.buyAmount = @(_stacks * 2* _chooseNumberView.multiTF.text.integerValue);
    [self.navigationController pushViewController:successVC animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
