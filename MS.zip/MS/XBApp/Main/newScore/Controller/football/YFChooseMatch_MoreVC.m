//
//  YFChooseMatch_MoreVC.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFChooseMatch_MoreVC.h"
#import "YFScore_SectionHeader.h"
#import "YFScore_moreCell.h"
#import "YFScoreMore_Bottom.h"


@interface YFChooseMatch_MoreVC ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) UILabel *titleLBl;
@property (nonatomic, strong) YFScoreMore_Bottom *score_bottom;

@end

@implementation YFChooseMatch_MoreVC

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = Color_Base_BG;
    [self initUI];
}


- (void)initUI {
    
    [self addTilteLbl];
    [self addBottomView];
    [self addTableView];
   
}

- (void)addTilteLbl {
    UIView *topView = [[UIView alloc] init];
    [self.view addSubview:topView];
    topView.backgroundColor = [UIColor colorWithRed:252/255.0 green:43/ 255.0 blue:53/ 255.0 alpha:1];
    [topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(NAVIBAR_HEIGHT + Statur_HEIGHT);
        make.top.mas_offset(0);
    }];
    
    
    UILabel *titleLBl = [[UILabel alloc] init];
    [topView addSubview:titleLBl];
    _titleLBl = titleLBl;
    titleLBl.backgroundColor = [UIColor colorWithRed:252/255.0 green:43/ 255.0 blue:53/ 255.0 alpha:1];
    titleLBl.textColor = [UIColor whiteColor];
    titleLBl.textAlignment = NSTextAlignmentCenter;
    titleLBl.text = [NSString stringWithFormat:@"%@ VS %@", _zqModel.home, _zqModel.away];
    [titleLBl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(44 + Statur_HEIGHT);
        make.top.mas_offset(Statur_HEIGHT);
    }];
    
}


- (void)addBottomView {
    
    YFScoreMore_Bottom *bottomV = [[YFScoreMore_Bottom alloc] init];
    [self.view addSubview:bottomV];
    _score_bottom = bottomV;
    [bottomV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(44 *SCALE_375);
        if (@available(iOS 11.0,*)) {
            make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        }else{
            make.bottom.mas_equalTo(0);
        }
    }];
    
}


- (void)addTableView {
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, FRAME_WIDTH, FRAME_HEIGHT) style:UITableViewStylePlain];
    [self.view addSubview:tableView];
    _tableView = tableView;
    _tableView.backgroundColor = Color_Base_BG;
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.top.equalTo(_titleLBl.mas_bottom).offset(SCALE_375);
        make.bottom.equalTo(_score_bottom.mas_top).offset(- SCALE_375);
    }];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    YFScore_moreCell *cell = nil;
    
    switch (indexPath.section) {
        case 0:
            cell = [YFScore_moreCell cellWithTableView:tableView addType:Lottery_Result];
            [cell setValueWith:_zqModel addType:Lottery_Result];
            break;
        case 1:
            cell = [YFScore_moreCell cellWithTableView:tableView addType:Lottery_Score];
            [cell setValueWith:_zqModel addType:Lottery_Score];
            break;
        case 2:
            cell = [YFScore_moreCell cellWithTableView:tableView addType:Lottery_BallNumer];
            [cell setValueWith:_zqModel addType:Lottery_BallNumer];
            break;
        case 3:
            cell = [YFScore_moreCell cellWithTableView:tableView addType:Lottery_DoubleResult];
            [cell setValueWith:_zqModel addType:Lottery_DoubleResult];
            break;
        default:
            break;
    }
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat cellHeight = 0;
    
    switch (indexPath.section) {
        case 0:
            cellHeight = 96 *SCALE_375;
            break;
        case 1:
            return 310 *SCALE_375;
            break;
        case 2:
            cellHeight = 96 *SCALE_375;
            break;
        case 3:
            return 143 *SCALE_375;
            break;
        default:
            break;
    }
    return cellHeight;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    NSArray *titleArr = @[@"胜平负/让球", @"比分", @"进球数", @"半全场"];
    YFScore_SectionHeader *header = [[YFScore_SectionHeader alloc] initWithFrame:CGRectMake(0, 0, FRAME_HEIGHT, 27 *SCALE_375)];
    header.titleStr  = titleArr[section];
    return header;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 27 *SCALE_375;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
