//
//  YFPlaceOrderVC.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/13.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFPlaceOrderVC.h"
#import "YFPlaceOrderBaseView.h"
#import "YFBase_textView.h"
#import "YFNetBaseManager.h"
#import "YFOrderSuccessVC.h"

#import "UIViewController+page.h"
@interface YFPlaceOrderVC ()

@property (nonatomic, strong) YFPlaceOrderBaseView *moneyView;

@property (nonatomic, strong) YFPlaceOrderBaseView *commissionView;

@property (nonatomic, strong) YFPlaceOrderBaseView *oddsView;

@property (nonatomic, strong) YFPlaceOrderBaseView *settingView;

@property (nonatomic, strong) YFBase_textView *contentTF;
@end

@implementation YFPlaceOrderVC

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"方案选项";
    self.view.backgroundColor = [UIColor whiteColor];
    [self initUI];
    [self setRightBarButtonItemWithTitle:@"分享" action:@selector(gotoRedVC:)];
}
- (void)gotoRedVC:(UIButton *)sender {
    [self toSharepage];
}

- (void)initUI {
    [self addMoneyViewUI];
    [self addcommissionViewUI];
    [self addOddsViewUI];
    [self addSettingViewUI];
    [self addContentTF];
    [self addSendLbl];
}

- (void)addMoneyViewUI {
    //方案金额
    YFPlaceOrderBaseView *moneyView = [[YFPlaceOrderBaseView alloc] init];
    _moneyView = moneyView;
    [self.view addSubview:moneyView];
    [moneyView setUIWith:Base_Lbl];
    [moneyView setValueWithLeftStr:[NSString stringWithFormat:@"方案金额:%@元", _Amount] addRightLblStr:@"单注2元"];
    [moneyView mas_makeConstraints:^(MASConstraintMaker *make) {
        if (@available(iOS 11.0,*)) {
            make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
        }else{
            make.top.mas_equalTo(Statur_HEIGHT + NAVIBAR_HEIGHT);
        }
        make.left.right.mas_offset(0);
        make.height.mas_offset(36 *SCALE_375);
    }];
}

- (void)addcommissionViewUI {
    YFPlaceOrderBaseView *commissionView = [[YFPlaceOrderBaseView alloc] init];
    _commissionView = commissionView;
    [self.view addSubview:commissionView];
    [commissionView setUIWith:Base_Swith];
    [commissionView setValueWithLeftStr:@"佣金比例:10%" addRightLblStr:@""];
    [commissionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_moneyView.mas_bottom);
        make.left.right.mas_offset(0);
        make.height.mas_offset(36 *SCALE_375);
    }];
}

- (void)addOddsViewUI {
    YFPlaceOrderBaseView *oddsView = [[YFPlaceOrderBaseView alloc] init];
    _oddsView = oddsView;
    [self.view addSubview:oddsView];
    [oddsView setUIWith:Base_TF];
    [oddsView setValueWithLeftStr:@"赔率" addRightLblStr:@""];
    [oddsView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_commissionView.mas_bottom);
        make.left.right.mas_offset(0);
        make.height.mas_offset(36 *SCALE_375);
    }];
    
}

- (void)addSettingViewUI {
    YFPlaceOrderBaseView *settingView = [[YFPlaceOrderBaseView alloc] init];
    _settingView = settingView;
    [self.view addSubview:settingView];
    [settingView setUIWith:Base_Choose];
    [settingView setValueWithLeftStr:@"保密设置:" addRightLblStr:@""];
    [settingView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_oddsView.mas_bottom);
        make.left.right.mas_offset(0);
        make.height.mas_offset(40 *SCALE_375);
    }];
}

- (void)addContentTF {
    
    UILabel *titleLbl = [[UILabel alloc] init];
    [self.view addSubview:titleLbl];
    titleLbl.text = @"方案描述";
    titleLbl.textColor = Color_title_333;
    titleLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [titleLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(10 *SCALE_375);
        make.top.equalTo(_settingView.mas_bottom).offset(20 *SCALE_375);
    }];
    
    YFBase_textView *contentTF = [[YFBase_textView alloc] init];
    [self.view addSubview:contentTF];
    _contentTF = contentTF;
    contentTF.hiddenNum = YES;
    contentTF.limtNum = 50;
    contentTF.placeHolderLabel.text = @"竞彩比赛精选方案";
    contentTF.textView.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [contentTF mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(10 *SCALE_375);
        make.right.mas_offset(- 10 *SCALE_375);
        make.top.equalTo(titleLbl.mas_bottom).offset(5 *SCALE_375);
        make.height.mas_offset(50 *SCALE_375);
    }];
}

- (void)addSendLbl {
    
    UILabel *sendLbl = [[UILabel alloc] init];
    [self.view addSubview:sendLbl];
    sendLbl.text = @"确认发单";
    sendLbl.textColor = [UIColor whiteColor];
    sendLbl.backgroundColor = [UIColor redColor];
    sendLbl.textAlignment = NSTextAlignmentCenter;
    sendLbl.layer.masksToBounds = YES;
    sendLbl.layer.cornerRadius = 4 *SCALE_375;
    [sendLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(9);
        make.right.mas_offset(-9);
        make.height.mas_offset(36 *SCALE_375);
        if (@available(iOS 11.0,*)) {
            make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom).offset(-19 *SCALE_375);
        }else{
            make.bottom.mas_equalTo(- 19 *SCALE_375);
        }
    }];
    
    [sendLbl addTapgestureWithTarget:self action:@selector(sendOrederNetWork:)];
    
}

- (void)sendOrederNetWork:(UITapGestureRecognizer *)sender {
    
    [_paramters setValue:_settingView.privacy_setting forKey:@"privacy_setting"];
    [_paramters setValue:(_contentTF.textView.text.length ?  _contentTF.textView.text : @"竞彩比赛精选方案") forKey:@"description"];
    [_paramters setValue:@10 forKey:@"commission_rate"];
    [_paramters setValue:_oddsView.centerTF.text forKey:@"protect_odds"];
    
    
    [[YFNetBaseManager sharedConnect] postWithPortName:@"/v1/order/sendOrder" parameters:_paramters hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        NSLog(@"%@", responseObject);
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
            NSNumber *payID = responseObject[@"orderInfo"][@"id"];
            if (payID) {
                [self PayAction:payID];
            } else {
                [self showHint:@"获取订单失败"];
            }
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}


- (void)PayAction:(NSNumber *)payID {
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"确认付款" message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self payNetWork:payID];
    }];
    UIAlertAction *alertAction2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSLog(@"取消");
    }];
    //将两个按钮与alertController相关联
    [alertC addAction:alertAction2];
    [alertC addAction:alertAction1];
    
    //将alertController 显示
    [self presentViewController:alertC animated:YES completion:nil];
    
}

#pragma mark  ---  支付 ---
- (void)payNetWork:(NSNumber *)payID {
    
    [[YFNetBaseManager sharedConnect] postWithPortName:@"/v1/order/payOrder" parameters:@{@"orderId":payID} hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        NSLog(@"%@", responseObject);
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
//            [self.navigationController popToRootViewControllerAnimated:YES];
//            [self showHint:responseObject[@"tip"]];
            [self gotoSuccessVC];
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)gotoSuccessVC {
    
    YFOrderSuccessVC *successVC = [[YFOrderSuccessVC alloc] init];
    successVC.buyAmount = _paramters[@"buy_amount"];
    [self.navigationController pushViewController:successVC animated:YES];
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
