//
//  YFPlaceOrderVC.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/13.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFPlaceOrderVC : UIViewController

@property (nonatomic, strong) NSString *Amount;

@property (nonatomic, strong) NSMutableDictionary *paramters;



@end
