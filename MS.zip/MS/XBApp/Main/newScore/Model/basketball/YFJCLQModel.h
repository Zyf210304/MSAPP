//
//  YFJCLQModel.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFJCLQModel : NSObject

@property (nonatomic, strong) NSString *away;

@property (nonatomic, strong) NSString *event;

@property (nonatomic, strong) NSString *home;

@property (nonatomic, strong) NSNumber *ID;

@property (nonatomic, strong) NSNumber *issue;

@property (nonatomic, strong) NSString *issue_num;

@property (nonatomic, strong) NSNumber *matchtime;

@property (nonatomic, strong) NSString *sell_status;

//让分
@property (nonatomic, strong) NSString *rf;
@property (nonatomic, strong) NSArray *rfArr;
@property (nonatomic, strong) NSMutableArray *rfStateArr;

//胜负
@property (nonatomic, strong) NSString *sf;
@property (nonatomic, strong) NSArray *sfArr;
@property (nonatomic, strong) NSMutableArray *sfStateArr;

//胜分差
@property (nonatomic, strong) NSString *sfc;
@property (nonatomic, strong) NSArray *sfcArr;
@property (nonatomic, strong) NSMutableArray *sfcStateArr;

//大小分
@property (nonatomic, strong) NSString *dxf;
@property (nonatomic, strong) NSArray *dxfArr;
@property (nonatomic, strong) NSMutableArray *dxfStateArr;

- (void)initData;

- (void)refreshData;

- (void)checkChooseCount;

@property (nonatomic, strong) NSString *endtime;

@property (nonatomic)         BOOL isRF;
@property (nonatomic)         BOOL isDG;
@property (nonatomic)   BOOL isCanDG; //进入单关下单

@property (nonatomic)         NSInteger chooseCount;

@property (nonatomic)   BOOL isMoreFour;

@property (nonatomic)   CGFloat maxOdd;
@property (nonatomic)   CGFloat minOdd;



//保存上传数据
- (void)addDataWith:(NSMutableArray *)dataSoure;


@property (nonatomic)   BOOL isHave;
@property (nonatomic)   CGFloat canjudgeOdd;



@end
