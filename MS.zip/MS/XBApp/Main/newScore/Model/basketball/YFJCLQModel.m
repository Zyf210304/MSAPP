//
//  YFJCLQModel.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFJCLQModel.h"

@implementation YFJCLQModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
    
}

- (void)initData {
    _canjudgeOdd = 10000;
    //大小分
    self.dxfStateArr = [NSMutableArray arrayWithArray:@[@0, @0]];
    NSArray *dxfTempArr = [self.dxf componentsSeparatedByString:@","];
    self.dxfArr = @[dxfTempArr[1], dxfTempArr[2]];
    
    //让分
    self.rfStateArr = [NSMutableArray arrayWithArray:@[@0, @0]];
    NSArray *rfTempArr = [self.rf componentsSeparatedByString:@","];
    self.rfArr = @[rfTempArr[2], rfTempArr[1]];
    
    //胜负
    self.sfStateArr = [NSMutableArray arrayWithArray:@[@0, @0]];
    NSArray *sfTempArr = [self.sf componentsSeparatedByString:@","];
    self.sfArr = @[sfTempArr[1], sfTempArr[0]];
    
    //胜分差
    self.sfcStateArr = [NSMutableArray array];
    NSArray *sfcTempArr = [self.sfc componentsSeparatedByString:@","];
    self.sfcArr = @[sfcTempArr[1],sfcTempArr[3],
                    sfcTempArr[5],sfcTempArr[7],
                    sfcTempArr[9],sfcTempArr[11],
                    sfcTempArr[0],sfcTempArr[2],
                    sfcTempArr[4],sfcTempArr[6],
                    sfcTempArr[8],sfcTempArr[10],];
    
    for (int i = 0; i < 12; i ++) {
        [self.sfcStateArr addObject:@0];
    }
    
    for (int i = 0; i < 2; i ++) {
        NSNumber *spfTempOdd = _sfArr[i];
        NSNumber *rqTempOdd = _rfArr[i];
        
        CGFloat tempOdd = spfTempOdd.floatValue > rqTempOdd.floatValue ?  rqTempOdd.floatValue: spfTempOdd.floatValue;
        _canjudgeOdd = _canjudgeOdd > tempOdd ? tempOdd : _canjudgeOdd;
        
    }
    
    _isDG = NO;
    _isRF = NO;
    _isHave = YES;
}

- (void)refreshData {
    for (int i = 0; i < 2; i ++) {
        self.dxfStateArr[i] = @0;
        self.rfStateArr[i] = @0;
        self.sfStateArr[i] = @0;
    }
    
    for (int i = 0; i < 12; i ++) {
        [self.sfcStateArr addObject:@0];
    }
    _isDG = NO;
    _isRF = NO;
    _isHave = YES;
}



- (void)checkChooseCount {
    NSInteger count = 0;
    BOOL isMoreFour = NO;
    BOOL isCanDG = YES;
    
    CGFloat maxOdd = 0;
    CGFloat minOdd = 0;
    
    NSArray *sell_status = [self.sell_status componentsSeparatedByString:@","];
    
    
    
    //胜负
    for (int i = 0; i < self.sfStateArr.count; i ++) {
        NSNumber *state = self.sfStateArr[i];
        if ([state isEqual:@1]) {
            count ++;
            
            NSNumber *currentOdd = self.sfArr[i];
            maxOdd += currentOdd.floatValue;
            
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
            if (![sell_status[0] isEqualToString:@"2"]) {
                isCanDG = NO;
            }
        }
    }
    
    //让求
    for (int i = 0; i < self.rfStateArr.count; i ++) {
        NSNumber *state = self.rfStateArr[i];
        if ([state isEqual:@1]) {
            count ++;
            
            NSNumber *currentOdd = self.rfArr[i];
            maxOdd += currentOdd.floatValue;
            
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
            if (![sell_status[0] isEqualToString:@"2"]) {
                isCanDG = NO;
            }
            isCanDG = NO;
        }
    }
    
    //大小分
    for (int i = 0; i < self.dxfStateArr.count; i ++) {
        NSNumber *state = self.dxfStateArr[i];
        if ([state isEqual:@1]) {
            count ++;
            
            NSNumber *currentOdd = self.dxfArr[i];
            maxOdd += currentOdd.floatValue;
            
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
            //            if (![sell_status[0] isEqualToString:@"2"]) {
            //                isCanDG = NO;
            //            }
            isCanDG = NO;
        }
    }
    
    
    //胜分差
    for (int i = 0; i < self.sfcStateArr.count; i ++) {
        NSNumber *state = self.sfcStateArr[i];
        if ([state isEqual:@1]) {
            count ++;
            
            NSNumber *currentOdd = self.sfcArr[i];
            maxOdd += currentOdd.floatValue;
            
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
            //            if (![sell_status[0] isEqualToString:@"2"]) {
            //                isCanDG = NO;
            //            }
            isCanDG = NO;
        }
    }
    
    

    
    self.chooseCount = count;
    self.isMoreFour = isMoreFour;
    self.isCanDG = isCanDG;
    self.maxOdd = maxOdd;
    self.minOdd = minOdd;
    if (self.chooseCount == 0) {
        self.isCanDG = YES;
    }
}






- (void)addDataWith:(NSMutableArray *)dataSoure {
    
    for (int i = 0; i < 2; i++) {
        if ([_sfStateArr[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @5;
            requstModelDic[@"odd"] = self.sfArr[i];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
        if ([_rfStateArr[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @6;
            requstModelDic[@"odd"] = self.rfArr [i];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
        
        if ([_dxfStateArr[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @8;
            requstModelDic[@"odd"] = self.dxfArr[i];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
    }
    
    for (int i = 0; i < 12; i++) {
        if ([_sfcStateArr[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @7;
            requstModelDic[@"odd"] = self.sfcArr[i];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
    }
 
}

- (void)addDefalultData:(NSMutableDictionary *)requstModelDic  {
    requstModelDic[@"event"] = self.event;
    requstModelDic[@"away"] = self.away;
    requstModelDic[@"home"] = self.home;
    requstModelDic[@"end_time"] = self.endtime;
    requstModelDic[@"issue"] = self.issue;
    requstModelDic[@"issue_num"] = self.issue_num;
    requstModelDic[@"matchtime"] = self.matchtime;
    requstModelDic[@"let_ball_count"] = [self.rf componentsSeparatedByString:@","][0];
    requstModelDic[@"total_score"] = [self.dxf componentsSeparatedByString:@","][0];
}


@end
