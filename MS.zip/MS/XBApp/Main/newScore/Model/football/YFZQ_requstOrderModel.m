//
//  YFZQ_requstOrderModel.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/12.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFZQ_requstOrderModel.h"

@implementation YFZQ_requstOrderModel



- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
