//
//  YFJCZQ_model.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/9.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YFJCZQ_model : NSObject

@property (nonatomic, strong) NSNumber *ID;

@property (nonatomic, strong) NSString *event;

@property (nonatomic, strong) NSString *home;

@property (nonatomic, strong) NSString *away;

@property (nonatomic, strong) NSString *issue;

@property (nonatomic, strong) NSString *issue_num;

@property (nonatomic, strong) NSString *sell_status;

@property (nonatomic, strong) NSNumber *matchtime;

@property (nonatomic, strong) NSString *spf;
@property (nonatomic, strong) NSArray  <NSNumber *>*spfArr;
@property (nonatomic, strong) NSMutableArray *spfState;

@property (nonatomic, strong) NSString *rq;
@property (nonatomic, strong) NSArray  <NSNumber *>*rqArr;
@property (nonatomic, strong) NSMutableArray *rqState;

@property (nonatomic, strong) NSString *bf;
@property (nonatomic, strong) NSArray  <NSNumber *>*bfArr;
@property (nonatomic, strong) NSMutableArray *bfState;

@property (nonatomic, strong) NSString *jq;
@property (nonatomic, strong) NSArray  <NSNumber *>*jqArr;
@property (nonatomic, strong) NSMutableArray *jqState;

@property (nonatomic, strong) NSString *bqc;
@property (nonatomic, strong) NSArray  <NSNumber *>*bqcArr;
@property (nonatomic, strong) NSMutableArray *bqcState;

//混投二选一
@property (nonatomic, strong) NSString *exy;
@property (nonatomic, strong) NSArray  *exyArr;
@property (nonatomic, strong) NSMutableArray *exyState;


@property (nonatomic, strong) NSString *endtime;

- (void)initData;

- (void)refreshData;

- (void)checkChooseCount;

@property (nonatomic)   BOOL isSFP;

@property (nonatomic)   BOOL isDG;  //单关Type

@property (nonatomic)   BOOL isCanDG; //进入单关下单

@property (nonatomic)   NSInteger chooseCount;
@property (nonatomic)   BOOL isMoreFour;


@property (nonatomic)   CGFloat maxOdd;
@property (nonatomic)   CGFloat minOdd;

//保存上传数据
- (void)addDataWith:(NSMutableArray *)dataSoure;


@property (nonatomic)   BOOL isHave; 
@property (nonatomic)   CGFloat canjudgeOdd;


@end
