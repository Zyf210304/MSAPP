//
//  YFJCZQ_model.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/9.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFJCZQ_model.h"
#import "YFZQ_requstOrderModel.h"

@implementation YFJCZQ_model


- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.ID = value;
    }
}


- (void)initData {
    self.canjudgeOdd = 10000;
    
    self.bfState = [NSMutableArray array];
    self.bfArr = [self.bf componentsSeparatedByString:@","];

    self.jqState = [NSMutableArray array];
    self.jqArr= [self.jq componentsSeparatedByString:@","];
    
    self.rqState = [NSMutableArray array];
    self.rqArr = [self.rq componentsSeparatedByString:@","];
    
    self.spfState = [NSMutableArray array];
    self.spfArr = [self.spf componentsSeparatedByString:@","];
    
    self.bqcState = [NSMutableArray array];
    self.bqcArr = [self.bqc componentsSeparatedByString:@","];
    
    self.exyState = [NSMutableArray array];
    
    for (int i = 0; i < 3; i++) {
        [self.spfState addObject:@0];
        [self.rqState addObject:@0];
    }
    
    for (int i = 0; i < 8; i ++) {
        [self.jqState addObject:@0];
    }
    
    for (int i = 0; i < 9; i++) {
        [self.bqcState addObject:@0];
    }
    
    for (int i = 0; i < 31; i++) {
        [self.bfState addObject:@0];
    }
    
    for (int i = 0; i < 2; i ++) {
        [self.exyState addObject:@0];
    }
    
    NSArray *spfArr = [self.spf componentsSeparatedByString:@","];
    NSArray *rqArr = [self.rq componentsSeparatedByString:@","];
    NSString *rqStr = rqArr[0];
    
    
    for (int i = 0; i < 3; i ++) {
        NSNumber *spfTempOdd = spfArr[i];
        NSNumber *rqTempOdd = rqArr[i + 1];
        
        CGFloat tempOdd = spfTempOdd.floatValue > rqTempOdd.floatValue ?  rqTempOdd.floatValue: spfTempOdd.floatValue;
        _canjudgeOdd = _canjudgeOdd > tempOdd ? tempOdd : _canjudgeOdd;
        
    }
    
    
    if (rqStr.integerValue < 0) {
        self.exy = [NSString stringWithFormat:@"%@,%@",spfArr[0], rqArr[3]];
    } else {
        self.exy = [NSString stringWithFormat:@"%@,%@",rqArr[1], spfArr[2]];
    }
    self.exyArr = [self.exy componentsSeparatedByString:@","];
    
    self.isCanDG = YES;
    self.maxOdd = 0;
    self.minOdd = 0;
    self.isHave = YES;
}


- (void)refreshData {
    [self.spfState removeAllObjects];
    [self.rqState removeAllObjects];
    [self.bfState removeAllObjects];
    [self.jqState removeAllObjects];
    [self.bqcState removeAllObjects];
    [self.exyState removeAllObjects];
    
    for (int i = 0; i < 3; i++) {
        [self.spfState addObject:@0];
        [self.rqState addObject:@0];
    }
    
    for (int i = 0; i < 8; i ++) {
        [self.jqState addObject:@0];
    }
    
    for (int i = 0; i < 9; i++) {
        [self.bqcState addObject:@0];
    }
    
    for (int i = 0; i < 31; i++) {
        [self.bfState addObject:@0];
    }
    
    for (int i = 0; i < 2; i ++) {
        [self.exyState addObject:@0];
    }
    
    self.isSFP = NO;
    self.isDG = NO;
    _chooseCount = 0;
    _isMoreFour = YES;
    _isCanDG = YES;
    self.maxOdd = 0;
    self.minOdd = 0;
    
    
    self.isHave = YES;
}


- (NSString *)description {
    return [NSString stringWithFormat:@" %@  %@  %.2lf %@  %zd %@ %@ max = %lf  min = %lf", self.home, self.away, self.canjudgeOdd, self.matchtime ,  self.chooseCount, (self.isMoreFour ? @"限制" : @"无限制"), (self.isCanDG ? @"能单关" : @"不能单关"), _maxOdd, _minOdd];
}


- (void)addDataWith:(NSMutableArray *)dataSoure {
    
    for (int i = 0; i < 3; i++) {
        if ([_spfState[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @0;
            requstModelDic[@"odd"] = [self.spf componentsSeparatedByString:@","][i];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
        if ([_rqState[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @1;
            requstModelDic[@"odd"] = [self.rq componentsSeparatedByString:@","][i + 1];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
    }
    
    for (int i = 0; i < 31; i++) {
        if ([_bfState[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @2;
            requstModelDic[@"odd"] = [self.bf componentsSeparatedByString:@","][i];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
    }
    
    for (int i = 0; i < 8; i ++) {
        if ([_jqState[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @3;
            requstModelDic[@"odd"] = [self.jq componentsSeparatedByString:@","][i];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
    }
    
    for (int i = 0; i < 9; i++) {
        if ([_bqcState[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @4;
            requstModelDic[@"odd"] = [self.bqc componentsSeparatedByString:@","][i];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
    }

    for (int i = 0; i < 2; i ++) {
        if ([_exyState[i] isEqual:@1]) {
            NSMutableDictionary * requstModelDic = [NSMutableDictionary dictionary];
            [self addDefalultData:requstModelDic];
            requstModelDic[@"game_type"] = @9;
            requstModelDic[@"odd"] = [self.exy componentsSeparatedByString:@","][i];
            requstModelDic[@"pin_type"] = @(i + 1);
            [dataSoure addObject:requstModelDic];
        }
    }
}

- (void)addDefalultData:(NSMutableDictionary *)requstModelDic {
    requstModelDic[@"event"] = self.event;
    requstModelDic[@"away"] = self.away;
    requstModelDic[@"home"] = self.home;
    requstModelDic[@"end_time"] = self.endtime;
    requstModelDic[@"issue"] = self.issue;
    requstModelDic[@"issue_num"] = self.issue_num;
    requstModelDic[@"matchtime"] = self.matchtime;
    requstModelDic[@"let_ball_count"] = [self.rq componentsSeparatedByString:@","][0];
}



- (void)checkChooseCount {
    NSInteger count = 0;
    BOOL isMoreFour = NO;
    BOOL isCanDG = YES;
    
    CGFloat maxOdd = 0;
    CGFloat minOdd = 0;
    
    CGFloat tempMax = 0;
    
    NSArray *sell_status = [self.sell_status componentsSeparatedByString:@","];
    
    
    
    //胜平负 &&  让球
    for (int i = 0; i < self.spfState.count; i ++) {
        NSNumber *state = self.spfState[i];
        if ([state isEqual:@1]) {
            count ++;
            NSNumber *currentOdd = self.spfArr[i];
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
            
            if (![sell_status[0] isEqualToString:@"2"]) {
                isCanDG = NO;
            }
        }
    }

    for (int i = 0; i < self.rqState.count; i ++) {
        NSNumber *state = self.rqState[i];
        
        if ([state isEqual:@1]) {
            count ++;
            
            NSNumber *currentOdd = self.rqArr[i + 1];
            
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
            if (![sell_status[0] isEqualToString:@"2"]) {
                isCanDG = NO;
            }
             isCanDG = NO;
        }
    }
    
    CGFloat SPFAndRQMaxOdd = [self countSPFAndRQMaxOdd];
    maxOdd += SPFAndRQMaxOdd;
    
 
    
    
    //比分
   tempMax = 0;
    for (int i = 0; i < self.bfState.count; i ++) {
        NSNumber *state = self.bfState[i];
        if ([state isEqual:@1]) {
            count ++;
            
            NSNumber *currentOdd = self.bfArr[i];
            
            tempMax  = tempMax > currentOdd.floatValue ? tempMax : currentOdd.floatValue;
            
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
//            if (![sell_status[0] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
             isCanDG = NO;
        }
    }
    
    maxOdd += tempMax;
    
    
    
    
    //进球
    tempMax = 0;
    for (int i = 0; i < self.jqState.count; i ++) {
        NSNumber *state = self.jqState[i];
        if ([state isEqual:@1]) {
            count ++;
            
            NSNumber *currentOdd = self.jqArr[i];
            
            tempMax  = tempMax > currentOdd.floatValue ? tempMax : currentOdd.floatValue;
            
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
//            if (![sell_status[0] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
             isCanDG = NO;
        }
    }
    
    maxOdd += tempMax;
    
    
    
    
    //半全场
    tempMax = 0;
    for (int i = 0; i < self.bqcState.count; i ++) {
        NSNumber *state = self.bqcState[i];
        if ([state isEqual:@1]) {
            count ++;
            
            NSNumber *currentOdd = self.bqcArr[i];
            
            tempMax  = tempMax > currentOdd.floatValue ? tempMax : currentOdd.floatValue;
            
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
//            if (![sell_status[0] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
             isCanDG = NO;
        }
    }
    
    maxOdd += tempMax;

    
    
    
    //二选一
    tempMax = 0;
    for (int i = 0; i < self.exyState.count; i ++) {
        NSNumber *state = self.exyState[i];
        if ([state isEqual:@1]) {
            count ++;
            
            NSNumber *currentOdd = self.exyArr[i];
            
            tempMax  = tempMax > currentOdd.floatValue ? tempMax : currentOdd.floatValue;
            
            if (minOdd > 0) {
                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
            } else {
                minOdd = currentOdd.floatValue;
            }
            
//            if (![sell_status[0] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
             isCanDG = NO;
        }
    }
    
    maxOdd += tempMax;
    
    
    self.chooseCount = count;
    self.isMoreFour = isMoreFour;
    self.isCanDG = isCanDG;
    self.maxOdd = maxOdd;
    self.minOdd = minOdd;
    if (self.chooseCount == 0) {
        self.isCanDG = YES;
    }
}


- (CGFloat)countSPFAndRQMaxOdd {
    CGFloat maxOdd = 0;
    
    CGFloat shengOdd = 0;
    CGFloat pingOdd = 0;
    CGFloat fuOdd = 0;

    
    
    if ([NSString stringWithFormat:@"%@", self.rqArr[0]].floatValue < 0) {

        //胜
        shengOdd += [self.spfState[0] isEqual:@1] ? self.spfArr[0].floatValue : 0;
        if ([self.rqState[0] isEqual:@1] && [self.rqState[1] isEqual:@1] ) {
            shengOdd += self.rqArr[1].floatValue > self.rqArr[2].floatValue ?self.rqArr[1].floatValue  :self.rqArr[2].floatValue ;
        } else {
            shengOdd += [self.rqState[0] isEqual:@1] ? self.rqArr[1].floatValue : 0;
            shengOdd += [self.rqState[1] isEqual:@1]  ? self.rqArr[2].floatValue : 0;
        }
        
        
        //平
        pingOdd += [self.spfState[1] isEqual:@1] ? self.spfArr[1].floatValue : 0;
        pingOdd += [self.rqState[2] isEqual:@1] ? self.rqArr[3].floatValue : 0;
        
        
        //负
        fuOdd += [self.spfState[2] isEqual:@1] ? self.spfArr[2].floatValue : 0;
        fuOdd += [self.rqState[2] isEqual:@1] ? self.rqArr[3].floatValue : 0;
        
    } else {
        
        //胜
        shengOdd += [self.spfState[0] isEqual:@1] ? self.spfArr[0].floatValue : 0;
        shengOdd += [self.rqState[0] isEqual:@1] ? self.rqArr[1].floatValue : 0;
        
        
        //平
        pingOdd += [self.spfState[1] isEqual:@1] ? self.spfArr[1].floatValue : 0;
        pingOdd += [self.rqState[0] isEqual:@1] ? self.rqArr[1].floatValue : 0;
        
        
        //负
        fuOdd += [self.spfState[2] isEqual:@1] ? self.spfArr[2].floatValue : 0;
        if ([self.rqState[1] isEqual:@1] && [self.rqState[2] isEqual:@1] ) {
            fuOdd += self.rqArr[2].floatValue > self.rqArr[3].floatValue ?self.rqArr[2].floatValue  :self.rqArr[3].floatValue ;
        } else {
            fuOdd += [self.rqState[1] isEqual:@1] ? self.rqArr[2].floatValue : 0;
            fuOdd += [self.rqState[2] isEqual:@1]  ? self.rqArr[3].floatValue : 0;
        }
  
    }
    
    
    maxOdd = shengOdd > pingOdd ? shengOdd > fuOdd ? shengOdd : fuOdd : pingOdd > fuOdd ? pingOdd : fuOdd;

    
    
    return maxOdd;
}






@end
