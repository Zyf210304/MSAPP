//
//  YFBasketBallTypeVIew.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBasketBallTypeVIew.h"

@implementation YFBasketBallTypeVIew


- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUIWithChoosView];
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    }
    return self;
}

- (void)initUIWithChoosView {
    
    UIView *chooseView = [[UIView alloc] init];
    [self addSubview:chooseView];
    chooseView.backgroundColor = [UIColor whiteColor];
    [chooseView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(130 *SCALE_375);
    }];
    
    NSArray *titelArr = @[@"胜负",  @"让分胜负",  @"胜分差",
                          @"大小分",  @"混合过关",  @"单关"];
    
    CGFloat lbl_width = (FRAME_WIDTH - 60) / 3;
    CGFloat lbl_height = 40 *SCALE_375;
    for (int i = 0; i < 2; i ++) {
        for (int j = 0; j < 3; j ++) {

            UILabel *typelbl = [[UILabel alloc] init];
            typelbl.text = titelArr[i * 3 + j];
            typelbl.tag = 2000 + i * 3 + j;
            [chooseView addSubview:typelbl];
            typelbl.textColor = Color_title_333;
            typelbl.font = [UIFont systemFontOfSize:15 *SCALE_375];
            typelbl.textAlignment = NSTextAlignmentCenter;
            typelbl.layer.masksToBounds = YES;
            typelbl.layer.cornerRadius = 4 *SCALE_375;
            typelbl.layer.borderWidth = 1;
            typelbl.layer.borderColor = Color_title_bbb.CGColor;
            [typelbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.width.mas_offset(lbl_width);
                make.height.mas_offset(lbl_height);
                make.left.mas_offset(15 *SCALE_375 + (15 *SCALE_375 + lbl_width) * j);
                make.top.mas_offset(10 *SCALE_375 + (10 *SCALE_375 + lbl_height) *i);
            }];
            
            [typelbl addTapgestureWithTarget:self action:@selector(changeCurrenttype:)];
        }
    }
}


- (void)changeCurrenttype:(UITapGestureRecognizer *)sender {
    UILabel *typelbl = (UILabel *)sender.view;
    self.hidden = YES;
    self.changeLotteryType(typelbl.tag - 2000, typelbl.text);
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
