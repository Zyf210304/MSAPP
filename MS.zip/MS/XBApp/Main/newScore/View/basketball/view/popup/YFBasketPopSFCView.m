//
//  YFBasketPopSFCView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/24.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBasketPopSFCView.h"
#import "YFJCLQModel.h"

@interface YFBasketPopSFCView()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) UILabel *matchtitle;

@property (nonatomic, strong) NSArray *titleArr;

@property (nonatomic, strong) YFJCLQModel *currentmodel;

@end

@implementation YFBasketPopSFCView


- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        self.titleArr = @[@"客胜(1-5)", @"客胜(6-10)", @"客胜(11-15)",
                            @"客胜(16-20)", @"客胜(11-25)", @"客胜(26+)",
                            @"主胜(1-5)", @"主胜(6-10)", @"主胜(11-15)",
                            @"主胜(16-20)", @"主胜(21-25)", @"主胜(36+)"];
        
        [self initUI];
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
        [self addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    }
    return self;
}

- (void)initUI {
    UIView *centerView = [[UIView alloc] init];
    [self addSubview:centerView];
    centerView.backgroundColor = Color_Base_BG;
    centerView.layer.masksToBounds = YES;
    centerView.layer.cornerRadius = 3.0;
    [centerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_offset(FRAME_WIDTH - 30 *SCALE_375);
        make.height.mas_offset(225 *SCALE_375);
        make.centerX.equalTo(self.mas_centerX);
        make.centerY.equalTo(self.mas_centerY);
    }];
    [centerView addTapgestureWithTarget:self action:@selector(nothing:)];
    
    [self addMatchtitle:centerView];
    [self addBottmChooseLbl:centerView];
    [self addCenterChooseView:centerView];
}

- (void)addMatchtitle:(UIView *)centerView {
    UILabel *matchtitle = [[UILabel alloc] init];
    [centerView addSubview:matchtitle];
    matchtitle.textAlignment = NSTextAlignmentCenter;
    matchtitle.textColor = Color_title_333;
    matchtitle.text = @"甲方  VS  乙方";
    _matchtitle = matchtitle;
    matchtitle.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [matchtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(31 *SCALE_375);
    }];
    
}



- (void)addBottmChooseLbl:(UIView *)centerView  {
    
    UILabel *leftLbl = [[UILabel alloc] init];
    [centerView addSubview:leftLbl];
    leftLbl.textAlignment = NSTextAlignmentCenter;
    leftLbl.backgroundColor = [UIColor whiteColor];
    leftLbl.text = @"取消";
    leftLbl.textColor = Color_title_333;
    leftLbl.font = [UIFont systemFontOfSize:13];
    [leftLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.mas_offset(0);
        make.right.equalTo(centerView.mas_centerX).offset(-0.5);
        make.height.mas_offset(41 *SCALE_375);
    }];
    [leftLbl addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    
    UILabel *rightLbl = [[UILabel alloc] init];
    [centerView addSubview:rightLbl];
    rightLbl.textAlignment = NSTextAlignmentCenter;
    rightLbl.backgroundColor = [UIColor whiteColor];
    rightLbl.text = @"确定";
    rightLbl.textColor = UIColorFromRGB(0xA94148);
    rightLbl.font = [UIFont systemFontOfSize:13];
    [rightLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.mas_offset(0);
        make.left.equalTo(centerView.mas_centerX).offset(0.5);
        make.height.mas_offset(41 *SCALE_375);
    }];
    
    [rightLbl addTapgestureWithTarget:self action:@selector(trueAction:)];
}

- (void)addCenterChooseView:(UIView *)centerView  {
    
    [self addScoreLeftView:centerView];
    [self addScoreRightView:centerView];
    
    
    
}

- (void)addScoreLeftView:(UIView *)centerView {
    
    UILabel *leftTopLBl = [[UILabel alloc] init];
    [centerView addSubview:leftTopLBl];
    leftTopLBl.text = @"客胜";
    leftTopLBl.numberOfLines = 0;
    leftTopLBl.textAlignment = NSTextAlignmentCenter;
    leftTopLBl.textColor = [UIColor whiteColor];
    leftTopLBl.backgroundColor = UIColorFromRGB(0x5EC5A8);
    leftTopLBl.font = [UIFont systemFontOfSize:12 *SCALE_375];
    [leftTopLBl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(5 *SCALE_375);
        make.top.mas_offset(30 *SCALE_375);
        make.width.mas_offset(22 *SCALE_375);
        make.height.mas_offset(74 *SCALE_375);
    }];
    
    UILabel *leftBottomLBl = [[UILabel alloc] init];
    [centerView addSubview:leftBottomLBl];
    leftBottomLBl.text = @"主胜";
    leftBottomLBl.numberOfLines = 0;
    leftBottomLBl.textAlignment = NSTextAlignmentCenter;
    leftBottomLBl.textColor = [UIColor whiteColor];
    leftBottomLBl.backgroundColor = UIColorFromRGB(0x5EC5A8);
    leftBottomLBl.font = [UIFont systemFontOfSize:12 *SCALE_375];
    [leftBottomLBl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(5 *SCALE_375);
        make.top.mas_offset(105 *SCALE_375);
        make.width.mas_offset(22 *SCALE_375);
        make.height.mas_offset(74 *SCALE_375);
    }];
}

- (void)addScoreRightView:(UIView *)centerView {
    for (int i = 0; i < 4; i ++) {
        for (int j = 0; j < 3; j ++) {
            
            UILabel *typeLbl = [[UILabel alloc] init];
            [centerView addSubview:typeLbl];
            typeLbl.textAlignment = NSTextAlignmentCenter;
            typeLbl.numberOfLines = 0;
            typeLbl.tag = 2000 + i * 3 + j;
            typeLbl.text = [NSString stringWithFormat:@"%@", _titleArr[i * 3 + j]];
            typeLbl.font = [UIFont systemFontOfSize:12 *SCALE_375];
            typeLbl.backgroundColor = [UIColor whiteColor];
            [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(27 *SCALE_375 + 105 *SCALE_375 * j);
                make.top.mas_offset(30 *SCALE_375 + 36 *SCALE_375 * i);
                make.width.mas_offset(104 *SCALE_375);
                make.height.mas_offset(35 *SCALE_375);
            }];
            
            [typeLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
        }
    }
}

- (void)nothing:(UITapGestureRecognizer *)sender {
    NSLog(@"");
}

- (void)hiddenSelf:(UITapGestureRecognizer *)sender {
    self.trueBlock();
    self.hidden = YES;
}


- (void)setValueWith:(YFJCLQModel *)model {
    self.currentmodel = model;
    
    //胜分差
    for (int i = 0; i < 4; i ++) {
        for (int j = 0; j < 3; j ++) {
            
            UILabel *typeLbl = [self viewWithTag:2000 + i * 3 + j];
            typeLbl.text = [NSString stringWithFormat:@"%@\n%@", _titleArr[i * 3 + j], model.sfcArr[i *3 +j]];
            [self lableState:typeLbl isSelect:[model.sfcStateArr[i * 3 + j] isEqual:@1]];
        }
    }
    [_currentmodel checkChooseCount];
    
}


//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {
    
    UILabel *currentLbl = (UILabel *)sender.view;
    
    _currentmodel.sfcStateArr[currentLbl.tag - 2000] =  [_currentmodel.sfcStateArr[currentLbl.tag - 2000] isEqual:@0] ? @1 : @0;
    BOOL isSelect = [_currentmodel.sfcStateArr[currentLbl.tag - 2000] isEqual:@1];
    
    [self lableState:currentLbl isSelect:isSelect];
    [_currentmodel checkChooseCount];
}


// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
}


- (void)trueAction:(UITapGestureRecognizer *)sender {
    self.hidden = YES;
    self.trueBlock();
}





/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
