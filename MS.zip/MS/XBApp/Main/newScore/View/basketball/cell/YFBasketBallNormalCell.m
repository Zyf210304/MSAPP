//
//  YFBasketBallNormalCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBasketBallNormalCell.h"
#import "YFJCLQModel.h"

@interface YFBasketBallNormalCell()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) UILabel *matchtitle;

@property (nonatomic, strong) UILabel *chooseNumLbl;

@property (nonatomic, strong) UIImageView *danImg;

@property (nonatomic, strong) YFJCLQModel *currentmodel;

@end

@implementation YFBasketBallNormalCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFBasketBallNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFBasketBallNormalCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        
        [cell initUI];
    }
    return cell;
}


- (void)initUI  {
    
    self.danImg = [[UIImageView alloc] init];
    [self addSubview:_danImg];
    _danImg.hidden = YES;
    _danImg.image = [UIImage imageNamed:@"icon_dan"];
    [_danImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_offset(0);
        make.width.height.mas_offset(27 *SCALE_375);
    }];
    

    UILabel *contentLbl = [[UILabel alloc] init];
    [self addSubview:contentLbl];
    self.contentLbl = contentLbl;
    contentLbl.textColor = Color_title_666;
    contentLbl.textAlignment = NSTextAlignmentCenter;
    contentLbl.numberOfLines = 0;
    contentLbl.text = @"001\n\n国际赛\n\n17:40截止";
    contentLbl.font = [UIFont systemFontOfSize:11];
    [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(0);
        make.top.bottom.mas_offset(0);
        make.width.mas_offset(61 *SCALE_375);
    }];
    
    [self addMatchtitle];
    [self addCenterView];
    [self addRightView];
}

- (void)addMatchtitle {
    
    UILabel *matchtitle = [[UILabel alloc] init];
    [self addSubview:matchtitle];
    _matchtitle = matchtitle;
    matchtitle.textAlignment = NSTextAlignmentCenter;
    matchtitle.textColor = Color_title_333;
    matchtitle.text = @"甲方  VS  乙方";
    matchtitle.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [matchtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(45 *SCALE_375);
    }];
    
}


- (void)addCenterView {
    
    NSArray *titleArr = @[@"0", @"让", @"大\n小\n分"];

    for (int i = 0; i < 3; i++) {
        [self addCenterChildView:i];
        UILabel *contenLbl = [self viewWithTag:200 + 100 *i];
        contenLbl.text = titleArr[i];
        if (i == 0) {
            contenLbl.backgroundColor = [UIColor colorWithRed:234/255.0 green:230/255.0 blue:231/255.0 alpha:1];
        }else if (i == 1) {
            contenLbl.backgroundColor = [UIColor colorWithRed:183/255.0 green:202/255.0 blue:235/255.0 alpha:1];
        } else{
            contenLbl.backgroundColor = [UIColor colorWithRed:89/255.0 green:200/255.0 blue:168/255.0 alpha:1];
            contenLbl.font = [UIFont systemFontOfSize:9 *SCALE_375];
        }
    }
    
}

- (void)addCenterChildView:(NSInteger)count {
    CGFloat top = 45 *SCALE_375 + 36 *SCALE_375 *count;
    CGFloat width = 112 *SCALE_375;
    NSArray *left = @[@64, @86, @199];
    for (int i = 0; i < 3; i ++) {
        UILabel *contentLBl = [[UILabel alloc] init];
        [self addSubview:contentLBl];
        NSNumber *leftDis = left[i];
        contentLBl.backgroundColor = [UIColor whiteColor];
        contentLBl.textColor = Color_title_333;
        contentLBl.font = [UIFont systemFontOfSize:13 *SCALE_375];
        contentLBl.textAlignment = NSTextAlignmentCenter;
        contentLBl.text = @"主胜\n5.90";
        contentLBl.numberOfLines = 0;
        CGFloat lblWidth = i == 0 ? 20 : width;
        contentLBl.tag = 200 + 100 * count + i;
        [contentLBl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(leftDis.integerValue);
            make.width.mas_offset(lblWidth);
            make.height.mas_offset(35 *SCALE_375);
            make.top.mas_offset(top);
        }];
        
        if (i > 0) {
            [contentLBl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
        }
    }
    
   
    
    UILabel *notOpen = [[UILabel alloc] init];
    [self addSubview:notOpen];
    notOpen.textColor = Color_title_333;
    notOpen.backgroundColor = [UIColor whiteColor];
    notOpen.textAlignment = NSTextAlignmentCenter;
    notOpen.text = @"未开放";
    notOpen.tag = 700 + count;
    notOpen.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [notOpen mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(64 *SCALE_375);
        make.top.mas_offset(top);
        make.right.mas_offset(- 63 *SCALE_375);
        make.height.mas_offset(35 *SCALE_375);
    }];
    notOpen.hidden = YES;
    
}


- (void)addRightView {
    UILabel *rightLbl = [[UILabel alloc] init];
    [self addSubview:rightLbl];
    _chooseNumLbl = rightLbl;
    rightLbl.backgroundColor = [UIColor whiteColor];
    rightLbl.textColor = UIColorFromRGB(0x979184);
    rightLbl.textAlignment = NSTextAlignmentCenter;
    rightLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    rightLbl.numberOfLines = 2;
    rightLbl.text = @"全部\n玩法";
    [rightLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(314 *SCALE_375);
        make.top.mas_offset(45 *SCALE_375);
        make.width.mas_offset(51 *SCALE_375);
        make.height.mas_offset(106 *SCALE_375);
    }];
    
    [rightLbl addTapgestureWithTarget:self action:@selector(gotoDetailAction:)];
    
}

- (void)gotoDetailAction:(UITapGestureRecognizer *)sender {
    self.gotoDeatil();
}


- (void)setValueWith:(YFJCLQModel *)model {
    
    _currentmodel = model;
    NSString *time = [NSString getmatichTime:model.matchtime.integerValue];
    _contentLbl.text = [NSString stringWithFormat:@"\n%@\n%@\n%@截止", model.event,  [model.issue_num  substringFromIndex:1], time];
    
    _matchtitle.text = [NSString stringWithFormat:@"%@ VS %@", model.home, model.away];
    
    for (int i = 0; i < 3; i ++) {
        for (int j = 1; j < 3; j ++) {
            UILabel *contentLBl = [self viewWithTag:200 + 100 * i + j];
            contentLBl.tag = 200 + 100 * i + j;
            //胜负
            if (i == 0 && j > 0) {
                if (j == 1) {
                    contentLBl.text = [NSString stringWithFormat:@"主负\n%@", model.sfArr[0]];
                    [self lableState:contentLBl isSelect:[model.sfStateArr[0] isEqual:@1]];
                } else {
                    contentLBl.text = [NSString stringWithFormat:@"主胜\n%@", model.sfArr[1]];
                    [self lableState:contentLBl isSelect:[model.sfStateArr[1] isEqual:@1]];
                }
                
            }
            //让胜
            if (i == 1 && j > 0) {
                if (j == 1) {
                    contentLBl.text = [NSString stringWithFormat:@"主负\n%@", model.rfArr[0]];
                    [self lableState:contentLBl isSelect:[model.rfStateArr[0] isEqual:@1]];
                } else {
                    contentLBl.text = [NSString stringWithFormat:@"主胜(%@)\n%@", [model.rf componentsSeparatedByString:@","][0], model.rfArr[1]];
                    [self lableState:contentLBl isSelect:[model.rfStateArr[1] isEqual:@1]];
                }
            }
            
            //大小分
            if (i == 2 && j > 0) {
                if (j == 1) {
                    contentLBl.text = [NSString stringWithFormat:@"大于%@分\n%@",[model.dxf componentsSeparatedByString:@","][0], model.rfArr[0]];
                     [self lableState:contentLBl isSelect:[model.dxfStateArr[0] isEqual:@1]];
                } else {
                    contentLBl.text = [NSString stringWithFormat:@"小于%@分\n%@", [model.dxf componentsSeparatedByString:@","][0], model.rfArr[1]];
                    [self lableState:contentLBl isSelect:[model.dxfStateArr[1] isEqual:@1]];
                }
            }
        }
    }
    
    [model checkChooseCount];
    if (_currentmodel.chooseCount > 0) {
        _chooseNumLbl.text = [NSString stringWithFormat:@"已选\n%zd项", _currentmodel.chooseCount];
        _chooseNumLbl.backgroundColor = [UIColor redColor];
        _chooseNumLbl.textColor = [UIColor whiteColor];
    } else {
        _chooseNumLbl.text = @"全部\n玩法";
        _chooseNumLbl.backgroundColor = [UIColor whiteColor];
        _chooseNumLbl.textColor = UIColorFromRGB(0x979184);
    }
    
    UILabel *rqLbl = [self viewWithTag:300];
    NSString *rqStr = [model.rf componentsSeparatedByString:@","][0];
    if (rqStr.integerValue > 0) {
        rqLbl.backgroundColor = JKRGBColor(249, 220, 226);
    } else {
        rqLbl.backgroundColor = JKRGBColor(226, 242, 177);
    }
}




//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {

    UILabel *currentLbl = (UILabel *)sender.view;
    BOOL isSelect = NO;
    if (currentLbl.tag > 200 && currentLbl.tag < 300) {
        _currentmodel.sfStateArr[currentLbl.tag - 201] = [_currentmodel.sfStateArr[currentLbl.tag - 201] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.sfStateArr[currentLbl.tag - 201] isEqual:@1];
    }
    
    if (currentLbl.tag > 300 && currentLbl.tag < 400) {
        _currentmodel.rfStateArr[currentLbl.tag - 301] = [_currentmodel.rfStateArr[currentLbl.tag - 301] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.rfStateArr[currentLbl.tag - 301] isEqual:@1];
    }
    
    if (currentLbl.tag > 400) {
        _currentmodel.dxfStateArr[currentLbl.tag - 401] = [_currentmodel.dxfStateArr[currentLbl.tag - 401] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.dxfStateArr[currentLbl.tag - 401] isEqual:@1];
    }
    
    [self lableState:currentLbl isSelect:isSelect];

    [_currentmodel checkChooseCount];
    
    if (_currentmodel.chooseCount > 0) {
        _chooseNumLbl.text = [NSString stringWithFormat:@"已选\n%zd项", _currentmodel.chooseCount];
        _chooseNumLbl.backgroundColor = [UIColor redColor];
        _chooseNumLbl.textColor = [UIColor whiteColor];
    } else {
        _chooseNumLbl.text = @"全部\n玩法";
        _chooseNumLbl.backgroundColor = [UIColor whiteColor];
        _chooseNumLbl.textColor = UIColorFromRGB(0x979184);
    }

    self.dataDidChanged();


}

// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
    
}









- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
