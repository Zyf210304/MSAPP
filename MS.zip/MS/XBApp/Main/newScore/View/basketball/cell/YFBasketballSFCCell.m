//
//  YFBasketballSFCCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/24.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBasketballSFCCell.h"
#import "YFJCLQModel.h"

@interface YFBasketballSFCCell()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) UILabel *matchtitle;

@property (nonatomic, strong) UILabel *centerLbl;

@property (nonatomic, strong) NSArray *titleArr;

@property (nonatomic, strong) YFJCLQModel *currentmodel;


@end

@implementation YFBasketballSFCCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


// 37 + 41 + 24   37 + 65  =102
+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFBasketballSFCCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFBasketballSFCCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        [cell initUI];
    }
    return cell;
}


- (void)initUI  {
    
    NSArray *titleArr = @[@"客胜(1-5)", @"客胜(6-10)", @"客胜(11-15)",
                          @"客胜(16-20)", @"客胜(11-25)", @"客胜(26+)",
                          @"主胜(1-5)", @"主胜(6-10)", @"主胜(11-15)",
                          @"主胜(16-20)", @"主胜(21-25)", @"主胜(36+)"];
    _titleArr = titleArr;
    
    UILabel *contentLbl = [[UILabel alloc] init];
    [self addSubview:contentLbl];
    self.contentLbl = contentLbl;
    contentLbl.textColor = Color_title_666;
    contentLbl.textAlignment = NSTextAlignmentCenter;
    contentLbl.numberOfLines = 0;
    contentLbl.text = @"001\n\n国际赛\n\n17:40截止";
    contentLbl.font = [UIFont systemFontOfSize:11];
    [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(0);
        make.top.bottom.mas_offset(0);
        make.width.mas_offset(61 *SCALE_375);
    }];
    [self addMatchtitle];
    [self addCenterView];
}


- (void)addMatchtitle {
    UILabel *matchtitle = [[UILabel alloc] init];
    [self addSubview:matchtitle];
    matchtitle.textAlignment = NSTextAlignmentCenter;
    matchtitle.textColor = Color_title_333;
    matchtitle.text = @"甲方  VS  乙方";
    _matchtitle = matchtitle;
    matchtitle.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [matchtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(37 *SCALE_375);
    }];
    
}


- (void)addCenterView {
    
    UILabel *centerLbl = [[UILabel alloc] init];
    [self addSubview:centerLbl];
    centerLbl.textColor = Color_title_333;
    centerLbl.font = [UIFont systemFontOfSize:11 *SCALE_375];
    centerLbl.textAlignment = NSTextAlignmentCenter;
    centerLbl.backgroundColor = [UIColor whiteColor];
    centerLbl.text = @"点击投注";
    _centerLbl = centerLbl;
    [centerLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(67 *SCALE_375);
        make.top.mas_offset(34 *SCALE_375);
        make.right.mas_offset(- 10 *SCALE_375);
        make.height.mas_offset(41 *SCALE_375);
    }];
    
    [centerLbl addTapgestureWithTarget:self action:@selector(chooseAction:)];
    
}

- (void)chooseAction:(UITapGestureRecognizer *)sender {
    self.chooseLotteryBlock();
}


- (void)setValueWith:(YFJCLQModel *)model {
    self.currentmodel = model;
    
    NSString *time = [NSString getmatichTime:model.matchtime.integerValue];
    _contentLbl.text = [NSString stringWithFormat:@"%@\n%@\n%@截止", model.event,  [model.issue_num  substringFromIndex:1], time];
    _matchtitle.text = [NSString stringWithFormat:@"%@ VS %@", model.home, model.away];
    
    _centerLbl.textColor = Color_title_333;
    _centerLbl.backgroundColor = [UIColor whiteColor];
    _centerLbl.text = @"点击投注";
    
     [_currentmodel checkChooseCount];
    
    NSString *contenStr = @"";
    for (int i = 0; i < _currentmodel.sfcStateArr.count; i++) {
        NSNumber *selcet = _currentmodel.sfcStateArr[i];
        if ([selcet isEqual:@1]) {
            contenStr = [NSString stringWithFormat:@"%@%@[%@] ", contenStr, _titleArr[i], _currentmodel.sfcArr[i]];
        }
    }
    [self changeContentLbl:contenStr];
}

- (void)changeContentLbl:(NSString *)contenStr {
    
    if (!contenStr.length) {
        _centerLbl.textColor = Color_title_333;
        _centerLbl.backgroundColor = [UIColor whiteColor];
        _centerLbl.text = @"点击投注";
    } else {
        _centerLbl.textColor = [UIColor whiteColor];
        _centerLbl.backgroundColor = [UIColor redColor];
        _centerLbl.text = contenStr;
    }
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
