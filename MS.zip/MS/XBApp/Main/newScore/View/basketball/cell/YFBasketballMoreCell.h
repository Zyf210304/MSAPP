//
//  YFBasketballMoreCell.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YFJCLQModel;

typedef enum {
    
    Match_Result,
    
    Match_Score,

}mathchType;


@interface YFBasketballMoreCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView addType:(mathchType)type;


@property (nonatomic, strong) YFJCLQModel *lqModel;

- (void)setValueWithModel:(YFJCLQModel *)model;

@property (nonatomic, copy) void(^dataDidChanged)(void);

@end
