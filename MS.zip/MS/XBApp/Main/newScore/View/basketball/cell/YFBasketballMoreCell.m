//
//  YFBasketballMoreCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/23.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBasketballMoreCell.h"
#import "YFJCLQModel.h"

@interface YFBasketballMoreCell()

@property (nonatomic, strong) NSArray *titleArr;

@property (nonatomic, strong) YFJCLQModel *currentmodel;

@end
@implementation YFBasketballMoreCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+ (instancetype)cellWithTableView:(UITableView *)tableView addType:(mathchType)type{
    YFBasketballMoreCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFBasketballMoreCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        [cell initUIWith:type];
    }
    return cell;
}

- (void)initUIWith:(mathchType)type {
    
    UILabel *titleLbl = [[UILabel alloc] init];
    [self addSubview:titleLbl];
    titleLbl.textColor = Color_title_333;
    titleLbl.text = @"类型";
    titleLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [titleLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(9 *SCALE_375);
        make.top.mas_offset(22 *SCALE_375);
    }];
    
    NSArray *titleArr = @[@"客胜(1-5)", @"客胜(6-10)", @"客胜(11-15)",
                          @"客胜(16-20)", @"客胜(11-25)", @"客胜(26+)",
                          @"主胜(1-5)", @"主胜(6-10)", @"主胜(11-15)",
                          @"主胜(16-20)", @"主胜(21-25)", @"主胜(36+)"];
    _titleArr = titleArr;
    
    
    switch (type) {
        case Match_Result:
            [self addResultView];
            break;
        case Match_Score:
            [self addScoreView];
            break;
        default:
            break;
    }
}


//胜负和大小分
- (void)addResultView {
    
    for (int i = 0; i < 3; i++) {
        
        NSArray *titleArr = @[@"0", @"让", @"大\n小\n分"];
        [self addResultCenterChildView:i];
        UILabel *contenLbl = [self viewWithTag:200 + 100 *i];
        contenLbl.numberOfLines = 0;
        contenLbl.text = titleArr[i];
        if (i == 0) {
            contenLbl.backgroundColor = [UIColor colorWithRed:234/255.0 green:230/255.0 blue:231/255.0 alpha:1];
        }else if (i == 1) {
            contenLbl.backgroundColor = [UIColor colorWithRed:183/255.0 green:202/255.0 blue:235/255.0 alpha:1];
        } else{
            contenLbl.backgroundColor = [UIColor colorWithRed:89/255.0 green:200/255.0 blue:168/255.0 alpha:1];
            contenLbl.font = [UIFont systemFontOfSize:9 *SCALE_375];
        }
        
    }
}


- (void)addResultCenterChildView:(NSInteger)count {
    CGFloat top = 43 *SCALE_375 + 36 *SCALE_375 *count;
    CGFloat width = 164 *SCALE_375;
    NSArray *left = @[@8, @30, @194];
    for (int i = 0; i < 3; i ++) {
        UILabel *contentLBl = [[UILabel alloc] init];
        [self addSubview:contentLBl];
        NSNumber *leftDis = left[i];
        contentLBl.backgroundColor = [UIColor whiteColor];
        contentLBl.textColor = Color_title_333;
        contentLBl.font = [UIFont systemFontOfSize:13 *SCALE_375];
        contentLBl.textAlignment = NSTextAlignmentCenter;
        contentLBl.text = @"主胜\n5.90";
        contentLBl.numberOfLines = 0;
        contentLBl.tag = 200 + 100 * count + i;
        CGFloat lblWidth = i == 0 ? 21 : width;
        [contentLBl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(leftDis.integerValue);
            make.width.mas_offset(lblWidth);
            make.height.mas_offset(35 *SCALE_375);
            make.top.mas_offset(top);
        }];
        if (i > 0) {
            [contentLBl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
        }
    }
    
    
    
    UILabel *notOpen = [[UILabel alloc] init];
    [self addSubview:notOpen];
    notOpen.textColor = Color_title_333;
    notOpen.backgroundColor = [UIColor whiteColor];
    notOpen.textAlignment = NSTextAlignmentCenter;
    notOpen.text = @"未开放";
    notOpen.tag = 700 + count;
    notOpen.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [notOpen mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(86 *SCALE_375);
        make.top.mas_offset(top);
        make.right.mas_offset(- 63 *SCALE_375);
        make.height.mas_offset(35 *SCALE_375);
    }];
    notOpen.hidden = YES;
    
}


//胜分差
- (void)addScoreView {
    [self addScoreLeftView];
    [self addScoreRightView];
}

- (void)addScoreLeftView {
    
    for (int i = 0 ; i < 2; i ++) {
        
        CGFloat top = i == 0 ? 49 *SCALE_375 : 120 *SCALE_375;
        UILabel *titleLbl = [[UILabel alloc] init];
        [self addSubview:titleLbl];
        titleLbl.textAlignment = NSTextAlignmentCenter;
        titleLbl.numberOfLines = 0;
        titleLbl.font = [UIFont systemFontOfSize:12 *SCALE_375];
        [titleLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(8 *SCALE_375);
            make.top.mas_offset(top);
            make.width.mas_offset(22 *SCALE_375);
            make.height.mas_offset(71 *SCALE_375);
        }];
        
        titleLbl.text = i == 0 ? @"客胜" : @"主胜";
        titleLbl.textColor = [UIColor whiteColor];
        titleLbl.backgroundColor =  i == 0 ? [UIColor colorWithRed:94/255.0 green:197/255.0 blue:168/255.0 alpha:1] :  [UIColor colorWithRed:99/255.0 green:186/255.0 blue:238/255.0 alpha:1];
        
    }
}

- (void)addScoreRightView {
    
    
    for (int i = 0; i < 4; i ++) {
        for (int j = 0; j < 3; j ++) {
            
            UILabel *typeLbl = [[UILabel alloc] init];
            [self addSubview:typeLbl];
            typeLbl.textAlignment = NSTextAlignmentCenter;
            typeLbl.numberOfLines = 0;
            typeLbl.tag = 2000 + i * 3 + j;
            typeLbl.text = [NSString stringWithFormat:@"%@", _titleArr[i * 3 + j]];
            typeLbl.font = [UIFont systemFontOfSize:12 *SCALE_375];
            typeLbl.backgroundColor = [UIColor whiteColor];
            [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(30 *SCALE_375 + 110 *SCALE_375 * j);
                make.top.mas_offset(49 *SCALE_375 + 36 *SCALE_375 * i);
                make.width.mas_offset(109 *SCALE_375);
                make.height.mas_offset(35 *SCALE_375);
            }];
            [typeLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
        }
    }
}


- (void)setValueWithModel:(YFJCLQModel *)model {
    _currentmodel = model;
    //胜负
    for (int i = 0; i < 3; i ++) {
        for (int j = 1; j < 3; j ++) {
            UILabel *contentLBl = [self viewWithTag:200 + 100 * i + j];
            contentLBl.tag = 200 + 100 * i + j;
            //胜负
            if (i == 0) {
                if (j == 1) {
                    contentLBl.text = [NSString stringWithFormat:@"主负\n%@", model.sfArr[0]];
                    [self lableState:contentLBl isSelect:[model.sfStateArr[0] isEqual:@1]];
                } else {
                    contentLBl.text = [NSString stringWithFormat:@"主胜\n%@", model.sfArr[1]];
                    [self lableState:contentLBl isSelect:[model.sfStateArr[1] isEqual:@1]];
                }
                
            }
            //让胜
            if (i == 1) {
                if (j == 1) {
                    contentLBl.text = [NSString stringWithFormat:@"主负\n%@", model.rfArr[0]];
                    [self lableState:contentLBl isSelect:[model.rfStateArr[0] isEqual:@1]];
                } else {
                    contentLBl.text = [NSString stringWithFormat:@"主胜(%@)\n%@", [model.rf componentsSeparatedByString:@","][0], model.rfArr[1]];
                    [self lableState:contentLBl isSelect:[model.rfStateArr[1] isEqual:@1]];
                }
            }
            
            //大小分
            if (i == 2) {
                if (j == 1) {
                    contentLBl.text = [NSString stringWithFormat:@"大于%@分\n%@",[model.dxf componentsSeparatedByString:@","][0], model.rfArr[0]];
                    [self lableState:contentLBl isSelect:[model.dxfStateArr[0] isEqual:@1]];
                } else {
                    contentLBl.text = [NSString stringWithFormat:@"小于%@分\n%@", [model.dxf componentsSeparatedByString:@","][0], model.rfArr[1]];
                    [self lableState:contentLBl isSelect:[model.dxfStateArr[1] isEqual:@1]];
                }
            }
        }
    }
    
    
    //胜分差
    for (int i = 0; i < 4; i ++) {
        for (int j = 0; j < 3; j ++) {
            
            UILabel *typeLbl = [self viewWithTag:2000 + i * 3 + j];
            typeLbl.text = [NSString stringWithFormat:@"%@\n%@", _titleArr[i * 3 + j], model.sfcArr[i *3 +j]];
            [self lableState:typeLbl isSelect:[model.sfcStateArr[i * 3 + j] isEqual:@1]];
        }
    }
    
    [_currentmodel checkChooseCount];
}



//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {
    
    UILabel *currentLbl = (UILabel *)sender.view;
    BOOL isSelect = NO;
    if (currentLbl.tag > 200 && currentLbl.tag < 300) {
        _currentmodel.sfStateArr[currentLbl.tag - 201] = [_currentmodel.sfStateArr[currentLbl.tag - 201] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.sfStateArr[currentLbl.tag - 201] isEqual:@1];
    }
    
    if (currentLbl.tag > 300 && currentLbl.tag < 400) {
        _currentmodel.rfStateArr[currentLbl.tag - 301] = [_currentmodel.rfStateArr[currentLbl.tag - 301] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.rfStateArr[currentLbl.tag - 301] isEqual:@1];
    }
    
    if (currentLbl.tag > 400 && currentLbl.tag < 500) {
        _currentmodel.dxfStateArr[currentLbl.tag - 401] = [_currentmodel.dxfStateArr[currentLbl.tag - 401] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.dxfStateArr[currentLbl.tag - 401] isEqual:@1];
    }
    

    
    
    if (currentLbl.tag > 1999) {
        _currentmodel.sfcStateArr[currentLbl.tag - 2000] = [_currentmodel.sfcStateArr[currentLbl.tag - 2000] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.sfcStateArr[currentLbl.tag - 2000] isEqual:@1];
    }
    
    [self lableState:currentLbl isSelect:isSelect];
    
    [_currentmodel checkChooseCount];
    self.dataDidChanged();
}


// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
