//
//  YFBasketballSFCell.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/24.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YFJCLQModel;

@interface YFBasketballSFCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;

- (void)setValueWith:(YFJCLQModel *)model;

@property (nonatomic, copy) void(^dataDidChanged)(void);
@end
