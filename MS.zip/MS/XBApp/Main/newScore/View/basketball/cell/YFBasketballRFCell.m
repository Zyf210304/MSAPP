//
//  YFBasketballRFCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/24.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFBasketballRFCell.h"
#import "YFJCLQModel.h"

@interface YFBasketballRFCell()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) YFJCLQModel *currentmodel;

@property (nonatomic, strong) UILabel *titleLbl;

@property (nonatomic, strong) UILabel *numberLbl;

@property (nonatomic, strong) UILabel *leftLbl;

@property (nonatomic, strong) UILabel *rightLbl;
@end

@implementation YFBasketballRFCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}



+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFBasketballRFCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFBasketballRFCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        [cell initUI];
    }
    return cell;
}


- (void)initUI  {
    
    UILabel *contentLbl = [[UILabel alloc] init];
    [self addSubview:contentLbl];
    self.contentLbl = contentLbl;
    contentLbl.textColor = Color_title_666;
    contentLbl.textAlignment = NSTextAlignmentCenter;
    contentLbl.numberOfLines = 0;
    contentLbl.text = @"001\n\n国际赛\n\n17:40截止";
    contentLbl.font = [UIFont systemFontOfSize:11];
    [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(0);
        make.top.bottom.mas_offset(0);
        make.width.mas_offset(61 *SCALE_375);
    }];
    [self addCenterView];
}




- (void)addCenterView{
    UILabel *titleLbl = [[UILabel  alloc] init];
    [self addSubview:titleLbl];
    _titleLbl = titleLbl;
    titleLbl.text = @"甲方 VS 乙方";
    titleLbl.textColor = Color_title_333;
    titleLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [titleLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(0);
        make.centerX.equalTo(self.mas_centerX);
        make.height.mas_offset(40 *SCALE_375);
    }];
    
    UILabel *numberLbl = [[UILabel alloc] init];
    [self addSubview:numberLbl];
    _numberLbl = numberLbl;
    numberLbl.text = @"12.50";
    numberLbl.textColor = UIColorFromRGB(0x2B8E35);
    numberLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [numberLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-14 *SCALE_375);
        make.centerY.equalTo(titleLbl.mas_centerY);
    }];
    
    
    UILabel *leftLbl = [[UILabel alloc] init];
    [self addSubview:leftLbl];
    _leftLbl = leftLbl;
    leftLbl.tag = 200;
    leftLbl.textAlignment = NSTextAlignmentCenter;
    leftLbl.textColor = Color_title_333;
    leftLbl.backgroundColor = [UIColor whiteColor];
    leftLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [leftLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(67 *SCALE_375);
        make.top.mas_offset(45 *SCALE_375);
        make.width.mas_offset(148 *SCALE_375);
        make.height.mas_offset(40 *SCALE_375);
    }];
    
    
    UILabel *rightLbl = [[UILabel alloc] init];
    [self addSubview:rightLbl];
    _rightLbl = rightLbl;
    rightLbl.tag = 201;
    rightLbl.textColor = Color_title_333;
    rightLbl.textAlignment = NSTextAlignmentCenter;
    rightLbl.backgroundColor = [UIColor whiteColor];
    rightLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [rightLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(218 *SCALE_375);
        make.top.mas_offset(45 *SCALE_375);
        make.width.mas_offset(148 *SCALE_375);
        make.height.mas_offset(40 *SCALE_375);
    }];
    
    [leftLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
    [rightLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
}

- (void)setValueWith:(YFJCLQModel *)model {
    
    self.currentmodel = model;
    NSString *time = [NSString getmatichTime:model.matchtime.integerValue];
    _contentLbl.text = [NSString stringWithFormat:@"%@\n%@\n%@截止", model.event,  [model.issue_num  substringFromIndex:1], time];
    
    _titleLbl.text = [NSString stringWithFormat:@"%@ %@", model.home, model.away];
    
    
    
    if (model.isRF) {
        _numberLbl.text =[model.rf componentsSeparatedByString:@","][0];
        _leftLbl.text = [NSString stringWithFormat:@"主负%@", model.rfArr[0]];
        [self lableState:_leftLbl isSelect:[model.rfStateArr[0] isEqual:@1]];
        _rightLbl.text = [NSString stringWithFormat:@"主胜%@", model.rfArr[1]];
        [self lableState:_rightLbl isSelect:[model.rfStateArr[1] isEqual:@1]];
    } else {
        _numberLbl.text =[model.dxf componentsSeparatedByString:@","][0];
        _leftLbl.text = [NSString stringWithFormat:@"大分%@", model.dxfArr[0]];
        [self lableState:_leftLbl isSelect:[model.dxfStateArr[0] isEqual:@1]];
        _rightLbl.text = [NSString stringWithFormat:@"小分%@", model.dxfArr[1]];
        [self lableState:_rightLbl isSelect:[model.dxfStateArr[0] isEqual:@1]];
    }
     [_currentmodel checkChooseCount];
    
}




//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {
    
    
    UILabel *currentLbl = (UILabel *)sender.view;
    BOOL isSelect = NO;
    
    if (_currentmodel.isRF) {
        _currentmodel.rfStateArr[currentLbl.tag - 200] = [_currentmodel.rfStateArr[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.rfStateArr[currentLbl.tag - 200] isEqual:@1];
    } else {
        _currentmodel.dxfStateArr[currentLbl.tag - 200] = [_currentmodel.dxfStateArr[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.dxfStateArr[currentLbl.tag - 200] isEqual:@1];
    }
    
    
    [self lableState:currentLbl isSelect:isSelect];
    
     [_currentmodel checkChooseCount];
    self.dataDidChanged();
}



// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
