//
//  YFScore_bottomView.h
//  XBApp
//
//  Created by 张亚飞 on 2018/9/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFScore_bottomView : UIView

@property (nonatomic, copy) void(^leftBlock)(void);

@property (nonatomic, copy) void(^rightBlock)(void);

- (void)changeStateWith:(NSInteger)count addIsCanDG:(BOOL)isCanDG;

- (void)changeStateWithStack:(NSInteger)stacks addMult:(NSInteger )mutiNum;

- (void)changeStateAboutDanStack:(NSInteger)stacks addMult:(NSInteger )mutiNum minBouns:(CGFloat)minBouns maxBouns:(CGFloat)maxBouns;

- (void)changeStateWithStack:(NSInteger)stacks addMult:(NSInteger )mutiNum minBouns:(CGFloat)minBouns maxBouns:(CGFloat)maxBouns;


- (void)setIsSendUI;

@end
