//
//  YFScrore_Nav.m
//  XBApp
//
//  Created by 张亚飞 on 2018/9/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScrore_Nav.h"

@implementation YFScrore_Nav


- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
        self.backgroundColor = [UIColor colorWithRed:252/255.0 green:43/ 255.0 blue:53/ 255.0 alpha:1];
    }
    return self;
}


- (void)initUI {
    
    UIView *bottomView = [[UIView alloc] init];
    [self addSubview:bottomView];
    [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.mas_equalTo(0);
        make.height.mas_equalTo(44);
    }];
    
    [self addbackArrows:bottomView];
    [self addCenterTypeView:bottomView];
    
    UIImageView *chooseImg = [[UIImageView alloc] init];
    [bottomView addSubview:chooseImg];
    chooseImg.image = [UIImage imageNamed:@"screen"];
    [chooseImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-10 *SCALE_375);
        make.width.height.mas_offset(20 *SCALE_375);
        make.centerY.equalTo(bottomView.mas_centerY);
    }];
    [chooseImg addTapGesture:^{
        self.screenShow();
    }];
}

- (void)addbackArrows:(UIView *)bottomView {
    UIImageView *backImg = [[UIImageView alloc] init];
    [bottomView addSubview:backImg];
    backImg.image = [UIImage imageNamed:@"back_white"];
    [backImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(13 *SCALE_375);
        make.width.height.mas_equalTo(20 *SCALE_375);
        make.centerY.equalTo(bottomView.mas_centerY);
    }];
    [backImg addTapgestureWithTarget:self action:@selector(goBackAction:)];
}

- (void)goBackAction:(UITapGestureRecognizer *)sender {
    self.goBack();
}


- (void)addCenterTypeView:(UIView *)bottomView {
    
    UIView *centerView = [[UIView alloc] init];
    [bottomView addSubview:centerView];
    [centerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.mas_offset(0);
        make.width.mas_equalTo(FRAME_WIDTH / 3);
        make.centerX.equalTo(self.mas_centerX);
    }];
    
    self.typeLbl = [[UILabel alloc] init];
    [centerView addSubview:_typeLbl];
    _typeLbl.text = @"混合过关";
    _typeLbl.textColor = [UIColor whiteColor];
    [_typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(centerView.mas_centerX).offset(- 10 *SCALE_375);
        make.centerY.equalTo(centerView.mas_centerY);
    }];
    
    UIImageView *ArrowsImg = [[UIImageView alloc] init];
    [centerView addSubview:ArrowsImg];
    ArrowsImg.image = [UIImage imageNamed:@"down_arrows"];
    [ArrowsImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_typeLbl.mas_right).offset(5 *SCALE_375);
        make.centerY.equalTo(centerView.mas_centerY);
        make.width.mas_offset(12 *SCALE_375);
        make.height.mas_offset(12 *SCALE_375);
    }];
    
    [centerView addTapGesture:^{
        self.changeType();
    }];
    
    
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
