//
//  YFScrore_Nav.h
//  XBApp
//
//  Created by 张亚飞 on 2018/9/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFScrore_Nav : UIView

@property (nonatomic, copy) void(^goBack)(void);

@property (nonatomic, copy) void(^changeType)(void);

@property (nonatomic, copy) void(^screenShow)(void);

@property (nonatomic, strong) UILabel *typeLbl;

@end
