//
//  YFScoreMore_Bottom.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScoreMore_Bottom.h"

@implementation YFScoreMore_Bottom


- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
    
}


- (void)initUI {
    
    UILabel *leftLbl = [[UILabel alloc] init];
    [self addSubview:leftLbl];
    leftLbl.text = @"取消";
    leftLbl.textAlignment = NSTextAlignmentCenter;
    leftLbl.textColor = Color_title_333;
    leftLbl.layer.masksToBounds = YES;
    leftLbl.layer.borderWidth = SCALE_375;
    leftLbl.layer.borderColor = Color_Base_BG.CGColor;
    leftLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [leftLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.mas_offset(0);
        make.width.mas_offset(FRAME_WIDTH / 2);
        make.height.mas_offset(44 *SCALE_375);
    }];
    [self addTapgestureWithTarget:self action:@selector(goBackAction:)];

    
    UILabel *rightLbl = [[UILabel alloc] init];
    [self addSubview:rightLbl];
    rightLbl.text = @"确定";
    rightLbl.layer.masksToBounds = YES;
    rightLbl.textAlignment = NSTextAlignmentCenter;
    rightLbl.textColor = [UIColor redColor];
    rightLbl.layer.masksToBounds = YES;
    rightLbl.layer.borderWidth = SCALE_375;
    rightLbl.layer.borderColor = Color_Base_BG.CGColor;
    rightLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [rightLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.mas_offset(0);
        make.width.mas_offset(FRAME_WIDTH / 2);
        make.height.mas_offset(44 *SCALE_375);
    }];
    
}


- (void)goBackAction:(UITapGestureRecognizer *)sender {
    [[YFCurrentVC getCurrentVC].navigationController popViewControllerAnimated:YES];
}

- (void)saveData:(UITapGestureRecognizer *)sender {
     [[YFCurrentVC getCurrentVC].navigationController popViewControllerAnimated:YES];
}































/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/




@end
