//
//  YFScoreMore_Bottom.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFScoreMore_Bottom : UIView

@property (nonatomic, copy) void(^changeDataBlock)(void);

@end
