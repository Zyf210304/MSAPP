//
//  YFScore_SectionHeader.h
//  XBApp
//
//  Created by 张亚飞 on 2018/9/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFScore_SectionHeader : UIView

@property (nonatomic, strong) NSString *titleStr;

@end
