//
//  YFScore_SectionHeader.m
//  XBApp
//
//  Created by 张亚飞 on 2018/9/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScore_SectionHeader.h"

@implementation YFScore_SectionHeader

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)initUI  {
    
    UIView *lineView = [[UIView alloc] init];
    [self addSubview:lineView];
    lineView.backgroundColor = [UIColor redColor];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(8 *SCALE_375);
        make.width.mas_offset(2 *SCALE_375);
        make.top.mas_offset(4 *SCALE_375);
        make.bottom.mas_offset(-4 *SCALE_375);
    }];
    
    UILabel *titleLbl = [[UILabel alloc] init];
    [self addSubview:titleLbl];
    titleLbl.text = @"2000-09-30 星期日 63场比赛";
    titleLbl.tag = 200;
    titleLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [titleLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(lineView.mas_right).offset(8 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    
    UIImageView *rowImg = [[UIImageView alloc] init];
    [self addSubview:rowImg];
    rowImg.image =  [UIImage imageNamed: @"icon-arrows-"];
    [rowImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_offset(6 *SCALE_375);
        make.height.mas_offset(12 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
        make.right.mas_offset(- 12 *SCALE_375);
    }];
}

- (void)setTitleStr:(NSString *)titleStr {
    UILabel *titleLbl = [self viewWithTag:200];
    titleLbl.text = titleStr;
    _titleStr = titleStr;
}





/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
