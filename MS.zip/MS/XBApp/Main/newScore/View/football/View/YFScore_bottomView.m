//
//  YFScore_bottomView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/9/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScore_bottomView.h"

@interface YFScore_bottomView()

@property (nonatomic, strong) UILabel *leftLbl;

@property (nonatomic, strong) UILabel *rightLbl;

@property (nonatomic, strong) UILabel *bottomLbl;
@end

@implementation YFScore_bottomView




- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)initUI {
    UILabel *consultLbl = [[UILabel alloc] init];
    [self addSubview:consultLbl];
    _leftLbl = consultLbl;
    consultLbl.text = @"清空";
    consultLbl.layer.cornerRadius = 4 *SCALE_375;
    consultLbl.layer.masksToBounds = YES;
    consultLbl.layer.borderWidth = 1;
    consultLbl.layer.borderColor = [UIColor lightGrayColor].CGColor;
    consultLbl.textAlignment = NSTextAlignmentCenter;
    consultLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    consultLbl.textColor = UIColorFromRGB(0xA94148);
    [consultLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(15 *SCALE_375);
        make.top.mas_offset(8 *SCALE_375);
        make.width.mas_offset(64 *SCALE_375);
        make.height.mas_offset(37 *SCALE_375);
    }];
    [consultLbl addTapgestureWithTarget:self action:@selector(leftAction:)];
    
    UILabel *applyPayLbl = [[UILabel alloc] init];
    [self addSubview:applyPayLbl];
    _rightLbl = applyPayLbl;
    applyPayLbl.text = @"确定";
    applyPayLbl.layer.cornerRadius = 4 *SCALE_375;
    applyPayLbl.layer.masksToBounds = YES;
    applyPayLbl.textAlignment = NSTextAlignmentCenter;
    applyPayLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    applyPayLbl.textColor = [UIColor whiteColor];
    applyPayLbl.backgroundColor = UIColorFromRGB(0xE14133);
    [applyPayLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-15 *SCALE_375);
        make.top.mas_offset(8 *SCALE_375);
        make.width.mas_offset(64 *SCALE_375);
        make.height.mas_offset(37 *SCALE_375);
    }];
    [applyPayLbl addTapgestureWithTarget:self action:@selector(rightAction:)];
    
    
    [self addCenterLbl];
}

- (void)leftAction:(UITapGestureRecognizer *)sender {
    self.leftBlock();
}

- (void)rightAction:(UITapGestureRecognizer *)sender {
    self.rightBlock();
}


- (void)addCenterLbl {
    UILabel *topLbl = [[UILabel alloc] init];
    [self addSubview:topLbl];
    topLbl.text = @"请选择比赛";
    topLbl.tag = 200;
    topLbl.textColor = Color_title_666;
    topLbl.font = [UIFont systemFontOfSize:11 *SCALE_375];
    [topLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(10 *SCALE_375);
        make.centerX.equalTo(self.mas_centerX);
    }];
    
    
    UILabel *bottomLbl = [[UILabel alloc] init];
    [self addSubview:bottomLbl];
    bottomLbl.text = @"[页面赔率仅供参考,请以实体票为准]";
    _bottomLbl = bottomLbl;
    bottomLbl.textColor = Color_title_666;
    bottomLbl.font = [UIFont systemFontOfSize:11 *SCALE_375];
    [bottomLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(33 *SCALE_375);
        make.centerX.equalTo(self.mas_centerX);
    }];
}

- (void)setIsSendUI {
    _leftLbl.text = @"返回";
    _rightLbl.text = @"下单";
}


- (void)changeStateWith:(NSInteger)count addIsCanDG:(BOOL)isCanDG{
    UILabel *statisticsLbl = [self viewWithTag:200];
    if (count == 0) {
        statisticsLbl.text = @"请选择比赛";
    }
    if (count == 1) {
        statisticsLbl.text = @"已选一场,还差一场";
    }
    if (count > 1) {
        statisticsLbl.text = [NSString stringWithFormat:@"已选%zd场", count];
    }
    if (isCanDG && count > 0) {
        statisticsLbl.text = [NSString stringWithFormat:@"已选%zd场", count];
    }
}

- (void)changeStateWithStack:(NSInteger)stacks addMult:(NSInteger)mutiNum {
    UILabel *statisticsLbl = [self viewWithTag:200];
    statisticsLbl.text = [NSString stringWithFormat:@"%zd注 %zd倍 共%zd元", stacks, mutiNum, stacks * mutiNum *2];
    [statisticsLbl changeStringArr:@[@(stacks).stringValue, @(mutiNum).stringValue, [NSString stringWithFormat:@"%zd", mutiNum * stacks * 2]] andAllColor:Color_title_666 andMarkColor:[UIColor redColor] andMarkFondSize:12 *SCALE_375];
}

- (void)changeStateAboutDanStack:(NSInteger)stacks addMult:(NSInteger)mutiNum minBouns:(CGFloat)minBouns maxBouns:(CGFloat)maxBouns{
    UILabel *statisticsLbl = [self viewWithTag:200];
    statisticsLbl.text = [NSString stringWithFormat:@"%zd注 %zd倍 共%zd元", stacks, mutiNum, stacks * mutiNum *2];
    [statisticsLbl changeStringArr:@[@"注", @"倍", @"共", @"元"] andAllColor:[UIColor redColor] andMarkColor:Color_title_666 andMarkFondSize:10 *SCALE_375];
    
    _bottomLbl.text = [NSString stringWithFormat:@"奖金范围:%.2lf~%.2lf", minBouns * 2 * mutiNum, maxBouns* 2 * mutiNum];
    [_bottomLbl changeStringArr:@[@"奖金范围:",@"~"] andAllColor:[UIColor redColor] andMarkColor:Color_title_666 andMarkFondSize:10 *SCALE_375];
    
}

- (void)changeStateWithStack:(NSInteger)stacks addMult:(NSInteger)mutiNum minBouns:(CGFloat)minBouns maxBouns:(CGFloat)maxBouns {
    UILabel *statisticsLbl = [self viewWithTag:200];
    statisticsLbl.text = [NSString stringWithFormat:@"%zd注 %zd倍 共%zd元", stacks, mutiNum, stacks * mutiNum *2];
    [statisticsLbl changeStringArr:@[@"注", @"倍", @"共", @"元"] andAllColor:[UIColor redColor] andMarkColor:Color_title_666 andMarkFondSize:10 *SCALE_375];
    
    minBouns = minBouns * 2 * mutiNum;
    maxBouns = maxBouns * 2 * mutiNum > 5000000 ?  5000000:maxBouns * 2 * mutiNum ;

    _bottomLbl.text = [NSString stringWithFormat:@"奖金范围:%.2lf~%.2lf",minBouns, maxBouns];
    [_bottomLbl changeStringArr:@[@"奖金范围:",@"~"] andAllColor:[UIColor redColor] andMarkColor:Color_title_666 andMarkFondSize:10 *SCALE_375];
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
