//
//  YFScore_moreCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScore_moreCell.h"
#import "YFJCZQ_model.h"

@interface YFScore_moreCell()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) NSArray *spfTitle;

@property (nonatomic, strong) YFJCZQ_model *currentmodel;

@property (nonatomic, strong) NSArray *ScoreArr;
@property (nonatomic, strong) NSArray *resultArr;
@property (nonatomic, strong) NSArray *ballNumber;

@end

@implementation YFScore_moreCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


+ (instancetype)cellWithTableView:(UITableView *)tableView addType:(LotteryType)type{
    YFScore_moreCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFScore_moreCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        [cell initUIWith:type];
    }
    return cell;
}


- (void)initUIWith:(LotteryType)type {
    
    self.ScoreArr = @[@"1:0", @"2:0", @"2:1", @"3:0", @"3:1",
                      @"3:2", @"4:0", @"4:1", @"4:2", @"5:0",
                      @"5:1", @"5:2", @"胜其他",
                      @"0:0", @"1:1", @"2:2", @"3:3", @"平其他",
                      @"0:1", @"0:2", @"1:2", @"0:3:0", @"1:3",
                      @"2:3", @"0:4", @"1:4", @"2:4", @"0:5",
                      @"1:5", @"2:5", @"负其他"];
    
    self.resultArr = @[@"胜胜", @"胜平", @"胜负",
                       @"平胜", @"平平", @"平负",
                       @"负胜", @"负平", @"负负"];
    
    self.ballNumber = @[@"0球", @"1球", @"2球", @"3球",
                        @"4球", @"5球", @"6球", @"7+球"];
    
    self.spfTitle = @[@"胜", @"平", @"负"];
    
    switch (type) {
        case Lottery_Result:
            [self setResultUI];
            break;
        case Lottery_Score:
            [self setScoreUI];
            break;
        case Lottery_BallNumer:
            [self setBallNumerUI];
            break;
        case Lottery_DoubleResult:
            [self setDoubleResultUI];
            break;
        default:
            break;
    }

}

//胜平负
- (void)setResultUI {
    
    CGFloat typeWidth = (FRAME_WIDTH - 52 *SCALE_375) / 3;
    for (int i = 0; i < 2; i ++) {
        UILabel *offsetLbl = [[UILabel alloc] init];
        [self addSubview:offsetLbl];
        offsetLbl.textAlignment = NSTextAlignmentCenter;
        offsetLbl.text = @"0";
        offsetLbl.tag = 2000 *(i + 1);
        offsetLbl.backgroundColor = Color_Main;
        offsetLbl.font = [UIFont systemFontOfSize:13];
        offsetLbl.textColor = Color_title_333;
         
        [offsetLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(15 *SCALE_375);
            make.width.mas_offset(20 *SCALE_375);
            make.height.mas_offset(40 *SCALE_375);
            make.top.mas_offset(10 + 41 *SCALE_375 * i);
        }];
        
        for (int j = 0; j < 3 ; j ++) {
            
            UILabel *typeLbl = [[UILabel alloc] init];
            [self addSubview:typeLbl];
            typeLbl.textColor = Color_title_333;
            typeLbl.tag = 200 * (i + 1) + j + 1;
            typeLbl.textAlignment = NSTextAlignmentCenter;
            typeLbl.text = @"胜1.83";
            typeLbl.font = [UIFont systemFontOfSize:13];
            typeLbl.backgroundColor = [UIColor whiteColor];
            
            [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(35 *SCALE_375 + (typeWidth + SCALE_375 )* j);
                make.width.mas_offset(typeWidth);
                make.height.mas_offset(40 *SCALE_375);
                make.top.mas_offset(10 + 41 *SCALE_375 * i);
            }];
            
            [typeLbl addTapgestureWithTarget:self action:@selector(spfDidSelect:)];
        }
        
        UILabel *notOpen = [[UILabel alloc] init];
        [self addSubview:notOpen];
        notOpen.textColor = Color_title_333;
        notOpen.backgroundColor = [UIColor whiteColor];
        notOpen.textAlignment = NSTextAlignmentCenter;
        notOpen.text = @"未开放";
        notOpen.tag = 700 + i;
        notOpen.font = [UIFont systemFontOfSize:13 *SCALE_375];
        [notOpen mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(35 *SCALE_375);
            make.top.mas_offset(10 + 41 *SCALE_375 * i);
            make.right.mas_offset(- 15 *SCALE_375);
            make.height.mas_offset(40 *SCALE_375);
        }];
        notOpen.hidden = YES;
        
        
        
    }
    
    
    
}

- (void)setScoreUI {
    //top
    [self addScoreUIAboutTopAndBottom:YES];
    //center
    [self addScoreUIAboutCenter];
    //bottom
    [self addScoreUIAboutTopAndBottom:NO];
}

- (void)addScoreUIAboutTopAndBottom:(BOOL)istop {
    
    CGFloat top = istop ? 10 *SCALE_375 : 174 *SCALE_375;
    
    UILabel *offsetLbl = [[UILabel alloc] init];
    [self addSubview:offsetLbl];
    offsetLbl.backgroundColor = Color_Main;
    offsetLbl.textAlignment = NSTextAlignmentCenter;
    offsetLbl.text = istop ? @"胜" : @"负";
    offsetLbl.textColor = Color_title_333;
    offsetLbl.font = [UIFont systemFontOfSize:13];
    offsetLbl.backgroundColor = istop ? JKRGBColor(249, 220, 226) : JKRGBColor(226, 242, 177);
    [offsetLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(15 *SCALE_375);
        make.width.mas_offset(20 *SCALE_375);
        make.height.mas_offset(122 *SCALE_375);
        make.top.mas_offset(top);
    }];
    
    int start = istop ? 0 : 18;
    CGFloat typeWidth = (FRAME_WIDTH - 54 *SCALE_375) / 5;
    
    for (int i = 0; i < 3; i ++) {
        for (int j = 0; j < 5 ; j ++) {
            
            if (i == 2 && j > 2) {
                break;
            }
            
            UILabel *typeLbl = [[UILabel alloc] init];
            [self addSubview:typeLbl];
            typeLbl.textColor = Color_title_333;
            typeLbl.textAlignment = NSTextAlignmentCenter;
            typeLbl.numberOfLines = 2;
            typeLbl.tag = 200 + i * 5 + j + start;
            typeLbl.text = [NSString stringWithFormat:@"%@\n1.50", _ScoreArr[i * 5 + j + start]];
            typeLbl.font = [UIFont systemFontOfSize:13];
            typeLbl.backgroundColor = [UIColor whiteColor];
            [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(35 *SCALE_375 + (typeWidth + SCALE_375 )* j);
                make.height.mas_offset(40 *SCALE_375);
                make.top.mas_offset(top + 41 *SCALE_375 * i);
                
                if (i == 2 && j == 2) {
                    make.width.mas_offset(typeWidth * 3 + 2 *SCALE_375);
                } else {
                    make.width.mas_offset(typeWidth);
                }
                
            }];
            [typeLbl addTapgestureWithTarget:self action:@selector(bfDidSelect:)];
        }
    }
}

- (void)addScoreUIAboutCenter {
    
    CGFloat top = 133 *SCALE_375;
    
    UILabel *offsetLbl = [[UILabel alloc] init];
    [self addSubview:offsetLbl];
    offsetLbl.textAlignment = NSTextAlignmentCenter;
    offsetLbl.text = @"平";
    offsetLbl.backgroundColor = Color_Main;
    offsetLbl.textColor = Color_title_333;
    offsetLbl.font = [UIFont systemFontOfSize:13];
    offsetLbl.backgroundColor = JKRGBColor(204, 229, 253);
    [offsetLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(15 *SCALE_375);
        make.width.mas_offset(20 *SCALE_375);
        make.height.mas_offset(40 *SCALE_375);
        make.top.mas_offset(top);
    }];

    CGFloat typeWidth = (FRAME_WIDTH - 54 *SCALE_375) / 5;
    for (int i = 0; i < 5; i ++) {
            
        UILabel *typeLbl = [[UILabel alloc] init];
        [self addSubview:typeLbl];
        typeLbl.textColor = Color_title_333;
        typeLbl.textAlignment = NSTextAlignmentCenter;
        typeLbl.numberOfLines = 2;
        typeLbl.tag = i + 13 + 200;
        typeLbl.text = [NSString stringWithFormat:@"%@\n1.40", _ScoreArr[i + 13]];
        typeLbl.font = [UIFont systemFontOfSize:13];
        typeLbl.backgroundColor = [UIColor whiteColor];
        [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(35 *SCALE_375 + (typeWidth + SCALE_375 )* i);
            make.width.mas_offset(typeWidth);
            make.height.mas_offset(40 *SCALE_375);
            make.top.mas_offset(top);
        }];
        
        [typeLbl addTapgestureWithTarget:self action:@selector(bfDidSelect:)];
    }
}


- (void)setBallNumerUI {
    
    UILabel *offsetLbl = [[UILabel alloc] init];
    [self addSubview:offsetLbl];
    offsetLbl.textAlignment = NSTextAlignmentCenter;
    offsetLbl.text = @"总进球";
    offsetLbl.numberOfLines = 0;
    offsetLbl.backgroundColor = Color_Main;
    offsetLbl.textColor = Color_title_333;
    offsetLbl.font = [UIFont systemFontOfSize:13];
    offsetLbl.backgroundColor = JKRGBColor(227, 237, 140);
    [offsetLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(15 *SCALE_375);
        make.width.mas_offset(20 *SCALE_375);
        make.height.mas_offset(81 *SCALE_375);
        make.top.mas_offset(10 *SCALE_375);
    }];
    
    NSArray *ballNumber = @[@"0球", @"1球", @"2球", @"3球",
                            @"4球", @"5球", @"6球", @"7+球"];
    CGFloat typeWidth = (FRAME_WIDTH - 53 *SCALE_375) / 4;
    for (int i = 0; i < 2; i ++) {
        for (int j = 0; j < 4 ; j ++) {
            
            UILabel *typeLbl = [[UILabel alloc] init];
            [self addSubview:typeLbl];
            typeLbl.textColor = Color_title_333;
            typeLbl.textAlignment = NSTextAlignmentCenter;
            typeLbl.numberOfLines = 2;
            typeLbl.tag = 200 + i *4 + j;
            typeLbl.text = [NSString stringWithFormat:@"%@\n3.44", ballNumber[i *4 + j]];
            typeLbl.font = [UIFont systemFontOfSize:13];
            typeLbl.backgroundColor = [UIColor whiteColor];
            [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(35 *SCALE_375 + (typeWidth + SCALE_375 )* j);
                make.width.mas_offset(typeWidth);
                make.height.mas_offset(40 *SCALE_375);
                make.top.mas_offset(10 + 41 *SCALE_375 * i);
            }];
            
            [typeLbl addTapgestureWithTarget:self action:@selector(zjqDidSelect:)];
        }
    }
    
}


- (void)setDoubleResultUI {
    UILabel *offsetLbl = [[UILabel alloc] init];
    [self addSubview:offsetLbl];
    offsetLbl.textAlignment = NSTextAlignmentCenter;
    offsetLbl.text = @"半全场";
    offsetLbl.numberOfLines = 0;
    offsetLbl.backgroundColor = Color_Main;
    offsetLbl.font = [UIFont systemFontOfSize:13];
    offsetLbl.textColor = Color_title_333;
    offsetLbl.backgroundColor = JKRGBColor(254, 228, 158);
    [offsetLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(15 *SCALE_375);
        make.width.mas_offset(20 *SCALE_375);
        make.height.mas_offset(122 *SCALE_375);
        make.top.mas_offset(10 *SCALE_375);
    }];

    CGFloat typeWidth = (FRAME_WIDTH - 52 *SCALE_375) / 3;
    for (int i = 0; i < 3; i ++) {
        for (int j = 0; j < 3 ; j ++) {
            
            UILabel *typeLbl = [[UILabel alloc] init];
            [self addSubview:typeLbl];
            typeLbl.textColor = Color_title_333;
            typeLbl.textAlignment = NSTextAlignmentCenter;
            typeLbl.numberOfLines = 2;
            typeLbl.tag = 200 + i * 3 + j;
            typeLbl.text = [NSString stringWithFormat:@"%@\n11.00", _resultArr[i *3 +j]];
            typeLbl.font = [UIFont systemFontOfSize:13];
            typeLbl.backgroundColor = [UIColor whiteColor];
            [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(35 *SCALE_375 + (typeWidth + SCALE_375 )* j);
                make.width.mas_offset(typeWidth);
                make.height.mas_offset(40 *SCALE_375);
                make.top.mas_offset(10 + 41 *SCALE_375 * i);
            }];
            
            [typeLbl addTapgestureWithTarget:self action:@selector(bqcDidSelect:)];
        }
    }
}


- (void)setValueWith:(YFJCZQ_model *)model addType:(LotteryType)type {
    self.currentmodel = model;
    switch (type) {
        case Lottery_Result:
            [self setResultValue];
            break;
        case Lottery_Score:
            [self setScoreValue];
            break;
        case Lottery_BallNumer:
            [self setBallNumberValue];
            break;
        case Lottery_DoubleResult:
            [self setDoubleResultValue];
            break;
        default:
            break;
    }
}


#pragma mark -----  赋值
- (void)setResultValue {
    NSArray *spfArr = [_currentmodel.spf componentsSeparatedByString:@","];
    NSArray *rqArr = [_currentmodel.rq componentsSeparatedByString:@","];
    

    
    //胜平负
    for (int i = 0; i < 3; i++) {
        UILabel *contentlbl = [self viewWithTag:201 + i];
        contentlbl.text = [NSString stringWithFormat:@"%@%@", _spfTitle[i], spfArr[i]];
        BOOL isSelet = [_currentmodel.spfState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
    
    //让球
    for (int i = 0; i < 3; i++) {
        UILabel *contentlbl = [self viewWithTag:401 + i];
        contentlbl.text = [NSString stringWithFormat:@"%@%@", _spfTitle[i], rqArr[i + 1]];
        BOOL isSelet = [_currentmodel.rqState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
    
    for (int i = 0; i < 2; i ++) {
        UILabel *notOpen = [self viewWithTag:700 +i];
        notOpen.hidden = !_currentmodel.isDG;
    }
    
    //左侧   添加颜色
    UILabel *spfLbl = [self viewWithTag:2000];
    spfLbl.backgroundColor = JKRGBColor(204, 229, 253);
    UILabel *rqLbl = [self viewWithTag:4000];
    NSString *rqStr = rqArr[0];
    if (rqStr.integerValue > 0) {
        rqLbl.backgroundColor = JKRGBColor(249, 220, 226);
        rqLbl.text = [@"+" stringByAppendingString:rqStr];
    } else {
        rqLbl.backgroundColor = JKRGBColor(226, 242, 177);
        rqLbl.text = rqStr;
    }
 
    
}

- (void)setScoreValue {
    NSArray *bfArr = [_currentmodel.bf componentsSeparatedByString:@","];
    
    //胜平负
    for (int i = 0; i < 31 ; i++) {
        UILabel *contentlbl = [self viewWithTag:200 + i];
        contentlbl.text = [NSString stringWithFormat:@"%@\n%@", _ScoreArr[i], bfArr[i]];
        BOOL isSelet = [_currentmodel.bfState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
    
}

- (void)setBallNumberValue {
    NSArray *jqArr = [_currentmodel.jq componentsSeparatedByString:@","];
    
    
    //进球
    for (int i = 0; i < 8 ; i++) {
        UILabel *contentlbl = [self viewWithTag:200 + i];
        contentlbl.text = [NSString stringWithFormat:@"%@\n%@", _ballNumber[i], jqArr[i]];
        BOOL isSelet = [_currentmodel.jqState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
}

- (void)setDoubleResultValue {
    NSArray *bqcArr = [_currentmodel.bqc componentsSeparatedByString:@","];
    
    
    //半全场
    for (int i = 0; i < 9 ; i++) {
        UILabel *contentlbl = [self viewWithTag:200 + i];
        contentlbl.text = [NSString stringWithFormat:@"%@\n%@", _resultArr[i], bqcArr[i]];
        BOOL isSelet = [_currentmodel.bqcState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
}







#pragma mark  --- 被点击
//胜平负、让球
- (void)spfDidSelect:(UITapGestureRecognizer *)sender {
    UILabel *currentLbl = (UILabel *)sender.view;
    BOOL isSelect = NO;
    if (currentLbl.tag > 300) {
        _currentmodel.rqState[currentLbl.tag - 401] =  [_currentmodel.rqState[currentLbl.tag - 401] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.rqState[currentLbl.tag - 401] isEqual:@1];
    } else {
        _currentmodel.spfState[currentLbl.tag - 201] =  [_currentmodel.spfState[currentLbl.tag - 201] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.spfState[currentLbl.tag - 201] isEqual:@1];
    }
    [self lableState:currentLbl isSelect:isSelect];
    [_currentmodel checkChooseCount];
}


//比分
- (void)bfDidSelect:(UITapGestureRecognizer *)sender {
    UILabel *currentLbl = (UILabel *)sender.view;
    
    _currentmodel.bfState[currentLbl.tag - 200] =  [_currentmodel.bfState[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
    BOOL isSelect = [_currentmodel.bfState[currentLbl.tag - 200] isEqual:@1];
    
    [self lableState:currentLbl isSelect:isSelect];
     [_currentmodel checkChooseCount];
}

//总进球
- (void)zjqDidSelect:(UITapGestureRecognizer *)sender {
    UILabel *currentLbl = (UILabel *)sender.view;
    
    _currentmodel.jqState[currentLbl.tag - 200] =  [_currentmodel.jqState[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
    BOOL isSelect = [_currentmodel.jqState[currentLbl.tag - 200] isEqual:@1];
    
    [self lableState:currentLbl isSelect:isSelect];
     [_currentmodel checkChooseCount];
}

//半全场
- (void)bqcDidSelect:(UITapGestureRecognizer *)sender {
    UILabel *currentLbl = (UILabel *)sender.view;
    
    _currentmodel.bqcState[currentLbl.tag - 200] =  [_currentmodel.bqcState[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
    BOOL isSelect = [_currentmodel.bqcState[currentLbl.tag - 200] isEqual:@1];
    
    [self lableState:currentLbl isSelect:isSelect];
     [_currentmodel checkChooseCount];
   
}



// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



@end
