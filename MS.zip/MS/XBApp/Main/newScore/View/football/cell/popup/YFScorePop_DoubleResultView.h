//
//  YFScorePop_DoubleResultView.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YFJCZQ_model;

@interface YFScorePop_DoubleResultView : UIView

- (void)setValueWithModel:(YFJCZQ_model *)model;

@property (nonatomic, copy) void(^trueBlock)(void);

@end
