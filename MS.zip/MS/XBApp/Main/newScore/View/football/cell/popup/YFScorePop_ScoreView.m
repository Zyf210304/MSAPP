//
//  YFScorePop_ScoreView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/9.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScorePop_ScoreView.h"
#import "YFJCZQ_model.h"

@interface YFScorePop_ScoreView()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) UILabel *matchtitle;

@property (nonatomic, strong) NSArray *ScoreArr;

@property (nonatomic, strong) YFJCZQ_model *currentmodel;

@end

@implementation YFScorePop_ScoreView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
        [self addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    }
    return self;
}

- (void)initUI {
    
    self.ScoreArr = @[@"1:0", @"2:0", @"2:1", @"3:0", @"3:1",
                        @"3:2", @"4:0", @"4:1", @"4:2", @"5:0",
                        @"5:1", @"5:2", @"胜其他",
                        @"0:0", @"1:1", @"2:2", @"3:3", @"平其他",
                        @"0:1", @"0:2", @"1:2", @"0:3:0", @"1:3",
                        @"2:3", @"0:4", @"1:4", @"2:4", @"0:5",
                        @"1:5", @"2:5", @"负其他"];
    
    UIView *centerView = [[UIView alloc] init];
    [self addSubview:centerView];
    centerView.backgroundColor = Color_Base_BG;
    centerView.layer.masksToBounds = YES;
    centerView.layer.cornerRadius = 3.0;
    [centerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_offset(FRAME_WIDTH - 30 *SCALE_375);
        make.height.mas_offset(382 *SCALE_375);
        make.centerX.equalTo(self.mas_centerX);
        make.centerY.equalTo(self.mas_centerY);
    }];
    [centerView addTapgestureWithTarget:self action:@selector(nothing:)];
    
    [self addMatchtitle:centerView];
    [self addBottmChooseLbl:centerView];
    [self addCenterChooseView:centerView];
}

- (void)addMatchtitle:(UIView *)centerView {
    UILabel *matchtitle = [[UILabel alloc] init];
    [centerView addSubview:matchtitle];
    matchtitle.textAlignment = NSTextAlignmentCenter;
    matchtitle.textColor = Color_title_333;
    matchtitle.text = @"甲方  VS  乙方";
    _matchtitle = matchtitle;
    matchtitle.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [matchtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(31 *SCALE_375);
    }];
    
}



- (void)addBottmChooseLbl:(UIView *)centerView  {
    
    UILabel *leftLbl = [[UILabel alloc] init];
    [centerView addSubview:leftLbl];
    leftLbl.textAlignment = NSTextAlignmentCenter;
    leftLbl.backgroundColor = [UIColor whiteColor];
    leftLbl.text = @"取消";
    leftLbl.textColor = Color_title_333;
    leftLbl.font = [UIFont systemFontOfSize:13];
    [leftLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.mas_offset(0);
        make.right.equalTo(centerView.mas_centerX).offset(-0.5);
        make.height.mas_offset(41 *SCALE_375);
    }];
    [leftLbl addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    
    UILabel *rightLbl = [[UILabel alloc] init];
    [centerView addSubview:rightLbl];
    rightLbl.textAlignment = NSTextAlignmentCenter;
    rightLbl.backgroundColor = [UIColor whiteColor];
    rightLbl.text = @"确定";
    rightLbl.textColor = UIColorFromRGB(0xA94148);
    rightLbl.font = [UIFont systemFontOfSize:13];
    [rightLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.mas_offset(0);
        make.left.equalTo(centerView.mas_centerX).offset(0.5);
        make.height.mas_offset(41 *SCALE_375);
    }];
    [rightLbl addTapgestureWithTarget:self action:@selector(trueAction:)];
}

- (void)addCenterChooseView:(UIView *)centerView  {
    
    //top
    [self addScoreUIAboutTopAndBottom:YES with:centerView];
    //center
    [self addScoreUIAboutCenterwith:centerView];
    //bottom
    [self addScoreUIAboutTopAndBottom:NO with:centerView];
    
}

- (void)addScoreUIAboutTopAndBottom:(BOOL)istop  with:(UIView *)centerView{
    
    CGFloat top = istop ? 37 *SCALE_375 : 201 *SCALE_375;
    
    UILabel *offsetLbl = [[UILabel alloc] init];
    [centerView addSubview:offsetLbl];
    offsetLbl.backgroundColor = Color_Main;
    offsetLbl.textAlignment = NSTextAlignmentCenter;
    offsetLbl.text = istop ? @"胜" : @"负";
    offsetLbl.textColor = Color_title_333;
    offsetLbl.font = [UIFont systemFontOfSize:13];
    offsetLbl.backgroundColor = istop ? JKRGBColor(249, 220, 226) : JKRGBColor(226, 242, 177);
    [offsetLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(10 *SCALE_375);
        make.width.mas_offset(20 *SCALE_375);
        make.height.mas_offset(122 *SCALE_375);
        make.top.mas_offset(top);
    }];
    

    CGFloat typeWidth = 60 *SCALE_375;
    int start = istop ? 0 : 18;

    for (int i = 0; i < 3; i ++) {
        for (int j = 0; j < 5 ; j ++) {
            
            if (i == 2 && j > 2) {
                break;
            }
            
            UILabel *typeLbl = [[UILabel alloc] init];
            [centerView addSubview:typeLbl];
            typeLbl.textColor = Color_title_333;
            typeLbl.textAlignment = NSTextAlignmentCenter;
            typeLbl.numberOfLines = 2;
            typeLbl.tag = 200 + i * 5 + j + start;
            typeLbl.text = [NSString stringWithFormat:@"%@\n1.50", _ScoreArr[i * 5 + j + start]];
            typeLbl.font = [UIFont systemFontOfSize:13];
            typeLbl.backgroundColor = [UIColor whiteColor];
            [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(30 *SCALE_375 + (typeWidth + SCALE_375 )* j);
                make.height.mas_offset(40 *SCALE_375);
                make.top.mas_offset(top + 41 *SCALE_375 * i);
                
                if (i == 2 && j == 2) {
                    make.width.mas_offset(typeWidth * 3 + 2 *SCALE_375);
                } else {
                    make.width.mas_offset(typeWidth);
                }
                
            }];
            
            [typeLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
        }
    }
}

- (void)addScoreUIAboutCenterwith:(UIView *)centerView {
    
    CGFloat top = 160 *SCALE_375;
    
    UILabel *offsetLbl = [[UILabel alloc] init];
    [centerView addSubview:offsetLbl];
    offsetLbl.textAlignment = NSTextAlignmentCenter;
    offsetLbl.text = @"平";
    offsetLbl.backgroundColor = Color_Main;
    offsetLbl.textColor = Color_title_333;
    offsetLbl.font = [UIFont systemFontOfSize:13];
    offsetLbl.backgroundColor = JKRGBColor(204, 229, 253);
    [offsetLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(10 *SCALE_375);
        make.width.mas_offset(20 *SCALE_375);
        make.height.mas_offset(40 *SCALE_375);
        make.top.mas_offset(top);
    }];

    CGFloat typeWidth = 60 *SCALE_375;
    for (int i = 0; i < 5; i ++) {
        UILabel *typeLbl = [[UILabel alloc] init];
        [centerView addSubview:typeLbl];
        typeLbl.textColor = Color_title_333;
        typeLbl.textAlignment = NSTextAlignmentCenter;
        typeLbl.numberOfLines = 2;
        typeLbl.text = [NSString stringWithFormat:@"%@\n1.40", _ScoreArr[i + 13]];
        typeLbl.tag = 200 + i + 13;
        typeLbl.font = [UIFont systemFontOfSize:13];
        typeLbl.backgroundColor = [UIColor whiteColor];
        [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(30 *SCALE_375 + (typeWidth + SCALE_375 )* i);
            make.width.mas_offset(typeWidth);
            make.height.mas_offset(40 *SCALE_375);
            make.top.mas_offset(top);
        }];
        [typeLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
    }
}


- (void)nothing:(UITapGestureRecognizer *)sender {
    NSLog(@"");
}

- (void)hiddenSelf:(UITapGestureRecognizer *)sender {
    self.hidden = YES;
}


- (void)setValueWithModel:(YFJCZQ_model *)model {
    self.currentmodel = model;
    
    NSArray *bfArr = [model.bf componentsSeparatedByString:@","];
    
    _matchtitle.text = [NSString stringWithFormat:@"%@ VS %@", model.home, model.away];
    
    //胜平负
    for (int i = 0; i < 31 ; i++) {
        UILabel *contentlbl = [self viewWithTag:200 + i];
        contentlbl.text = [NSString stringWithFormat:@"%@\n%@", _ScoreArr[i], bfArr[i]];
        BOOL isSelet = [model.bfState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
}


//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {
    
    UILabel *currentLbl = (UILabel *)sender.view;
    
    _currentmodel.bfState[currentLbl.tag - 200] =  [_currentmodel.bfState[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
    BOOL isSelect = [_currentmodel.bfState[currentLbl.tag - 200] isEqual:@1];
    
    [self lableState:currentLbl isSelect:isSelect];
    [_currentmodel checkChooseCount];
}
//
//- (void)checkChooseCount {
//    
//    NSInteger count = 0;
//    BOOL isMoreFour = NO;
//    
//    BOOL isCanDG = YES;
//    NSArray *sell_status = [_currentmodel.sell_status componentsSeparatedByString:@","];
//    
//    for (NSNumber *state in _currentmodel.spfState) {
//        if ([state isEqual:@1]) {
//            count ++;
//            if (![sell_status[0] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
//        }
//    }
//    
//    for (NSNumber *state in _currentmodel.rqState) {
//        if ([state isEqual:@1]) {
//            count ++;
//            if (![sell_status[1] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
//        }
//    }
//    
//    for (NSNumber *state in _currentmodel.bfState) {
//        if ([state isEqual:@1]) {
//            count ++;
//            isMoreFour = YES;
//            if (![sell_status[2] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
//        }
//    }
//    
//    for (NSNumber *state in _currentmodel.jqState) {
//        if ([state isEqual:@1]) {
//            count ++;
//            isMoreFour = YES;
//            if (![sell_status[3] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
//        }
//    }
//    
//    for (NSNumber *state in _currentmodel.bqcState) {
//        if ([state isEqual:@1]) {
//            count ++;
//            isMoreFour = YES;
//            if (![sell_status[4] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
//        }
//    }
//    
//    _currentmodel.isCanDG = isCanDG;
//    _currentmodel.chooseCount = count;
//    _currentmodel.isMoreFour = isMoreFour;
//    if (_currentmodel.chooseCount == 0) {
//        _currentmodel.isCanDG = YES;
//    }
//    
//}



// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
}


- (void)trueAction:(UITapGestureRecognizer *)sender {
    self.hidden = YES;
    self.trueBlock();
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
