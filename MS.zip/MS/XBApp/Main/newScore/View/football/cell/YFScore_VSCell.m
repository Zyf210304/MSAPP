//
//  YFScore_VSCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/9/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScore_VSCell.h"
#import "YFJCZQ_model.h"

@interface YFScore_VSCell()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) NSArray *spfTitle;

@property (nonatomic, strong) YFJCZQ_model *currentmodel;

@property (nonatomic, strong) UILabel *rqNumLbl;
@end

@implementation YFScore_VSCell

//cell 高 56 + 19 * 2
+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFScore_VSCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFScore_VSCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);

        [cell initUI];
    }
    return cell;
}




- (void)initUI {
    
    UILabel *rqNumLbl = [[UILabel alloc] init];
    [self addSubview:rqNumLbl];
    _rqNumLbl = rqNumLbl;
    rqNumLbl.textColor = [UIColor whiteColor];
    rqNumLbl.font = [UIFont systemFontOfSize:12 *SCALE_375];
    [rqNumLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(45 *SCALE_375);
        make.width.height.mas_offset(15 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    
    UILabel *contentLbl = [[UILabel alloc] init];
    [self addSubview:contentLbl];
    _contentLbl = contentLbl;
    contentLbl.textColor = Color_title_666;
    contentLbl.textAlignment = NSTextAlignmentCenter;
    contentLbl.numberOfLines = 0;
    contentLbl.text = @"001\n\n国际赛\n\n17:40截止";
    contentLbl.font = [UIFont systemFontOfSize:11];
    [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(0);
        make.top.bottom.mas_offset(0);
        make.width.mas_offset(61 *SCALE_375);
    }];
    
    
    for (int i = 0; i < 3; i++) {
        [self addScoreView:i];
    }
    
}

- (void)addScoreView:(NSInteger )count {
    
    NSArray *leftArr = @[@"67", @"181", @"256"];
    NSArray *widthArr = @[@"109", @"71", @"109"];
    
    UILabel *ScoreLbl = [[UILabel alloc] init];
    [self addSubview:ScoreLbl];
    ScoreLbl.backgroundColor = [UIColor whiteColor];
    ScoreLbl.textColor = Color_title_333;
    ScoreLbl.textAlignment = NSTextAlignmentCenter;
    ScoreLbl.text = @"甲方\n胜3.0";
    ScoreLbl.numberOfLines = 0;
    ScoreLbl.tag = 200 + count;
    ScoreLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    NSString *left = leftArr[count];
    NSString *width = widthArr[count];
    [ScoreLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(left.floatValue *SCALE_375);
        make.width.mas_offset(width.floatValue *SCALE_375);
        make.top.mas_offset(19 *SCALE_375);
        make.height.mas_offset(56 *SCALE_375);
    }];
    [ScoreLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
    
    
}

- (void)setValueWithModel:(YFJCZQ_model *)model {
    self.currentmodel = model;
    if (_spfTitle == nil) {
        self.spfTitle = @[[NSString stringWithFormat:@"%@\n胜",model.home],
                          [NSString stringWithFormat:@"VS\n胜"],
                          [NSString stringWithFormat:@"%@\n负",model.away]];
    }
    
    NSArray *spfArr = [model.spf componentsSeparatedByString:@","];
    NSArray *rqArr = [model.rq componentsSeparatedByString:@","];
    
    NSString *time = [NSString getmatichTime:model.matchtime.integerValue];
    _contentLbl.text = [NSString stringWithFormat:@"%@\n%@\n%@截止", model.event,  [model.issue_num  substringFromIndex:1], time];
    
    
    if (model.isSFP) {
        _rqNumLbl.hidden = YES;
        for (int i = 0; i < 3; i++) {
            UILabel *contentlbl = [self viewWithTag:200 + i];
            contentlbl.text = [NSString stringWithFormat:@"%@%@", _spfTitle[i], spfArr[i]];
            BOOL isSelet = [model.spfState[i] isEqual:@1];
            [self lableState:contentlbl isSelect:isSelet];
        }
    } else {
        _rqNumLbl.hidden = NO;
        NSString *rqStr = rqArr[0];
        if (rqStr.integerValue > 0) {
            _rqNumLbl.backgroundColor = [UIColor redColor];
            _rqNumLbl.text = [@"+" stringByAppendingString:rqStr];
        } else {
            _rqNumLbl.backgroundColor = JKRGBColor(117, 230, 130);
            _rqNumLbl.text = rqStr;
        }
        
        for (int i = 0; i < 3; i++) {
            UILabel *contentlbl = [self viewWithTag:200 + i];
            contentlbl.text = [NSString stringWithFormat:@"%@%@", _spfTitle[i], rqArr[i + 1]];
            BOOL isSelet = [model.rqState[i] isEqual:@1];
            [self lableState:contentlbl isSelect:isSelet];
        }
    }
    
    
    
    
}


//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {
    
    UILabel *currentLbl = (UILabel *)sender.view;
    BOOL isSelect = YES;
    if (_currentmodel.isSFP) {
        _currentmodel.spfState[currentLbl.tag - 200] =  [_currentmodel.spfState[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.spfState[currentLbl.tag - 200] isEqual:@1];
    } else {
        _currentmodel.rqState[currentLbl.tag - 200] =  [_currentmodel.rqState[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.rqState[currentLbl.tag - 200] isEqual:@1];
    }
    

    [self lableState:currentLbl isSelect:isSelect];
    
    [_currentmodel checkChooseCount];
    self.dataDidChanged();
    //测试一下
    
}

//- (void)checkChooseCount {
//    NSInteger count = 0;
//    BOOL isMoreFour = NO;
//    BOOL isCanDG = YES;
//
//    CGFloat maxOdd = 0;
//    CGFloat minOdd = 0;
//
//    NSArray *sell_status = [_currentmodel.sell_status componentsSeparatedByString:@","];
//
//
//
//
//    for (int i = 0; i < _currentmodel.spfState.count; i ++) {
//        NSNumber *state = _currentmodel.spfState[i];
//        if ([state isEqual:@1]) {
//            count ++;
//
//            NSNumber *currentOdd = _currentmodel.spfArr[i];
//            maxOdd += currentOdd.floatValue;
//
//            if (minOdd > 0) {
//                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
//            } else {
//                minOdd = currentOdd.floatValue;
//            }
//
//            if (![sell_status[0] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
//        }
//    }
//
//
//    for (int i = 0; i < _currentmodel.rqState.count; i ++) {
//        NSNumber *state = _currentmodel.rqState[i];
//        if ([state isEqual:@1]) {
//            count ++;
//
//            NSNumber *currentOdd = _currentmodel.rqState[i + 1];
//            maxOdd += currentOdd.floatValue;
//
//            if (minOdd > 0) {
//                minOdd = currentOdd.floatValue > minOdd ? minOdd : currentOdd.floatValue;
//            } else {
//                minOdd = currentOdd.floatValue;
//            }
//
//            if (![sell_status[0] isEqualToString:@"2"]) {
//                isCanDG = NO;
//            }
//        }
//    }
//
//
//    _currentmodel.chooseCount = count;
//    _currentmodel.isMoreFour = isMoreFour;
//    _currentmodel.isCanDG = isCanDG;
//    _currentmodel.maxOdd = maxOdd;
//    _currentmodel.minOdd = minOdd;
//    if (_currentmodel.chooseCount == 0) {
//        _currentmodel.isCanDG = YES;
//    }
//}


// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
