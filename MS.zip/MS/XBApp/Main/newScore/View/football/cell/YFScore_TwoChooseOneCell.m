//
//  YFScore_TwoChooseOneCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScore_TwoChooseOneCell.h"
#import "YFJCZQ_model.h"

@interface YFScore_TwoChooseOneCell()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) NSArray *spfTitle;

@property (nonatomic, strong) YFJCZQ_model *currentmodel;

@end



@implementation YFScore_TwoChooseOneCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFScore_TwoChooseOneCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFScore_TwoChooseOneCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        [cell initUI];
    }
    return cell;
}


- (void)initUI  {
    
    UILabel *contentLbl = [[UILabel alloc] init];
    [self addSubview:contentLbl];
    self.contentLbl = contentLbl;
    contentLbl.textColor = Color_title_666;
    contentLbl.textAlignment = NSTextAlignmentCenter;
    contentLbl.numberOfLines = 0;
    contentLbl.text = @"001\n\n国际赛\n\n17:40截止";
    contentLbl.font = [UIFont systemFontOfSize:11];
    [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(0);
        make.top.bottom.mas_offset(0);
        make.width.mas_offset(61 *SCALE_375);
    }];
    [self addCenterView];
}




- (void)addCenterView {
    
    UILabel *leftLbl = [[UILabel alloc] init];
    [self addSubview:leftLbl];
    leftLbl.textColor = Color_title_333;
    leftLbl.text = @"甲方\n主胜3.25";
    leftLbl.numberOfLines = 0;
    leftLbl.tag = 200;
    leftLbl.font = [UIFont systemFontOfSize:11 *SCALE_375];
    leftLbl.textAlignment = NSTextAlignmentCenter;
    leftLbl.backgroundColor = [UIColor whiteColor];
    [leftLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(67 *SCALE_375);
        make.top.mas_offset(20 *SCALE_375);
        make.width.mas_offset(148 *SCALE_375);
        make.height.mas_offset(60 *SCALE_375);
    }];
    [leftLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
    
    
    UILabel *rightLbl = [[UILabel alloc] init];
    [self addSubview:rightLbl];
    rightLbl.textColor = Color_title_333;
    rightLbl.text = @"乙方\n客不败3.25";
    rightLbl.tag = 201;
    rightLbl.numberOfLines = 0;
    rightLbl.font = [UIFont systemFontOfSize:11 *SCALE_375];
    rightLbl.textAlignment = NSTextAlignmentCenter;
    rightLbl.backgroundColor = [UIColor whiteColor];
    [rightLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(218 *SCALE_375);
        make.top.mas_offset(20 *SCALE_375);
        make.width.mas_offset(148 *SCALE_375);
        make.height.mas_offset(60 *SCALE_375);
    }];
     [rightLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
    
}



- (void)setValueWithModel:(YFJCZQ_model *)model {
    self.currentmodel = model;

    
    NSString *time = [NSString getmatichTime:model.matchtime.integerValue];
    _contentLbl.text = [NSString stringWithFormat:@"%@\n%@\n%@截止", model.event,  [model.issue_num  substringFromIndex:1], time];
    
    NSArray *rqArr = [model.rq componentsSeparatedByString:@","];
    NSArray *exyArr = [model.exy componentsSeparatedByString:@","];
    
    NSArray *noramlArr = @[@"主胜", @"客不败"];
    NSArray *otherArr = @[@"主不败", @"客胜"];
    NSArray *currentArr = [rqArr[0] isEqualToString:@"-1"]  ? noramlArr : otherArr;
    
    for (int i = 0; i < 2; i++) {
        UILabel *contentlbl = [self viewWithTag:200 + i];
        NSString *name = i == 0 ? model.home : model.away;
        contentlbl.text = [NSString stringWithFormat:@"%@\n%@%@", name, currentArr[i], exyArr[i]];
        BOOL isSelet = [model.exyState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
    
    
    
}


//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {
    
    UILabel *currentLbl = (UILabel *)sender.view;
    BOOL isSelect = YES;

    _currentmodel.exyState[currentLbl.tag - 200] =  [_currentmodel.exyState[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
    isSelect = [_currentmodel.exyState[currentLbl.tag - 200] isEqual:@1];
    
    [self lableState:currentLbl isSelect:isSelect];
    
}



// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
}




- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
