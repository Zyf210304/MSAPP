//
//  YFScorePop_allBallsView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScorePop_allBallsView.h"
#import "YFJCZQ_model.h"

@interface YFScorePop_allBallsView()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) UILabel *matchtitle;

@property (nonatomic, strong) NSArray *ballNumber;

@property (nonatomic, strong) YFJCZQ_model *currentmodel;

@end

@implementation YFScorePop_allBallsView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        self.ballNumber = @[@"0球", @"1球", @"2球", @"3球",
                            @"4球", @"5球", @"6球", @"7+球"];
        
        [self initUI];
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
        [self addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    }
    return self;
}

- (void)initUI {
    UIView *centerView = [[UIView alloc] init];
    [self addSubview:centerView];
    centerView.backgroundColor = Color_Base_BG;
    centerView.layer.masksToBounds = YES;
    centerView.layer.cornerRadius = 3.0;
    [centerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_offset(FRAME_WIDTH - 30 *SCALE_375);
        make.height.mas_offset(173 *SCALE_375);
        make.centerX.equalTo(self.mas_centerX);
        make.centerY.equalTo(self.mas_centerY);
    }];
    [centerView addTapgestureWithTarget:self action:@selector(nothing:)];
    
    [self addMatchtitle:centerView];
    [self addBottmChooseLbl:centerView];
    [self addCenterChooseView:centerView];
}

- (void)addMatchtitle:(UIView *)centerView {
    UILabel *matchtitle = [[UILabel alloc] init];
    [centerView addSubview:matchtitle];
    matchtitle.textAlignment = NSTextAlignmentCenter;
    matchtitle.textColor = Color_title_333;
    matchtitle.text = @"甲方  VS  乙方";
    _matchtitle = matchtitle;
    matchtitle.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [matchtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(31 *SCALE_375);
    }];
    
}



- (void)addBottmChooseLbl:(UIView *)centerView  {
    
    UILabel *leftLbl = [[UILabel alloc] init];
    [centerView addSubview:leftLbl];
    leftLbl.textAlignment = NSTextAlignmentCenter;
    leftLbl.backgroundColor = [UIColor whiteColor];
    leftLbl.text = @"取消";
    leftLbl.textColor = Color_title_333;
    leftLbl.font = [UIFont systemFontOfSize:13];
    [leftLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.mas_offset(0);
        make.right.equalTo(centerView.mas_centerX).offset(-0.5);
        make.height.mas_offset(41 *SCALE_375);
    }];
    [leftLbl addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    
    UILabel *rightLbl = [[UILabel alloc] init];
    [centerView addSubview:rightLbl];
    rightLbl.textAlignment = NSTextAlignmentCenter;
    rightLbl.backgroundColor = [UIColor whiteColor];
    rightLbl.text = @"确定";
    rightLbl.textColor = UIColorFromRGB(0xA94148);
    rightLbl.font = [UIFont systemFontOfSize:13];
    [rightLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.mas_offset(0);
        make.left.equalTo(centerView.mas_centerX).offset(0.5);
        make.height.mas_offset(41 *SCALE_375);
    }];

    [rightLbl addTapgestureWithTarget:self action:@selector(trueAction:)];
}

- (void)addCenterChooseView:(UIView *)centerView  {
    
    UILabel *typelbl = [[UILabel alloc] init];
    [centerView addSubview:typelbl];
    typelbl.textAlignment = NSTextAlignmentCenter;
    typelbl.textColor = UIColorFromRGB(0x998D50);
    typelbl.backgroundColor = UIColorFromRGB(0xEBE1BD);
    typelbl.numberOfLines = 0;
    typelbl.text = @"总进球";
    typelbl.backgroundColor = JKRGBColor(227, 237, 140);
    typelbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [typelbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(5 *SCALE_375);
        make.top.mas_offset(31 *SCALE_375);
        make.width.mas_offset(22 *SCALE_375);
        make.bottom.mas_offset(- 54 *SCALE_375);
    }];
    
    NSArray *ballNumber = @[@"0球", @"1球", @"2球", @"3球",
                            @"4球", @"5球", @"6球", @"7+球"];
    CGFloat width = 75 *SCALE_375;
    for (int i = 0; i < 2; i ++) {
        for (int j = 0; j < 4; j++) {
            UILabel *chooseLbl = [[UILabel alloc] init];
            [centerView addSubview:chooseLbl];
            chooseLbl.backgroundColor = [UIColor whiteColor];
            chooseLbl.textColor = Color_title_333;
            chooseLbl.font = [UIFont systemFontOfSize:12 *SCALE_375];
            chooseLbl.numberOfLines = 2;
            chooseLbl.tag = 200 + i *4 + j;
            chooseLbl.backgroundColor = [UIColor whiteColor];
            chooseLbl.textAlignment = NSTextAlignmentCenter;
            chooseLbl.text = [NSString stringWithFormat:@"%@\n3.44", ballNumber[i *4 + j]];
            [chooseLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(27 *SCALE_375 + 76 *SCALE_375 *j);
                make.width.mas_offset(width);
                if (i == 0) {
                    make.top.equalTo(typelbl.mas_top);
                    make.bottom.equalTo(typelbl.mas_centerY).offset(-0.5 *SCALE_375);
                } else {
                    make.top.equalTo(typelbl.mas_centerY).offset(0.5 *SCALE_375);
                    make.bottom.equalTo(typelbl.mas_bottom);
                }
            }];
            
            [chooseLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
        }
    }
    
}

- (void)nothing:(UITapGestureRecognizer *)sender {
    NSLog(@"");
}

- (void)hiddenSelf:(UITapGestureRecognizer *)sender {
    self.hidden = YES;
}


- (void)setValueWithModel:(YFJCZQ_model *)model {
    self.currentmodel = model;
    
    NSArray *jqArr = [model.jq componentsSeparatedByString:@","];
    
    _matchtitle.text = [NSString stringWithFormat:@"%@ VS %@", model.home, model.away];
    
    //进球
    for (int i = 0; i < 8 ; i++) {
        UILabel *contentlbl = [self viewWithTag:200 + i];
        contentlbl.text = [NSString stringWithFormat:@"%@\n%@", _ballNumber[i], jqArr[i]];
        BOOL isSelet = [model.jqState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
}


//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {
    
    UILabel *currentLbl = (UILabel *)sender.view;
    
    _currentmodel.jqState[currentLbl.tag - 200] =  [_currentmodel.jqState[currentLbl.tag - 200] isEqual:@0] ? @1 : @0;
    BOOL isSelect = [_currentmodel.jqState[currentLbl.tag - 200] isEqual:@1];
    
    [self lableState:currentLbl isSelect:isSelect];
    [_currentmodel checkChooseCount];
}


// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
}


- (void)trueAction:(UITapGestureRecognizer *)sender {
    self.hidden = YES;
    self.trueBlock();
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
