//
//  YFScore_ScoreCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScore_ScoreCell.h"
#import "YFJCZQ_model.h"

@interface YFScore_ScoreCell()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) UILabel *matchtitle;

@property (nonatomic, strong) UILabel *centerLbl;

@property (nonatomic, strong) NSArray *spfTitle;

@property (nonatomic, strong) YFJCZQ_model *currentmodel;

@property (nonatomic, strong) NSArray *ScoreArr;
@property (nonatomic, strong) NSArray *resultArr;
@property (nonatomic, strong) NSArray *ballNumber;

@end

@implementation YFScore_ScoreCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

// 37 + 41 + 24   37 + 65  =102
+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFScore_ScoreCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFScore_ScoreCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        [cell initUI];
    }
    return cell;
}


- (void)initUI  {
    
    self.ScoreArr = @[@"1:0", @"2:0", @"2:1", @"3:0", @"3:1",
                      @"3:2", @"4:0", @"4:1", @"4:2", @"5:0",
                      @"5:1", @"5:2", @"胜其他",
                      @"0:0", @"1:1", @"2:2", @"3:3", @"平其他",
                      @"0:1", @"0:2", @"1:2", @"0:3:0", @"1:3",
                      @"2:3", @"0:4", @"1:4", @"2:4", @"0:5",
                      @"1:5", @"2:5", @"负其他"];
    
    self.resultArr = @[@"胜胜", @"胜平", @"胜负",
                       @"平胜", @"平平", @"平负",
                       @"负胜", @"负平", @"负负"];
    
    self.ballNumber = @[@"0球", @"1球", @"2球", @"3球",
                        @"4球", @"5球", @"6球", @"7+球"];
    
    UILabel *contentLbl = [[UILabel alloc] init];
    [self addSubview:contentLbl];
    self.contentLbl = contentLbl;
    contentLbl.textColor = Color_title_666;
    contentLbl.textAlignment = NSTextAlignmentCenter;
    contentLbl.numberOfLines = 0;
    contentLbl.text = @"001\n\n国际赛\n\n17:40截止";
    contentLbl.font = [UIFont systemFontOfSize:11];
    [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(0);
        make.top.bottom.mas_offset(0);
        make.width.mas_offset(61 *SCALE_375);
    }];
    [self addMatchtitle];
    [self addCenterView];
}


- (void)addMatchtitle {
    UILabel *matchtitle = [[UILabel alloc] init];
    [self addSubview:matchtitle];
    matchtitle.textAlignment = NSTextAlignmentCenter;
    matchtitle.textColor = Color_title_333;
    matchtitle.text = @"甲方  VS  乙方";
    _matchtitle = matchtitle;
    matchtitle.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [matchtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(37 *SCALE_375);
    }];
    
}


- (void)addCenterView {
    
    UILabel *centerLbl = [[UILabel alloc] init];
    [self addSubview:centerLbl];
    centerLbl.textColor = Color_title_333;
    centerLbl.font = [UIFont systemFontOfSize:11 *SCALE_375];
    centerLbl.textAlignment = NSTextAlignmentCenter;
    centerLbl.backgroundColor = [UIColor whiteColor];
    centerLbl.text = @"点击投注";
    _centerLbl = centerLbl;
    [centerLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(67 *SCALE_375);
        make.top.mas_offset(34 *SCALE_375);
        make.right.mas_offset(- 10 *SCALE_375);
        make.height.mas_offset(41 *SCALE_375);
    }];
    
    [centerLbl addTapgestureWithTarget:self action:@selector(chooseAction:)];
    
}

- (void)setValueWithModel:(YFJCZQ_model *)model {
    self.currentmodel = model;
    
    NSString *time = [NSString getmatichTime:model.matchtime.integerValue];
    _contentLbl.text = [NSString stringWithFormat:@"%@\n%@\n%@截止", model.event,  [model.issue_num  substringFromIndex:1], time];
    _matchtitle.text = [NSString stringWithFormat:@"%@ VS %@", model.home, model.away];
    
    _centerLbl.textColor = Color_title_333;
    _centerLbl.backgroundColor = [UIColor whiteColor];
    _centerLbl.text = @"点击投注";
    
    [self countChooseType];
    
}

- (void)countChooseType {
    BOOL isBF = NO;
    BOOL isJQ = NO;
    BOOL isBQC = NO;
    
    for (NSNumber *select in _currentmodel.bfState) {
        if ([select isEqual:@1]) {
            isBF = YES;
        }
    }
    for (NSNumber *select in _currentmodel.jqState) {
        if ([select isEqual:@1]) {
            isJQ = YES;
        }
    }
    for (NSNumber *select in _currentmodel.bqcState) {
        if ([select isEqual:@1]) {
            isBQC = YES;
        }
    }
    
    
    if (isBF) {
        [self CountBF];
    }
    
    if (isJQ) {
        [self countJQ];
    }
    
    if (isBQC) {
        [self countBQC];
    }
    
}


- (void)CountBF {
    
    NSString *contenStr = @"";
    NSArray *bfArr = [_currentmodel.bf componentsSeparatedByString:@","];
    for (int i = 0; i < _currentmodel.bfState.count; i++) {
        NSNumber *selcet = _currentmodel.bfState[i];
        if ([selcet isEqual:@1]) {
            contenStr = [NSString stringWithFormat:@"%@%@[%@] ", contenStr, _ScoreArr[i], bfArr[i]];
        }
    }
    [self changeContentLbl:contenStr];
    
}

- (void)countJQ {
    NSString *contenStr = @"";
    NSArray *jqArr = [_currentmodel.jq componentsSeparatedByString:@","];
    for (int i = 0; i < _currentmodel.jqState.count; i++) {
        NSNumber *selcet = _currentmodel.jqState[i];
        if ([selcet isEqual:@1]) {
            contenStr = [NSString stringWithFormat:@"%@%@[%@] ", contenStr, _ballNumber[i], jqArr[i]];
        }
    }
     [self changeContentLbl:contenStr];
}


- (void)countBQC {
    
    NSString *contenStr = @"";
    NSArray *bqcArr = [_currentmodel.bqc componentsSeparatedByString:@","];
    for (int i = 0; i < _currentmodel.bqcState.count; i++) {
        NSNumber *selcet = _currentmodel.bqcState[i];
        if ([selcet isEqual:@1]) {
            contenStr = [NSString stringWithFormat:@"%@%@[%@] ", contenStr, _resultArr[i], bqcArr[i]];
        }
    }
    
    [self changeContentLbl:contenStr];
}







- (void)changeContentLbl:(NSString *)contenStr {
    
    if (!contenStr.length) {
        _centerLbl.textColor = Color_title_333;
        _centerLbl.backgroundColor = [UIColor whiteColor];
        _centerLbl.text = @"点击投注";
    } else {
        _centerLbl.textColor = [UIColor whiteColor];
        _centerLbl.backgroundColor = [UIColor redColor];
        _centerLbl.text = contenStr;
    }
}



- (void)chooseAction:(UITapGestureRecognizer *)sender {
    self.chooseLotteryBlock();
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
