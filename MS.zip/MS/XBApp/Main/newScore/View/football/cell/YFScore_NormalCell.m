//
//  YFScore_NormalCell.m
//  XBApp
//
//  Created by 张亚飞 on 2018/9/30.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFScore_NormalCell.h"
#import "YFJCZQ_model.h"

@interface YFScore_NormalCell()

@property (nonatomic, strong) UILabel *contentLbl;

@property (nonatomic, strong) UILabel *matchtitle;

@property (nonatomic, strong) NSArray *spfTitle;

@property (nonatomic, strong) YFJCZQ_model *currentmodel;

@property (nonatomic, strong) UILabel *chooseNumLbl;

@property (nonatomic, strong) UIImageView *danImg;

@end

@implementation YFScore_NormalCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    YFScore_NormalCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    if (cell == nil) {
        cell = [[YFScore_NormalCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([self class])];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor whiteColor];
        cell.backgroundColor = UIColorFromRGB(0xf4f4f4);
        
        
        [cell initArr];
        [cell initUI];
    }
    return cell;
}

- (void)initArr {
    self.spfTitle = @[@"胜", @"平", @"负"];
}

- (void)initUI  {
    self.danImg = [[UIImageView alloc] init];
    [self addSubview:_danImg];
    _danImg.hidden = YES;
    _danImg.image = [UIImage imageNamed:@"icon_dan"];
    [_danImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_offset(0);
        make.width.height.mas_offset(27 *SCALE_375);
    }];
    
    
    
    UILabel *contentLbl = [[UILabel alloc] init];
    [self addSubview:contentLbl];
    self.contentLbl = contentLbl;
    contentLbl.textColor = Color_title_666;
    contentLbl.textAlignment = NSTextAlignmentCenter;
    contentLbl.numberOfLines = 0;
    contentLbl.text = @"001\n\n国际赛\n\n17:40截止";
    contentLbl.font = [UIFont systemFontOfSize:11];
    [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(0);
        make.top.bottom.mas_offset(0);
        make.width.mas_offset(61 *SCALE_375);
    }];

    [self addMatchtitle];
    [self addCenterView];
    [self addRightView];
}

- (void)addMatchtitle {
    UILabel *matchtitle = [[UILabel alloc] init];
    [self addSubview:matchtitle];
    _matchtitle = matchtitle;
    matchtitle.textAlignment = NSTextAlignmentCenter;
    matchtitle.textColor = Color_title_333;
    matchtitle.text = @"甲方  VS  乙方";
    matchtitle.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [matchtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(37 *SCALE_375);
    }];
    
}


- (void)addCenterView {
    for (int i = 0; i < 2; i++) {
        [self addCenterChildView:i];
    }
}

- (void)addCenterChildView:(NSInteger)count {
    CGFloat top = count == 0 ? 37 *SCALE_375 : 73 *SCALE_375;
    CGFloat width = 75 *SCALE_375;
    
    UILabel *numberLbl = [[UILabel alloc] init];
    [self addSubview:numberLbl];
    numberLbl.text = @"0";
    numberLbl.tag = 200 *(count + 1);
    numberLbl.backgroundColor = UIColorFromRGB(0xEAE6E7);
    numberLbl.textAlignment = NSTextAlignmentCenter;
    numberLbl.font = [UIFont systemFontOfSize:12 *SCALE_375];
    numberLbl.textColor = Color_title_333;
    [numberLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(64 *SCALE_375);
        make.top.mas_offset(top);
        make.width.mas_offset(22 *SCALE_375);
        make.height.mas_offset(35 *SCALE_375);
    }];
    
    for (int i = 0; i < 3; i++) {
        UILabel *contentlbl = [[UILabel alloc] init];
        [self addSubview:contentlbl];
        contentlbl.text = @"胜 1.70";
        contentlbl.tag = 200 * (count + 1) + i + 1;
        contentlbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
        contentlbl.backgroundColor = [UIColor whiteColor];
        contentlbl.textAlignment = NSTextAlignmentCenter;
        contentlbl.layer.borderWidth = 1;
        [contentlbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
        [contentlbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(86 *SCALE_375 + (width + SCALE_375) * i);
            make.top.mas_offset(top);
            make.width.mas_offset(width);
            make.height.mas_offset(35 *SCALE_375);
        }];
    }
    
    UILabel *notOpen = [[UILabel alloc] init];
    [self addSubview:notOpen];
    notOpen.textColor = Color_title_333;
    notOpen.backgroundColor = [UIColor whiteColor];
    notOpen.textAlignment = NSTextAlignmentCenter;
    notOpen.text = @"未开放";
    notOpen.tag = 700 + count;
    notOpen.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [notOpen mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(86 *SCALE_375);
        make.top.mas_offset(top);
        make.right.mas_offset(- 63 *SCALE_375);
        make.height.mas_offset(35 *SCALE_375);
    }];
    notOpen.hidden = YES;
    
}


- (void)addRightView {
    UILabel *rightLbl = [[UILabel alloc] init];
    [self addSubview:rightLbl];
    _chooseNumLbl = rightLbl;
    rightLbl.backgroundColor = [UIColor whiteColor];
    rightLbl.textColor = UIColorFromRGB(0x979184);
    rightLbl.textAlignment = NSTextAlignmentCenter;
    rightLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    rightLbl.numberOfLines = 2;
    rightLbl.text = @"全部\n玩法";
    [rightLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(314 *SCALE_375);
        make.top.mas_offset(37 *SCALE_375);
        make.width.mas_offset(51 *SCALE_375);
        make.height.mas_offset(71 *SCALE_375);
    }];
    
    [rightLbl addTapgestureWithTarget:self action:@selector(gotoDetailAction:)];
    
}

- (void)gotoDetailAction:(UITapGestureRecognizer *)sender {
    self.gotoDeatil(nil);
}


// 赋值
- (void)setValueWithModel:(YFJCZQ_model *)model {
    _danImg.hidden = YES;
    self.currentmodel = model;
    NSArray *sell_status  = [model.sell_status componentsSeparatedByString:@","];
    _danImg.hidden = !([sell_status[0] isEqualToString:@"2"] || [sell_status[1] isEqualToString:@"2"]);
        

    
    
    NSArray *spfArr = [model.spf componentsSeparatedByString:@","];
    NSArray *rqArr = [model.rq componentsSeparatedByString:@","];
    
    NSString *time = [NSString getmatichTime:model.matchtime.integerValue];
    _contentLbl.text = [NSString stringWithFormat:@"\n%@\n%@\n%@截止", model.event,  [model.issue_num  substringFromIndex:1], time];
    
    _matchtitle.text = [NSString stringWithFormat:@"%@ VS %@", model.home, model.away];
    
    //胜平负
    for (int i = 0; i < 3; i++) {
        UILabel *contentlbl = [self viewWithTag:201 + i];
        contentlbl.layer.borderColor = [sell_status[0] isEqualToString:@"2"] ? [UIColor orangeColor].CGColor : [UIColor clearColor].CGColor;
        contentlbl.text = [NSString stringWithFormat:@"%@%@", _spfTitle[i], spfArr[i]];
        BOOL isSelet = [model.spfState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
    
    //让球
    for (int i = 0; i < 3; i++) {
        UILabel *contentlbl = [self viewWithTag:401 + i];
        contentlbl.layer.borderColor = [sell_status[1] isEqualToString:@"2"] ? [UIColor orangeColor].CGColor : [UIColor clearColor].CGColor;
        contentlbl.text = [NSString stringWithFormat:@"%@%@", _spfTitle[i], rqArr[i + 1]];
        BOOL isSelet = [model.rqState[i] isEqual:@1];
        [self lableState:contentlbl isSelect:isSelet];
    }
    
    
    if (model.isDG) {
        NSArray *sell_status = [_currentmodel.sell_status componentsSeparatedByString:@","];
        UILabel *notOpenSpf = [self viewWithTag:700];
        notOpenSpf.hidden = [sell_status[0] isEqualToString:@"2"];
        
        UILabel *notOpenRq = [self viewWithTag:701];
        notOpenRq.hidden = [sell_status[1] isEqualToString:@"2"];
    } else {
        UILabel *notOpenSpf = [self viewWithTag:700];
        UILabel *notOpenRq = [self viewWithTag:701];
        notOpenSpf.hidden = notOpenRq.hidden = YES;
    }
   
    
    
    //左侧   添加颜色
    UILabel *spfLbl = [self viewWithTag:200];
    spfLbl.backgroundColor = JKRGBColor(204, 229, 253);
    UILabel *rqLbl = [self viewWithTag:400];
    NSString *rqStr = rqArr[0];
    if (rqStr.integerValue > 0) {
        rqLbl.backgroundColor = JKRGBColor(249, 220, 226);
        rqLbl.text = [@"+" stringByAppendingString:rqStr];
    } else {
        rqLbl.backgroundColor = JKRGBColor(226, 242, 177);
        rqLbl.text = rqStr;
    }

    [_currentmodel checkChooseCount];
    if (_currentmodel.chooseCount > 0) {
        _chooseNumLbl.text = [NSString stringWithFormat:@"已选\n%zd项", _currentmodel.chooseCount];
        _chooseNumLbl.backgroundColor = [UIColor redColor];
        _chooseNumLbl.textColor = [UIColor whiteColor];
    } else {
        _chooseNumLbl.text = @"全部\n玩法";
        _chooseNumLbl.backgroundColor = [UIColor whiteColor];
        _chooseNumLbl.textColor = UIColorFromRGB(0x979184);
    }
    _chooseNumLbl.userInteractionEnabled = !model.isDG;
}



//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {
    
    UILabel *currentLbl = (UILabel *)sender.view;
    BOOL isSelect = NO;
    if (currentLbl.tag > 300) {
       _currentmodel.rqState[currentLbl.tag - 401] =  [_currentmodel.rqState[currentLbl.tag - 401] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.rqState[currentLbl.tag - 401] isEqual:@1];
    } else {
        _currentmodel.spfState[currentLbl.tag - 201] =  [_currentmodel.spfState[currentLbl.tag - 201] isEqual:@0] ? @1 : @0;
        isSelect = [_currentmodel.spfState[currentLbl.tag - 201] isEqual:@1];
    }
    [self lableState:currentLbl isSelect:isSelect];
    [_currentmodel checkChooseCount];
    if (_currentmodel.chooseCount > 0) {
        _chooseNumLbl.text = [NSString stringWithFormat:@"已选\n%zd项", _currentmodel.chooseCount];
        _chooseNumLbl.backgroundColor = [UIColor redColor];
        _chooseNumLbl.textColor = [UIColor whiteColor];
    } else {
        _chooseNumLbl.text = @"全部\n玩法";
        _chooseNumLbl.backgroundColor = [UIColor whiteColor];
        _chooseNumLbl.textColor = UIColorFromRGB(0x979184);
    }

    self.dataDidChanged();
    
}
// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
    
}







- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
