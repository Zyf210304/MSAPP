//
//  YFScore_moreCell.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/8.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YFJCZQ_model;

typedef enum {
    
    Lottery_Result,
    
    Lottery_Score,
    
    Lottery_BallNumer,
    
    Lottery_DoubleResult
    
}LotteryType;


@interface YFScore_moreCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView addType:(LotteryType)type;

- (void)setValueWith:(YFJCZQ_model *)model addType:(LotteryType)type;

@end
