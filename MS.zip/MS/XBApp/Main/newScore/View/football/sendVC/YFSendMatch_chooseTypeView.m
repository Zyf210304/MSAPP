//
//  YFSendMatch_chooseTypeView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/11.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFSendMatch_chooseTypeView.h"

@interface YFSendMatch_chooseTypeView()

@property (nonatomic, strong) NSMutableArray *typeArr;

@property (nonatomic)         NSInteger countNum;

@end

@implementation YFSendMatch_chooseTypeView


- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = Color_Base_BG;
        [self initUI];
        
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
        [self addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    }
    return self;
}

- (void)initUI {
    
    UIView *centerView = [[UIView alloc] init];
    [self addSubview:centerView];
    centerView.backgroundColor = Color_Base_BG;
    centerView.layer.masksToBounds = YES;
    centerView.layer.cornerRadius = 3.0;
    [centerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        if (@available(iOS 11.0,*)) {
            make.bottom.equalTo(self.mas_safeAreaLayoutGuideBottom);
        }else{
            make.bottom.mas_equalTo(0);
        }
        make.height.mas_offset(245 *SCALE_375);
    }];
    [centerView addTapgestureWithTarget:self action:@selector(nothing:)];
    
    
    [self addTopUI:centerView];
    [self addBottomUI:centerView];
}



- (void)addTopUI:(UIView *)centerView {
    UILabel *titleLBl = [[UILabel alloc] init];
    [centerView addSubview:titleLBl];
    titleLBl.text = @"标准过关";
    titleLBl.textColor = Color_title_333;
    titleLBl.font = [UIFont systemFontOfSize:15 *SCALE_375];
    [titleLBl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.mas_offset(0);
        make.left.mas_offset(10 *SCALE_375);
        make.height.mas_offset(35 *SCALE_375);
    }];
    
    UIView *TypeView = [[UIView alloc] init];
    [centerView addSubview:TypeView];
    TypeView.backgroundColor = [UIColor whiteColor];
    [TypeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(35 *SCALE_375);
        make.left.right.mas_offset(0);
        make.height.mas_offset(165 *SCALE_375);
    }];
    
    CGFloat lbl_width = (FRAME_WIDTH - 60) / 3;
    CGFloat lbl_height = 40 *SCALE_375;
    for (int i = 0; i < 3; i ++) {
        for (int j = 0; j < 3; j ++) {
            if (i == 2 && j == 1) {
                break;
            }
            UILabel *typelbl = [[UILabel alloc] init];
            typelbl.text = [NSString stringWithFormat:@"%d串1", i * 3 + j + 2];
            typelbl.tag = 2000 + i * 3 + j;
            [TypeView addSubview:typelbl];
            typelbl.textColor = Color_title_333;
            typelbl.font = [UIFont systemFontOfSize:15 *SCALE_375];
            typelbl.textAlignment = NSTextAlignmentCenter;
            typelbl.layer.masksToBounds = YES;
            typelbl.layer.cornerRadius = 4 *SCALE_375;
            typelbl.layer.borderWidth = 1;
            typelbl.layer.borderColor = Color_title_bbb.CGColor;
            [typelbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.width.mas_offset(lbl_width);
                make.height.mas_offset(lbl_height);
                make.left.mas_offset(15 *SCALE_375 + (15 *SCALE_375 + lbl_width) * j);
                make.top.mas_offset(10 *SCALE_375 + (10 *SCALE_375 + lbl_height) *i);
            }];
            
            [typelbl addTapgestureWithTarget:self action:@selector(changeCurrenttype:)];
        }
    }
    
}

//45
- (void)addBottomUI:(UIView *)centerView  {
    
    UIView *bottomView = [[UIView alloc] init];
    [centerView addSubview:bottomView];
    [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_offset(0);
        make.height.mas_offset(45 *SCALE_375);
    }];
    
    UILabel *cancelLbl = [[UILabel alloc] init];
    [bottomView addSubview:cancelLbl];
    cancelLbl.textColor = Color_title_333;
    cancelLbl.textAlignment = NSTextAlignmentCenter;
    cancelLbl.backgroundColor = [UIColor whiteColor];
    cancelLbl.text = @"取消";
    [cancelLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_offset(1);
        make.bottom.mas_offset(-1);
        make.width.mas_offset(FRAME_WIDTH/ 2 - 1.5);
    }];
    [cancelLbl addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    
    UILabel *trueLbl = [[UILabel alloc] init];
    [bottomView addSubview:trueLbl];
    trueLbl.textColor = [UIColor whiteColor];
    trueLbl.textAlignment = NSTextAlignmentCenter;
    trueLbl.backgroundColor = [UIColor redColor];
    trueLbl.text = @"确定";
    [trueLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(1);
        make.bottom.right.mas_offset(-1);
        make.width.mas_offset(FRAME_WIDTH/ 2 - 1.5);
    }];
    [trueLbl addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    
}

- (void)nothing:(UITapGestureRecognizer *)sender {
    NSLog(@"");
}

- (void)hiddenSelf:(UITapGestureRecognizer *)sender {
    self.changeTypeChoose(_chooseTypeStr);
    self.hidden = YES;
}



- (void)setValueWith:(NSInteger)count with:(NSMutableArray *)typeArr{
    _typeArr = typeArr;
    NSInteger countNum = count > 8 ? 6 : count - 2;
    _countNum = countNum;

    for (int i = 0; i < 7; i++) {
        UILabel *typeLbl = [self viewWithTag:2000 + i];
        [self lableState:typeLbl isSelect:[_typeArr[i] isEqual:@1]];
        typeLbl.hidden = i > countNum;
        if (i >countNum) {
            _typeArr[i] = @0;
        }
    }
    
    NSString *chooseTypeStr = @"";
    for ( int i = 0 ; i <= _countNum; i++) {
        UILabel *typeLbl = [self viewWithTag:2000 + i];
        if ([_typeArr[i] isEqual:@1]) {
            chooseTypeStr = [NSString stringWithFormat:@"%@,%@", chooseTypeStr, typeLbl.text];
        }
    }
    _chooseTypeStr = chooseTypeStr.length ?  [chooseTypeStr substringFromIndex:1] : @"";
}


- (void)changeCurrenttype:(UITapGestureRecognizer *)sender {
    
  
    UILabel *currentLbl = (UILabel *)sender.view;
    _typeArr[currentLbl.tag - 2000] =  [_typeArr[currentLbl.tag - 2000] isEqual:@0] ? @1 : @0;
    BOOL isSelect = [_typeArr[currentLbl.tag - 2000] isEqual:@1];
    [self lableState:currentLbl isSelect:isSelect];

    
    NSString *chooseTypeStr = @"";
    for ( int i = 0 ; i <= _countNum; i++) {
        UILabel *typeLbl = [self viewWithTag:2000 + i];
        if ([_typeArr[i] isEqual:@1]) {
            chooseTypeStr = [NSString stringWithFormat:@"%@,%@", chooseTypeStr, typeLbl.text];
        }
    }
    _chooseTypeStr = chooseTypeStr.length ?  [chooseTypeStr substringFromIndex:1] : @"";
}


// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
}







/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
