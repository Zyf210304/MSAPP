//
//  YFSendMatch_chooseTypeView.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/11.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFSendMatch_chooseTypeView : UIView

- (void)setValueWith:(NSInteger)count with:(NSMutableArray *)typeArr;


@property (nonatomic, copy)     void(^changeTypeChoose)(NSString *chooseTypeStr);

@property (nonatomic, strong) NSString *chooseTypeStr;

@end
