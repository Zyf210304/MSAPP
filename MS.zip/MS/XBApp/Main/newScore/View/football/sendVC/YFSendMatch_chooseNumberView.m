//
//  YFSendMatch_chooseNumberView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/11.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFSendMatch_chooseNumberView.h"

@interface YFSendMatch_chooseNumberView()<UITextFieldDelegate>


@end

@implementation YFSendMatch_chooseNumberView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = Color_Base_BG;
        [self initUI];
    }
    return self;
}

- (void)initUI {
    _chooseTypeStr = @"选择过关类型";
    [self addLeftView];
    [self addRightView];
}

- (void)addLeftView {
    
    UIView *leftView = [[UIView alloc] init];
    [self addSubview:leftView];
    leftView.backgroundColor = [UIColor whiteColor];
    [leftView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_offset(1);
        make.bottom.mas_offset(-1);
        make.width.mas_offset(FRAME_WIDTH/ 2 - 1.5);
    }];

    UILabel *chooseTypeLbl = [[UILabel alloc] init];
    [leftView addSubview:chooseTypeLbl];
    _chooseTypeLbl = chooseTypeLbl;
    chooseTypeLbl.text = @"请选择过关类型";
    chooseTypeLbl.textColor = Color_title_333;
    chooseTypeLbl.textAlignment = NSTextAlignmentCenter;
    chooseTypeLbl.numberOfLines = 2;
    chooseTypeLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [chooseTypeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(10 *SCALE_375);
        make.right.mas_offset(- 10 *SCALE_375);
        make.top.bottom.mas_offset(0);
    }];
    [chooseTypeLbl addTapgestureWithTarget:self action:@selector(showTypeViewAction:)];
    
}

- (void)addRightView {
    
    UIView *rightViw = [[UIView alloc] init];
    [self addSubview:rightViw];
    rightViw.backgroundColor = [UIColor whiteColor];
    [rightViw mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(1);
        make.bottom.right.mas_offset(-1);
        make.width.mas_offset(FRAME_WIDTH/ 2 - 1.5);
    }];
    
    UILabel *subLbl = [[UILabel alloc] init];
    [rightViw addSubview:subLbl];
    subLbl.text = @"-";
    subLbl.tag = 300;
    [self setLblState:subLbl];
    [subLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.height.mas_offset(25 *SCALE_375);
        make.centerY.equalTo(rightViw.mas_centerY);
    }];
    [subLbl addTapgestureWithTarget:self action:@selector(changeMultiNumber:)];
    
    UILabel *addLbl = [[UILabel alloc] init];
    [rightViw addSubview:addLbl];
    addLbl.text = @"+";
    addLbl.tag = 400;
    [self setLblState:addLbl];
    [addLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(- 25 *SCALE_375);
        make.width.height.mas_offset(25 *SCALE_375);
        make.centerY.equalTo(rightViw.mas_centerY);
    }];
    [addLbl addTapgestureWithTarget:self action:@selector(changeMultiNumber:)];
    
    UILabel *multiLbl = [[UILabel alloc] init];
    [rightViw addSubview:multiLbl];
    multiLbl.text = @"倍";
    multiLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [multiLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(addLbl.mas_right).offset(2);
        make.centerY.equalTo(rightViw.mas_centerY);
    }];
    
    UITextField *multiTF = [[UITextField alloc] init];
    [rightViw addSubview:multiTF];
    _multiTF = multiTF;
    multiTF.backgroundColor = [UIColor whiteColor];
    multiTF.delegate = self;
    multiTF.keyboardType = UIKeyboardTypeNumberPad;
    multiTF.textAlignment = NSTextAlignmentCenter;
    multiTF.layer.borderColor = [UIColor lightGrayColor].CGColor;
    multiTF.layer.borderWidth = 1;
    multiTF.text = @"1";
    [multiTF mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(subLbl.mas_right).offset(-2 *SCALE_375);
        make.right.equalTo(addLbl.mas_left).offset(2 *SCALE_375);
        make.top.equalTo(subLbl.mas_top);
        make.bottom.equalTo(subLbl.mas_bottom);
    }];
}

- (void)setLblState:(UILabel *)lbl {
    lbl.backgroundColor = [UIColor whiteColor];
    lbl.textAlignment = NSTextAlignmentCenter;
    lbl.font = [UIFont systemFontOfSize:15 *SCALE_375];
    lbl.layer.masksToBounds = YES;
    lbl.layer.borderWidth = 1;
    lbl.layer.borderColor = [UIColor lightGrayColor].CGColor;
    lbl.layer.cornerRadius = 3 *SCALE_375;
}



- (void)changeMultiNumber:(UITapGestureRecognizer *)sender {
    if (sender.view.tag > 350) {
        _multiTF.text = @(_multiTF.text.integerValue + 1).stringValue;
    } else {
        _multiTF.text = @(_multiTF.text.integerValue - 1).stringValue;
    }
    if (_multiTF.text.integerValue < 1) {
        _multiTF.text = @"1";
    }
    self.changeBottomBlock();
}


- (void)showTypeViewAction:(UITapGestureRecognizer *)sender {
    self.showTypeViewBlock();
}


- (void)setChooseTypeStr:(NSString *)chooseTypeStr {
    
    if (!chooseTypeStr.length) {
        _chooseTypeLbl.text = @"请选择过关类型";
    } else {
        _chooseTypeLbl.text = chooseTypeStr;
    }
    _chooseTypeStr = chooseTypeStr;
    
}


- (void)textFieldDidEndEditing:(UITextField *)textField {
    self.changeBottomBlock();
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
