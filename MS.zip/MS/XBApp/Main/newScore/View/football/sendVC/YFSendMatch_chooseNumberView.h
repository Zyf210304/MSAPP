//
//  YFSendMatch_chooseNumberView.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/11.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFSendMatch_chooseNumberView : UIView

@property (nonatomic, strong) UITextField *multiTF;

@property (nonatomic, copy) void(^showTypeViewBlock)(void);

@property (nonatomic, copy) void(^changeBottomBlock)(void);


@property (nonatomic, strong) UILabel *chooseTypeLbl;
@property (nonatomic, strong) NSString *chooseTypeStr;


@end
