//
//  YFMatchScreenView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/29.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFMatchScreenView.h"

@interface YFMatchScreenView()



@end

@implementation YFMatchScreenView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.ChooseArr = [NSMutableArray array];
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
        [self addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    }
    return self;
}

- (void)initUI {
    
    NSInteger rowNumber = 0;
    if (_ScreenArr.count%3 == 0) {
        rowNumber = _ScreenArr.count / 3;
    } else {
        rowNumber = _ScreenArr.count / 3  + 1;
    }
     CGFloat height = 46 *rowNumber + 11 *SCALE_375 + (32  + 123 + 41) *SCALE_375;
    
    UIView *centerView = [[UIView alloc] init];
    [self addSubview:centerView];
    centerView.backgroundColor = Color_Base_BG;
    centerView.layer.masksToBounds = YES;
    centerView.layer.cornerRadius = 3.0;
    [centerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_offset(0);
        make.height.mas_offset(height);
    }];
    [centerView addTapgestureWithTarget:self action:@selector(nothing:)];
    

    [self initBottomView:centerView];
    [self addOddView:centerView];
    [self addTypeView:centerView];
}

- (void)initBottomView:(UIView *)centerView {
    UILabel *cancelLbl = [[UILabel alloc] init];
    [centerView addSubview:cancelLbl];
    cancelLbl.text = @"取消";
    cancelLbl.backgroundColor = [UIColor whiteColor];
    cancelLbl.textAlignment = NSTextAlignmentCenter;
    cancelLbl.textColor = Color_title_333;
    [cancelLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.mas_offset(0);
        make.width.mas_offset(FRAME_WIDTH /2 - 0.5);
        make.height.mas_offset(40 *SCALE_375);
    }];
    [cancelLbl addTapgestureWithTarget:self action:@selector(hiddenSelf:)];
    
    UILabel *sureLbl = [[UILabel alloc] init];
    [centerView addSubview:sureLbl];
    sureLbl.text = @"确定";
    sureLbl.backgroundColor = [UIColor whiteColor];
    sureLbl.textAlignment = NSTextAlignmentCenter;
    sureLbl.textColor = UIColorFromRGB(0xA94148);
    [sureLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.mas_offset(0);
        make.width.mas_offset(FRAME_WIDTH / 2 - 0.5);
        make.height.mas_offset(40 *SCALE_375);
    }];
    [sureLbl addTapgestureWithTarget:self action:@selector(trueAction:)];

}

- (void)addOddView:(UIView *)centerView {
    UILabel *titleLbl = [[UILabel alloc] init];
    [centerView addSubview:titleLbl];
    titleLbl.text = @"赔率筛选";
    titleLbl.textColor = Color_title_333;
    titleLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [titleLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(14 *SCALE_375);
        make.bottom.equalTo(self.mas_bottom).offset(- 132 *SCALE_375);
        make.height.mas_offset(32 *SCALE_375);
    }];
    
    
    UIView *OddView = [[UIView alloc] init];
    [centerView addSubview:OddView];
    OddView.backgroundColor = [UIColor whiteColor];
    [OddView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.mas_bottom).offset(-41 *SCALE_375);
        make.left.right.mas_offset(0);
        make.height.mas_offset(91 *SCALE_375);
    }];
    
    UIImageView *chooseImg = [[UIImageView alloc] init];
    [OddView addSubview:chooseImg];
    chooseImg.layer.masksToBounds = YES;
    chooseImg.layer.cornerRadius = 8 *SCALE_375;
    [chooseImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(19 *SCALE_375);
        make.top.mas_offset(17 *SCALE_375);
        make.width.height.mas_offset(16 *SCALE_375);
    }];
    chooseImg.tag = 333;
    
    UILabel *chooseLBl = [[UILabel alloc] init];
    [OddView addSubview:chooseLBl];
    [chooseLBl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(chooseImg.mas_top).offset(- 3 *SCALE_375);
        make.bottom.equalTo(chooseImg.mas_bottom).offset(3 *SCALE_375);
        make.left.equalTo(chooseImg.mas_left).offset(- 3 *SCALE_375);
        make.right.equalTo(chooseImg.mas_right).offset(3 *SCALE_375);
    }];
    chooseImg.image = [UIImage imageNamed:@"chooseBit_0"];
    [chooseImg addTapgestureWithTarget:self action:@selector(chooseMinOdd:)];
    
    UILabel *centerLbl = [[UILabel alloc] init];
    [OddView addSubview:centerLbl];
    centerLbl.text = @"赔率小于：";
    centerLbl.textColor = Color_title_333;
    centerLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [centerLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(chooseImg.mas_right).offset(7 *SCALE_375);
        make.centerY.equalTo(chooseImg.mas_centerY);
    }];
    
    UITextField *centerTF = [[UITextField alloc] init];
    [OddView addSubview:centerTF];
    self.centerTF = centerTF;
    centerTF.textAlignment = NSTextAlignmentCenter;
    centerTF.font = [UIFont systemFontOfSize:14 *SCALE_375];
    centerTF.textColor = Color_title_333;
    centerTF.text = @"1.5";
    centerTF.keyboardType = UIKeyboardTypeDecimalPad;
    centerTF.layer.masksToBounds = YES;
    centerTF.layer.borderWidth = 1;
    centerLbl.layer.cornerRadius = 2;
    centerTF.layer.borderColor = UIColorFromRGB(0xE5E5E5).CGColor;
    [centerTF mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(centerLbl.mas_right).offset(9 *SCALE_375);
        make.width.mas_offset(63 *SCALE_375);
        make.height.mas_offset(22 *SCALE_375);
        make.centerY.equalTo(centerLbl.mas_centerY);
    }];
    
    
    UILabel *bottomLbl = [[UILabel alloc] init];
    [OddView addSubview:bottomLbl];
    bottomLbl.textColor = Color_title_333;
    bottomLbl.text = @"赔率筛选范围";
    bottomLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [bottomLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(19 *SCALE_375);
        make.top.equalTo(chooseImg.mas_bottom).offset(17 *SCALE_375);
    }];
    
    UILabel *desLbl = [[UILabel alloc] init];
    [OddView addSubview:desLbl];
    desLbl.textColor = Color_title_333;
    desLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    desLbl.numberOfLines = 0;
    desLbl.text = @"足球 胜平负/让球胜平负 \n篮球 胜负/让分胜负";
    [desLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(bottomLbl.mas_right).offset(6 *SCALE_375);
        make.top.equalTo(bottomLbl.mas_top);
    }];
    
    
}

- (void)addTypeView:(UIView *)centerView {
    NSInteger rowNumber = 0;
    if (_ScreenArr.count%3 == 0) {
        rowNumber = _ScreenArr.count / 3;
    } else {
        rowNumber = _ScreenArr.count / 3  + 1;
    }
    
    CGFloat height = 46 *rowNumber + 11 *SCALE_375;
    UIView *TypeView = [[UIView alloc] init];
    [centerView addSubview:TypeView];
    TypeView.backgroundColor = [UIColor whiteColor];
    [TypeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(height);
        make.bottom.equalTo(centerView.mas_bottom).offset(- 164 *SCALE_375);
    }];
    
    for (int i = 0; i < rowNumber; i++) {
        for (int j = 0; j < 3; j ++) {
            if (i * 3 + j >= _ScreenArr.count) {
                break;
            }
            
            UILabel *typeLbl = [[UILabel alloc] init];
            [TypeView addSubview:typeLbl];
            typeLbl.textColor = Color_title_333;
            typeLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
            typeLbl.layer.masksToBounds = YES;
            typeLbl.layer.cornerRadius = 3 *SCALE_375;
            typeLbl.layer.borderColor = UIColorFromRGB(0xE5E5E5).CGColor;
            typeLbl.layer.borderWidth = 1;
            typeLbl.backgroundColor = [UIColor whiteColor];
            typeLbl.text = @"国际赛";
            typeLbl.text = _ScreenArr[i * 3 + j];
            typeLbl.textAlignment = NSTextAlignmentCenter;
            typeLbl.numberOfLines = 0;
            typeLbl.tag = 200+ i * 3 + j;
            [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(10 *SCALE_375 + 123 *SCALE_375 * j);
                make.width.mas_offset(111 *SCALE_375);
                make.height.mas_offset(35 *SCALE_375);
                make.top.mas_offset(11 *SCALE_375 + 45 *SCALE_375 * i);
            }];
            
            [typeLbl addTapgestureWithTarget:self action:@selector(typeDidChangeState:)];
        }
    }
    
    
    UILabel *topLbl = [[UILabel alloc] init];
    [centerView addSubview:topLbl];
    topLbl.text = @"赛事筛选";
    topLbl.textColor = Color_title_333;
    topLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [topLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(14 *SCALE_375);
        make.top.mas_offset(0);
        make.height.mas_offset(32 *SCALE_375);
    }];
    
    UILabel *cleanLbl = [[UILabel alloc] init];
    [centerView addSubview:cleanLbl];
    cleanLbl.text = @"清空";
    cleanLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    cleanLbl.textAlignment = NSTextAlignmentCenter;
    cleanLbl.textColor = UIColorFromRGB(0xA94148);
    [cleanLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.mas_offset(0);
        make.height.mas_offset(32 *SCALE_375);
        make.width.mas_offset(56 *SCALE_375);
    }];
    [cleanLbl addTapgestureWithTarget:self action:@selector(clearAction:)];
}




//lbl 被点击
- (void)typeDidChangeState:(UITapGestureRecognizer *)sender {
    
    UILabel *currentLbl = (UILabel *)sender.view;
    
    if ([self.ChooseArr containsObject:currentLbl.text]) {
        [self.ChooseArr removeObject:currentLbl.text];
    } else {
        [self.ChooseArr addObject:currentLbl.text];
    }
    BOOL isSelect = [self.ChooseArr containsObject:currentLbl.text];
    
    [self lableState:currentLbl isSelect:isSelect];

    
}


// 改变字符串状态
- (void)lableState:(UILabel *)contenLbl isSelect:(BOOL)isSelect {
    
    contenLbl.textColor = isSelect ? [UIColor whiteColor] : Color_title_333;
    contenLbl.backgroundColor = isSelect ? [UIColor redColor] : [UIColor whiteColor];
}


- (void)trueAction:(UITapGestureRecognizer *)sender {
    self.hidden = YES;
    self.trueBlock();
}


- (void)nothing:(UITapGestureRecognizer *)sender {
    NSLog(@"");
}

- (void)hiddenSelf:(UITapGestureRecognizer *)sender {
//    self.trueBlock();
    self.hidden = YES;
}


- (void)chooseMinOdd:(UITapGestureRecognizer *)sender {
    _minOddIsChoose = !_minOddIsChoose;
    UIImageView *chooseImg = [self viewWithTag:333];
    chooseImg.image = _minOddIsChoose ? [UIImage imageNamed:@"chooseBit_1"] : [UIImage imageNamed:@"chooseBit_0"];
}



- (void)clearAction:(UITapGestureRecognizer *)sender {
    [_ChooseArr removeAllObjects];
    for (int i = 0; i < _ScreenArr.count; i ++) {
        UILabel *typeLbl = [self viewWithTag:200 + i];
        
        [self lableState:typeLbl isSelect:NO];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
