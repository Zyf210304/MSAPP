//
//  YFMatchScreenView.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/29.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFMatchScreenView : UIView

@property (nonatomic, copy) void(^trueBlock)(void);

@property (nonatomic, strong) NSMutableArray *ChooseArr;

@property (nonatomic, strong) NSMutableArray *ScreenArr;

- (void)initUI;

@property (nonatomic) BOOL minOddIsChoose;

@property (nonatomic)  UITextField *centerTF;
@end
