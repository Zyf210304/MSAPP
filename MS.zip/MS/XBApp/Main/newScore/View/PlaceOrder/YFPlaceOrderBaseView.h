//
//  YFPlaceOrderBaseView.h
//  XBApp
//
//  Created by 张亚飞 on 2018/10/13.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    
    Base_Lbl,
    
    Base_Swith,
    
    Base_Choose,
    
    Base_TF,
}BaseType;

@interface YFPlaceOrderBaseView : UIView

@property (nonatomic, strong) UISwitch *swith;

- (void)setUIWith:(BaseType)baseType;

- (void)setValueWithLeftStr:(NSString *)leftLblStr  addRightLblStr:(NSString *)rightLblStr;

@property (nonatomic, strong) UILabel *leftLbl;

@property (nonatomic, strong) UILabel *rightLbl;

@property (nonatomic, strong) UILabel *later;

@property (nonatomic, strong) UILabel *now;

@property (nonatomic, strong) UITextField *centerTF;

@property (nonatomic, strong) NSNumber *privacy_setting;

@end
