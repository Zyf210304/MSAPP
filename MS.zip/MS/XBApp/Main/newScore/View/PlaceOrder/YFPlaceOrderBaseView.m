//
//  YFPlaceOrderBaseView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/10/13.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFPlaceOrderBaseView.h"

@interface YFPlaceOrderBaseView()


@end

@implementation YFPlaceOrderBaseView


- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _privacy_setting = @0;
    }
    return self;
}

- (void)setUIWith:(BaseType)baseType {
    [self initUI];
    switch (baseType) {
        case Base_Lbl:
            [self addRightLblUI];
            break;
        case Base_Swith:
            [self addSwithUI];
            break;
        case Base_Choose:
            [self addSettingLbl];
            break;
        case Base_TF:
            [self addCenterTF];
            break;
        default:
            break;
    }
    
}


- (void)initUI {
    UILabel *leftlbl = [[UILabel alloc] init];
    [self addSubview:leftlbl];
    _leftLbl = leftlbl;
    leftlbl.textColor = Color_title_333;
    leftlbl.text = @"方案金额:";
    leftlbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [leftlbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(10 *SCALE_375);
        make.top.bottom.mas_offset(0);
    }];
    
    UIView *lineView = [[UIView alloc] init];
    [self addSubview:lineView];
    lineView.backgroundColor = UIColorFromRGB(0xe5e5e5);
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_offset(0);
        make.height.mas_offset(SCALE_375);
        make.left.mas_offset(0 *SCALE_375);
        make.right.mas_offset(- 0 *SCALE_375);
    }];
    
}

- (void)addRightLblUI {
    UILabel *rightLbl = [[UILabel alloc] init];
    [self addSubview:rightLbl];
    _rightLbl = rightLbl;
    rightLbl.textColor = Color_title_333;
    rightLbl.text = @"单倍2元";
    rightLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [rightLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-10 *SCALE_375);
        make.top.bottom.mas_offset(0);
    }];
}

- (void)addSwithUI {
    UISwitch *swith = [[UISwitch alloc] init];//WithFrame:CGRectMake(0, 0, 100 *SCALE_375, 70 *SCALE_375)];
    _swith = swith;
    swith.on = YES;
    [self addSubview:swith];
    [swith mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-15 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
    }];
    [swith addTarget:self action:@selector(changeSwithState:) forControlEvents:UIControlEventValueChanged];
}

- (void)addCenterTF {
    [self addSwithUI];
    
    UITextField *centerTF = [[UITextField alloc] init];
    [self addSubview:centerTF];
    _centerTF = centerTF;
    centerTF.font = [UIFont systemFontOfSize:13 *SCALE_375];
    centerTF.textColor = Color_title_333;
    centerTF.text = @"1.2";
    centerTF.textAlignment = NSTextAlignmentCenter;
    centerTF.keyboardType = UIKeyboardTypeDecimalPad;
    centerTF.layer.masksToBounds = YES;
    centerTF.layer.cornerRadius = 4;
    centerTF.layer.borderColor = [UIColor lightGrayColor].CGColor;
    centerTF.layer.borderWidth = 1;
    [centerTF mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_leftLbl.mas_right).offset(10 *SCALE_375);
        make.width.mas_offset(100 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
        make.height.mas_offset(28 *SCALE_375);
    }];
    
}

- (void)addSettingLbl {
    
    UILabel *later = [[UILabel alloc] init];
    [self addSubview:later];
    _later = later;
    later.tag = 300;
    later.text = @"开赛可见";
    later.textAlignment = NSTextAlignmentCenter;
    later.layer.masksToBounds = YES;
    later.cornerRadius = 4;
    later.layer.borderWidth = 1;
    later.textColor = [UIColor whiteColor];
    later.backgroundColor = [UIColor redColor];
    later.layer.borderColor = Color_Base_BG.CGColor;
    later.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [later mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_leftLbl.mas_right).offset(14 *SCALE_375);
        make.width.mas_offset(89 *SCALE_375);
        make.height.mas_offset(28 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    UILabel *now = [[UILabel alloc] init];
    [self addSubview:now];
    later.tag = 400;
    _now = now;
    now.text = @"公开";
    now.textAlignment = NSTextAlignmentCenter;
    now.layer.masksToBounds = YES;
    now.cornerRadius = 4;
    now.layer.borderWidth = 1;
    now.layer.borderColor = Color_Base_BG.CGColor;
    now.backgroundColor = [UIColor whiteColor];
    now.textColor = Color_title_333;
    now.font = [UIFont systemFontOfSize:13 *SCALE_375];
    [now mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(later.mas_right).offset(14 *SCALE_375);
        make.width.mas_offset(89 *SCALE_375);
        make.height.mas_offset(28 *SCALE_375);
        make.centerY.equalTo(self.mas_centerY);
    }];
    [later addTapgestureWithTarget:self action:@selector(changeOpenState:)];
    [now addTapgestureWithTarget:self action:@selector(changeOpenState:)];
}


- (void)changeOpenState:(UITapGestureRecognizer *)sender {
    UILabel *selectLbl = (UILabel *)sender.view;
    BOOL isChooseNow = selectLbl.tag > 350;
    _privacy_setting = isChooseNow ? @1 : @0;
    _later.textColor = isChooseNow ? [UIColor whiteColor] : Color_title_333;
    _later.backgroundColor = isChooseNow ? [UIColor redColor] : [UIColor whiteColor];
    _now.textColor = !isChooseNow ? [UIColor whiteColor] : Color_title_333;
    _now.backgroundColor = !isChooseNow ? [UIColor redColor] : [UIColor whiteColor];
}


- (void)changeSwithState:(UISwitch *)sender {
   sender.on = !sender.isOn;
}


- (void)setValueWithLeftStr:(NSString *)leftLblStr addRightLblStr:(NSString *)rightLblStr {
    _leftLbl.text = leftLblStr;
    if (rightLblStr) {
        _rightLbl.text = rightLblStr;
    }
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
