//
//  XBScoreViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/6.
//Copyright © 2018 stephen. All rights reserved.
//

#import "XBScoreViewController.h"

@interface XBScoreViewController ()

@end

@implementation XBScoreViewController
{
    DGridView * grid;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"";
}

-(void)initUI {
    [self initScrollView];
    [self setRefreshScrollView];
    
    grid = [[DGridView alloc]initWidth:APP_WIDTH];
    
    [grid setColumn:16 height:50];
    
    [self.scrollview addSubview:grid];
    [self.scrollview autoContentSize];
    
}

-(void)initData{
    //[self firstGetData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.tabBarController.navigationItem.leftBarButtonItem=nil;
    
    self.tabBarController.navigationItem.rightBarButtonItem=nil;
    
    self.tabBarController.navigationItem.title=@"比分";
}

#pragma mark - json

- (void)commonJson {
    

}


@end
