//model

//每个比赛选中的个数
var privateMapData = new Map()

var page = 15;

var scrollTop = 0;

var isNext = 0;

var chuangArray;

function addData(row, data) {
	if(privateMapData[row]) {} else {
		privateMapData[row] = new Array()
	}
	var array = privateMapData[row];

	array.push(data);

	privateMapData[row] = array;

}

function removeData(row, data) {
	var array = privateMapData[row]
	var index = array.indexOf(data);
	if(index > -1) {
		array.splice(index, 1);
	}
	privateMapData[row] = array;
}

// 配置选择类型
var leastSelectNum = 1;

// 总共选中的item
var sum = 0;

//每个比赛选中的个数
var mapObj = new Map()

var mapModeObj = new Map();

//胆选中的个数
var mapObjdan = new Map()

//弹出窗口

function showDialog(row) {
	$('.maskLayer').show();
	$('.dialog').show();

	$(".maskLayer").attr("title", row);

	updateTabelData(row);

	$(".needHide").hide();
}

function hideDialg() {
	$(".needHide").show();
	$('.maskLayer').hide();
	$('.dialog').hide();

	$('html, body').animate({
		scrollTop: scrollTop
	}, 0);

}

function initTip(num) {

	var string = "至少选择<span style='color: red;'>" + num + "</span>比赛"

	$('.completely_num').html(string);

}

function hideUnselectTable() {
	$('.gridtable').hide();

	$.each(mapObj, function(key, value) {

		if(value > 0) {
			var classKey = 'table:eq(' + key + ')';

			$(classKey).show();
		}

	});

	$('html, body').animate({
		scrollTop: 0
	}, 0);

}

function showAllTable() {
	$('.gridtable').show();
}

//选中几个比赛
function getSelectRowNums() {

	var tempSum = 0;
	$.each(mapObj, function(key, value) {

		if(value > 0) {
			tempSum++;
		}

	});

	return tempSum;
}

//注数
function countZun() {

	var data = new Array();

	$.each(mapObj, function(key, value) {

		data.push(value);

	});

	var tempSum = count(data, chuangArray);

	return tempSum;
}

//倍数
function beishu() {
	var value = $('.input-num').val();

	return value;
}

//支付金额
function countMoney() {

	return countZun() * 2 * beishu();
}

function setChuang(string, array) {

	chuangArray = array;
	$('.chuang').html(string);
	countZun();
	cal();

}

function calAward() {

	// 最小串  ， 最大串
	var maxc = 0;
	var minc = 1000;
	$.each(chuangArray, function(key, value2) {

		if(value2 > maxc) {
			maxc = value2;
		}

		if(value2 < minc) {
			minc = value2;
		}

	});

	var minArray = new Array();
	var MaxArray = new Array();

	$.each(privateMapData, function(key, value) {

		var max = 0;
		var min = 1000;
		$.each(value, function(key, value2) {

			var odd = $('<div>' + value2 + '</div>').find("span").html();

			var l = 1;

			if(odd * l > max) {
				max = odd * l;
			}

			if(odd * l < min) {
				min = odd * l;
			}

		});

		minArray.push(min);
		MaxArray.push(max);

	});

	minArray = minArray.sort()

	var minMoney = 1;

	for(var i = 0; i < minc; i++) {
		minMoney = minArray[i] * minMoney;
	}
	minMoney = minMoney * 2 * beishu();

	
	var allMaxMoney = 0;
	$.each(chuangArray, function(key, value2) {
		var arraychoose = choose(MaxArray, value2);
		$.each(arraychoose, function(key, arraychooseItems) {
			var maxMoney = 1;
			for(var i = 0; i < arraychooseItems.length; i++) {
				maxMoney = arraychooseItems[i] * maxMoney;
			}
			maxMoney = maxMoney * 2 * beishu();

			allMaxMoney = allMaxMoney + maxMoney;
		});
	});


	return minMoney.toFixed(2) + '-' + allMaxMoney.toFixed(2);
}

//计算注数和奖金
function cal() {

	if($('.chuang').html()) {

	} else {
		$('.chuang').html(getSelectRowNums() + "串1");
	}

	var t = countZun();

	var string = "<span style='color: red;'>" + countZun() + "</span>注<span style='color: red;'>" + beishu() +
		"</span>倍 共<span style='color: red;'>" + countMoney() + "</span>元";

	$('.completely_num2').html(string);

	var string2 = "预计奖金：" + calAward() + "元";

	$('.tip2').html(string2);

}

$(function() {

	var num_jia = document.getElementById("num-jia");
	var num_jian = document.getElementById("num-jian");
	var input_num = document.getElementById("input-num");

	$('.input-num').val(1);

	num_jia.onclick = function() {

		input_num.value = parseInt(input_num.value) + 1;

		cal();
	}

	num_jian.onclick = function() {

		if(input_num.value <= 1) {
			input_num.value = 1;
		} else {

			input_num.value = parseInt(input_num.value) - 1;
		}
		cal();

	}

	$('.chuang').click(function() {
		var v = getSelectRowNums();
		showChuang(v);

	});

	$('.leftbtn1').click(function() {

		var btns = $('.row_red');

		btns.each(function(i, btn) {

			if($(this).hasClass('itemSelect')) {

				$(this).removeClass('row_red');
				$(this).addClass('row_white');

			}

			sum == 0;
			mapObj = new Map();
			privateMapData = new Map();

			// 当前table
			var itemTable = $(this).parent().parent().parent();

			//当前row
			var rowNum = itemTable.attr("way-scope");

			$('.sumrow').html("展开全部")
		})

	})

	$('.next1').click(function() {

		if(getSelectRowNums() < leastSelectNum) {
			// 选择需要大于两个

			return;
		}

		isNext = 1;
		$('.head_show').hide();
		$('.dan').show();

		$('foot1').hide();
		$('.foot2').show();

		$('.head_time').hide();

		hideUnselectTable();

		if(!chuangArray) {
			chuangArray = [getSelectRowNums()];
			setChuang(getSelectRowNums() + '串1', chuangArray);
		}

	})

	$('.leftbtn2').click(function() {
		//上一步
		$('.head_show').show();
		$('.dan').hide();

		$('foot1').show();
		$('.foot2').hide();

		$('.head_time').show();

		showAllTable();

		hideDialg()

		isNext = 0;

	})

	$('.next2').click(function() {

		//购买
		var buy_amount = countMoney();
		var mulriple = beishu();
		var pass_way = $('.chuang').text();
		buyMthod(privateMapData, buy_amount, mulriple, pass_way);
	})

});

function pageData(pageNum) {
	var array = data.slice(0, pageNum * page)

	way.set("data.list", array);

	initClick()

	initDataShowTable();
}

function initPageScroll() {
	var count = 1;
	$(window).scroll(function() {

		if(isNext == 1) {
			return;
		}

		var scrollTop = $(this).scrollTop(); //滚动条距离顶部的高度
		var scrollHeight = $(document).height(); //当前页面的总高度
		var clientHeight = $(this).height(); //当前可视的页面高度

		if(scrollTop + clientHeight >= scrollHeight) {

			count++;
			pageData(count);

		} else if(scrollTop <= 0) {
			//滚动条距离顶部的高度小于等于0 TODO
		}
	});
}

function initClick() {

	$('.dan').unbind('click').click(function() {
		// 当前table
		var itemTable = $(this).parent().parent().parent();

		//当前row
		var rowNum = itemTable.attr("way-scope");

		if(mapObj[rowNum]) {

		} else {
			mapObjdan[rowNum] = 0;
		}

		if($(this).hasClass('row_white')) {
			$(this).removeClass('row_white');
			$(this).addClass('row_red');

			mapObjdan[rowNum] = mapObjdan[rowNum] + 1;

		} else {
			$(this).removeClass('row_red');
			$(this).addClass('row_white');

			mapObjdan[rowNum] = mapObjdan[rowNum] - 1;
		}

	})

	$('.itemSelect').unbind('click').click(function() {

                                           
        var odd =  $(this).find('span').html();
               
         if (!odd)
          {
            alert('不可选择');
                                           
              return;
          }
                                           
		// 当前table
		var itemTable = $(this).parent().parent().parent();

		var tableValue = itemTable.attr('title');

		var rowNum = itemTable.attr("way-scope");

		if(typeof(tableValue) != "undefined") {
			rowNum = tableValue;
		} else {
			//当前row
			rowNum = itemTable.attr("way-scope");
		}

		if(mapObj[rowNum]) {

		} else {
			mapObj[rowNum] = 0;
		}

		var oddContent = $(this).html();

		if($(this).hasClass('row_white')) {
			$(this).removeClass('row_white');
			$(this).addClass('row_red');
			sum++;

			mapObj[rowNum] = mapObj[rowNum] + 1;

			addData(rowNum, oddContent);

		} else {
			$(this).removeClass('row_red');
			$(this).addClass('row_white');

			sum--;

			mapObj[rowNum] = mapObj[rowNum] - 1;

			removeData(rowNum, oddContent)

		}

		//当前下按钮
		var classNum = ".sumrow:eq(" + rowNum + ")";
		if(mapObj[rowNum] == 0) {
			$(classNum).html("展开全部")

		} else {
			$(classNum).html("已选" + mapObj[rowNum] + "项")

		}

		if(sum == 0) {
			$('.completely_num').html("至少选择<span style='color: red;'>" + leastSelectNum + "</span>比赛");
		} else {

			$('.completely_num').html("已选<span style='color: red;'>" + getSelectRowNums() + "</span>场")

		}

		cal();

	})

	$('.btnDialog').unbind('click').click(function() {

		scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
		var num = $(this).attr("title");
		showDialog(num);
		// 设置初始值
		initDataShowDialogTable(num);
	})

	$('.dialog_cancel').unbind('click').click(function() {

		hideDialg()
	})

	$('.dialog_ok').unbind('click').click(function() {
		// 当前table
		hideDialg()
		var itemTable = $(this).parent().parent().parent();
		var value = itemTable.attr('title');
		var select = '.btnDialog[title=' + value + ']';
		var array = privateMapData[value];

		if(array) {

			var stringHtml = ""

			if($(select).hasClass('allbtn')) {
				stringHtml = '已选' + array.length + '项';
			} else

			{
				for(var i = 0; i < array.length; i++) {
					// .replace('<.+?>', '')
					var temp = array[i];

					//temp=temp.replace(/<[^>]+>/g,"")
					temp = temp.replace(/<br\s*\/?>/g, "[");
					temp += "] "
					stringHtml += temp;
				}
			}

			if(array.length > 0) {
				$(select).html(stringHtml)
				if($(select).hasClass('row_white')) {
					$(select).removeClass('row_white');
					$(select).addClass('row_red');
				}
			} else {
				if($(select).hasClass('row_red')) {
					$(select).removeClass('row_red');
					$(select).addClass('row_white');
				}
			}

		}

	})

}

//弹窗数据显示
function initDataShowDialogTable(row) {

	//初始化
	$(".maskLayer .itemSelect").each(function(i, td) {
		if($(this).hasClass('row_red')) {
			$(this).removeClass('row_red');
			$(this).addClass('row_white');
		}
	});

	var array = privateMapData[row];
	if(array) {

		$(".maskLayer .itemSelect").each(function(k, td) {
			var itemString = $(this).html();
			//选中的td
			for(var i = 0; i < array.length; i++) {
				if(itemString === array[i]) {
					if($(this).hasClass('row_white')) {
						$(this).removeClass('row_white');
						$(this).addClass('row_red');
					}
				}
			}
		});

	}

}

//主表格数据显示
function initDataShowTable() {

	$(".datatable .itemSelect").each(function(k, td) {
		var itemString = $(this).html();

		// 当前table
		var itemTable = $(this).parent().parent().parent();

		var tableValue = itemTable.attr('title');

		var rowNum = itemTable.attr("way-scope");

		var array = privateMapData[rowNum];

		if(array) {
			//选中的td
			for(var i = 0; i < array.length; i++) {
				if(itemString === array[i]) {
					if($(this).hasClass('row_white')) {
						$(this).removeClass('row_white');
						$(this).addClass('row_red');
					}
				}
			}
		}

	});

}

//组合
function choose(arr, size) {
	var allResult = [];
	(function(arr, size, result) {
		var arrLen = arr.length;
		if(size > arrLen) {
			return;
		}
		if(size == arrLen) {
			allResult.push([].concat(result, arr))
		} else {
			for(var i = 0; i < arrLen; i++) {
				var newResult = [].concat(result);
				newResult.push(arr[i]);

				if(size == 1) {
					allResult.push(newResult);
				} else {
					var newArr = [].concat(arr);
					newArr.splice(0, i + 1);
					arguments.callee(newArr, size - 1, newResult);
				}
			}
		}
	})(arr, size, []);
	return allResult;
}

// 计算n串1 的注数
function showResult(result) {
	console.log('The number of result sets: ' + result.length);

	var sum = 0;

	for(var i = 0, len = result.length; i < len; i++) {

		//串
		console.log(result[i]);
		var temp = 1;
		var arraylist = result[i];
		for(var k = 0; k < arraylist.length; k++) {
			temp = temp * arraylist[k];
		}
		sum = sum + temp;
		console.log(sum);
	}
	console.log(sum);
	return sum;
}

// 计算 m 个 n串1 的注数
function count(result, array) {

	var sum = 0;
	if(!array) {
		return 0;
	}

	for(var i = 0; i < array.length; i++) {
		sum = sum + showResult(choose(result, array[i]));

	}

	return sum;
}
