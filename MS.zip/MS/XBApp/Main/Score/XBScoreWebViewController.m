//
//  XBScorewebViewController.m
//  MSApp
//
//  Created by stephen on 2018/9/23.
//Copyright © 2018年 stephen. All rights reserved.
//

#import "XBScoreWebViewController.h"
#import <JavaScriptCore/JSContext.h>
#import <JavaScriptCore/JSValue.h>
#import "TFHpple.h"

@interface XBScoreWebViewController ()<UIWebViewDelegate>

@property (strong, nonatomic) IBOutlet DWrapView *wrap;
@property (strong, nonatomic) IBOutlet UIButton *Button;
@property (strong, nonatomic) IBOutlet UIView *customViews;

@property (strong, nonatomic) IBOutlet UIView *showView2;
@property (weak, nonatomic) IBOutlet DWrapView *wrap2;

@property (weak, nonatomic) IBOutlet UIButton *btnok;
@property (weak, nonatomic) IBOutlet UIButton *btncancel;


@end

@implementation XBScoreWebViewController
{
    
    NSMutableArray * dataSource;
    JSContext * context;
    UIWebView * webView;
    
    
    NSArray * web1Data;
    
    NSArray * web2Data;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView=self.Button;
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self setWhiteNavigation];
}

-(void)initUI{
    
    webView=[[UIWebView alloc]init];
    webView.delegate=self;
    webView.scrollView.bounces=NO;
    
    [self addCenterView:webView];
    
    
    self.wrap.width=APP_WIDTH;
    [self.wrap setColumn:3];
    
    NSArray * data=@[@"胜负平",@"让球胜负平",@"比分",@"总进球",@"半全场",@"混投2选1",@"混合过关",@"单关"];
    
    if (self.type==0) {
        data=@[@"胜负平",@"让球胜负平",@"比分",@"总进球",@"半全场",@"混投2选1",@"混合过关",@"单关"];
    }
    else
    {
        data=@[@"胜负",@"让球胜负",@"胜分差",@"大小分",@"混合过关",@"单关"];
    }
    
    web1Data=@[@"shengpingfu",@"rangqiu",@"bifen",@"zongjinqiu",@"banquanchang",@"huntou",@"menghunguoguan",@"dangguan"];
    
    web2Data=@[@"",@"",@"",@"",@"",@"",@"",@"",@""];
    
    int k =0;
    
    for (NSString * string in data) {
        
        UIButton * btn=[UIButton buttonWithType:UIButtonTypeCustom];
        
        [btn setTitle:string forState:UIControlStateNormal];
        btn.titleLabel.font=[UIFont systemFontOfSize:12];
        [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        btn.backgroundColor=[UIColor whiteColor];
        btn.borderColor=[UIColor lightGrayColor];
        btn.borderWidth=1;
        btn.tag=k;
        
        [btn click:^(id control) {
            for (UIButton * item in self.wrap.subviews) {
                
                [item setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                item.backgroundColor=[UIColor whiteColor];
                item.borderColor=[UIColor lightGrayColor];
                item.borderWidth=1;
            }
            
            btn.borderColor=[UIColor lightGrayColor];
            btn.borderWidth=0;
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            btn.backgroundColor=[Theme themeColor];
            [self.Button setTitle:btn.titleLabel.text forState:UIControlStateNormal];
            
            [self hideCustomHUB];
            
            if (self.type==0) {
                NSString *path = [[NSBundle mainBundle] pathForResource:web1Data[btn.tag] ofType:@"html"];
                
                [webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]]];
                
                
            }
            else
            {
                NSString *path = [[NSBundle mainBundle] pathForResource:web2Data[btn.tag] ofType:@"html"];
                
                [webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]]];
            }
            
            
        }];
        [self.wrap addView:btn margin:UIEdgeInsetsMake(10, 10, 10, 10)];
        
        k++;
        
    }
    
    [ self.wrap.subviews[6] setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    ((UIButton *) self.wrap.subviews[6]).backgroundColor=[Theme themeColor];
    ((UIButton *) self.wrap.subviews[6]).borderColor=[UIColor lightGrayColor];
    ((UIButton *) self.wrap.subviews[6]).borderWidth=0;
    
    [self.Button click:^(id control) {
        
        self.customViews.height=self.view.height;
        self.customViews.width=APP_WIDTH;
        [self showCustomHUD:self.customViews];
        
    }];
    
    
    
    
}

-(void)initData{
    [self firstGetData];
}


-(void)showDialog:(NSString *)string{
    
    self.wrap2.width=APP_WIDTH;
    [self.wrap2 setColumn:3];
    
    [self.wrap2 clearSubviews];
    
    NSString * str =  string;
    
    NSMutableArray * data=[NSMutableArray new];
    //2
    for (int i=1; i<= str.intValue ; i++) {
        
        if (string.intValue>1&&i==1) {
            
        }
        else{
            [data addObject:[NSString stringWithFormat:@"%d串1",i]];
        }
        
        
    }
    
    
    
    
    int k =2;
    for (NSString * string in data) {
        
        UIButton * btn=[UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:string forState:UIControlStateNormal];
        btn.titleLabel.font=[UIFont systemFontOfSize:12];
        [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        btn.backgroundColor=[UIColor whiteColor];
        btn.borderColor=[UIColor lightGrayColor];
        btn.borderWidth=1;
        btn.tag=k;
        
        [btn clickOn:^(id control) {
            btn.borderColor=[UIColor lightGrayColor];
            btn.borderWidth=0;
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            btn.backgroundColor=[Theme themeColor];
            
        } off:^(id control) {
            [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            btn.backgroundColor=[UIColor whiteColor];
            btn.borderColor=[UIColor lightGrayColor];
            btn.borderWidth=1;
        }];
        [self.wrap2 addView:btn margin:UIEdgeInsetsMake(10, 10, 10, 10)];
        k++;
    }
    
    
    [self.btnok click:^(id control) {
        
        
        NSMutableArray * temp =[NSMutableArray new];
        
        NSMutableArray * temp2=[NSMutableArray new];
        int k=0;
        for (UIButton * btn in self.wrap2.subviews) {
            if (btn.selected) {
                [temp addObject:data[k]];
                
                [temp2 addObject:@(btn.tag)];
            }
            
            k++;
        }
        
        NSString * chuang= [NSString stringWithFormat:@"setChuang('%@',%@)",[temp componentsJoinedByString:@","],temp2];
        
        [webView stringByEvaluatingJavaScriptFromString:chuang];
        
        [self hideCustomHUB];
    }];
    
    [self.btncancel click:^(id control) {
        [self hideCustomHUB];
    }];
    
    self.showView2.height=self.view.height;
    self.showView2.width=APP_WIDTH;
    [self showCustomHUD:self.showView2];
    
}



#pragma mark - delegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    
    [self showHUD];
    return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    context =  [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    // 给JS变量赋值
    context[@"data"] = dataSource;
    // 给JS方法赋值
    
    context[@"showChuang"] = ^(){
        NSArray *args= [JSContext currentArguments];
        
        dispatch_async(dispatch_get_main_queue(), ^(void) {
            [self showDialog:((JSValue *)args[0]).toString];
        });
    };
    
    
    context[@"buyMthod"] = ^(){
        
        dispatch_async(dispatch_get_main_queue(), ^(void) {
            
            [self showHUD];
        });
        
        
        NSArray *args= [JSContext currentArguments];
        
        
        NSDictionary * dic =   [args.firstObject toDictionary];
        
        NSMutableArray * arraysubmit=[NSMutableArray new];
        
        for (NSString * key in dic.allKeys) {
            NSArray * array= dic[key];
            for (NSString * odd in array) {
                
                NSMutableDictionary *temp=[NSMutableDictionary new ];
                NSDictionary * oldData = dataSource[key.intValue];
                
                NSData *data =[odd dataUsingEncoding:NSUTF8StringEncoding];
                
                TFHpple *Hpple = [[TFHpple alloc]initWithHTMLData:data];
                
                NSArray *span_array =  [Hpple searchWithXPathQuery:@"//span"];
                
                NSString * odd_fenshu =((TFHppleElement *)span_array.firstObject).content;
                
                //
                temp[@"odd"] = ((TFHppleElement *)span_array.firstObject).content;
                temp[@"away"] = oldData[@"away"];
                temp[@"bet_content"] = oldData[@"bet_content"];
                temp[@"event"] = oldData[@"event"];
                
                //0，足球胜负平；1，足球让球；2，足球比分，3，足球进球；4，足球半全场；
                
                NSString * pin_type = [odd componentsSeparatedByString:@"\n"].firstObject;
                
                NSInteger game_type=0;
                
                if ([pin_type isEqualToString:@"胜"]
                    ||
                    [pin_type isEqualToString:@"负"]
                    ||
                    [pin_type isEqualToString:@"平"]) {
                    game_type=0;
                    if ([oldData[@"spfList"] containsObject:odd_fenshu]) {
                        game_type=0;
                    }
                    else
                    {
                        game_type=1;
                    }
                }
                else if (([pin_type containsString:@"胜"]
                          ||
                          [pin_type containsString:@"负"]
                          ||
                          [pin_type containsString:@"平"])
                         &&
                         pin_type.length==2)
                {
                    game_type=4;
                }
                else if ([pin_type isEqualToString:@"0"]||
                         [pin_type isEqualToString:@"1"]||
                         [pin_type isEqualToString:@"2"]||
                         [pin_type isEqualToString:@"3"]||
                         [pin_type isEqualToString:@"4"]||
                         [pin_type isEqualToString:@"5"]||
                         [pin_type isEqualToString:@"6"]||
                         [pin_type isEqualToString:@"7+"]
                         )
                {
                    game_type=3;
                }
                else if ([pin_type containsString:@":"]||
                         [pin_type containsString:@"其他"])
                {
                    game_type=2;
                }


                
                temp[@"game_type"]=@(game_type);
                temp[@"home"]=oldData[@"home"];
                temp[@"issue"]=oldData[@"issue"];
                temp[@"issue_num"]=oldData[@"issue_num"];
                temp[@"matchtime"]=oldData[@"matchtime"];
                temp[@"occasion_num"]=oldData[@"occasion_num"];
                temp[@"pass_type"]=oldData[@"occasion_num"];
                //‘投注类型（如：类型如果为半全场，则：1，胜胜；2，为胜平；以此类推）’
                
                NSInteger pin=0;
                //0，足球胜负平；2，足球让球；3，足球比分，4，足球进球；5，足球半全场；
                // 查询index
                
                
                //胜平负
                //oldData[@"spfList"];
                if (game_type==0) {
                    pin=  [oldData[@"spfList"] indexOfObject:odd_fenshu];
                }
                
                //让球胜平负
                // oldData[@"rqList"];
                if (game_type==1) {
                    pin=  [oldData[@"rqList"] indexOfObject:odd_fenshu];
                }
                
                //半全场
                //oldData[@"bqcList"];
                if (game_type==4) {
                    pin=  [oldData[@"bqcList"] indexOfObject:odd_fenshu];
                }
                
                //比分
                //oldData[@"bfList"];
                if (game_type==2) {
                    pin=  [oldData[@"bfList"] indexOfObject:odd_fenshu];
                }
                
                //进球
                //oldData[@"jqList"];
                if (game_type==3) {
                    pin=  [oldData[@"jqList"] indexOfObject:odd_fenshu];
                }
                
                temp[@"pin_type"]=@(pin + 1);
                
               
                
                [arraysubmit addObject:temp];
                
            }
            
            
        }
        
        
        [service post:@"/v1/member/findPersonCenter" data:nil complete:^(NSDictionary *uvalue) {
            NSDictionary * submitDic =
            @{
              @"buy_amount": ((JSValue *)args[1]).toString,
              @"buy_way": @(0),
              @"lottery_type_id": @(12), //购彩类型
              @"member_id": uvalue.str(@"id"),
              @"member_name": uvalue.str(@"name"),
              @"mulriple": ((JSValue *)args[2]).toString,
              @"pass_type": @(0),
              @"pass_way": ((JSValue *)args[3]).toString,
              @"requestOrderPackages": arraysubmit
              };
            
            
            [service post:@"/v1/order/placeOrder" data:[NSMutableDictionary dictionaryWithDictionary:submitDic] complete:^(NSDictionary *value) {
                [self hideHUD];
            }];
        }];
        
    };
    
    [webView stringByEvaluatingJavaScriptFromString:@"loadData()"];
    
    [self hideHUD];
    
    
}


#pragma mark - json

-(void)commonJson
{
    [self showHUD];
    [service post:@"/v2/date/leiSuDate" data:nil complete:^(NSDictionary *value) {
        
        NSMutableArray * array  = [NSMutableArray new];
        
        
        //过滤
        if (self.type==0) {
            for (NSDictionary * obj in value.arr(@"jczq")) {
                
//                if (![obj.str(@"sell_status") isEqualToString:@"0,0,0,0,0"]) {
                    [array addObject:obj];
//                }
                
                
            }
        }else
        {
            array =value.arr(@"jclq");
        }
        
        //数据格式处理
        
        NSMutableArray * datalist=[NSMutableArray new];
        
        for (NSMutableDictionary * mDic in array) {
            //胜平负
            mDic[@"spfList"]= [mDic.str(@"spf") componentsSeparatedByString:@","];
            
            //让球胜平负
            mDic[@"rqList"]=[mDic.str(@"rq") componentsSeparatedByString:@","];
            
            //半全场
            mDic[@"bqcList"]=[mDic.str(@"bqc") componentsSeparatedByString:@","];
            
            //比分
            mDic[@"bfList"]=[mDic.str(@"bf") componentsSeparatedByString:@","];
            
            //进球
            mDic[@"jqList"]=[mDic.str(@"jq") componentsSeparatedByString:@","];
            
            mDic[@"num"]= [mDic.str(@"issue_num") stringByReplacingCharactersInRange:NSMakeRange(0, 1) withString:@""];
            
            NSDate * date =   [NSDate dateWithTimeIntervalSince1970: mDic.i(@"matchtime")];
            
            mDic[@"time"]= [date stringWithFormat:@"HH:mm"];
            
            //            if (![datalist containsObject: [date shortTimeString]]) {
            //                [datalist addObject:[date shortTimeString]];
            
            mDic[@"longtime"]=[date shortTimeString];
            if ([mDic.str(@"issue_num")[0]  isEqualToString:@"1"]) {
                mDic[@"week"]=@"一";
            }
            if ([mDic.str(@"issue_num")[0]  isEqualToString:@"2"]) {
                mDic[@"week"]=@"二";
            }
            if ([mDic.str(@"issue_num")[0]  isEqualToString:@"3"]) {
                mDic[@"week"]=@"三";
            }
            if ([mDic.str(@"issue_num")[0]  isEqualToString:@"4"]) {
                mDic[@"week"]=@"四";
            }
            if ([mDic.str(@"issue_num")[0]  isEqualToString:@"5"]) {
                mDic[@"week"]=@"五";
            }
            if ([mDic.str(@"issue_num")[0]  isEqualToString:@"6"]) {
                mDic[@"week"]=@"六";
            }
            if ([mDic.str(@"issue_num")[0]  isEqualToString:@"7"]) {
                mDic[@"week"]=@"日";
            }
            
            // mDic[@"num"]=@"50";
            //            }
            
            
            
        }
        
        //test
        // array= [array subarrayWithRange: NSMakeRange(0, 5)];
        
        dataSource= [NSMutableArray arrayWithArray:array];
        
        
        
        if (self.type==0) {
            NSString *path = [[NSBundle mainBundle] pathForResource:web1Data[self.wrap.subviews[6].tag] ofType:@"html"];
            
            [webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]]];
            
        }
        else
        {
            NSString *path = [[NSBundle mainBundle] pathForResource:web2Data[self.wrap.subviews[4].tag] ofType:@"html"];
            
            [webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]]];
            
        }
        
        
    }];
}


- (NSInteger)getGameType:(NSString *)currentStr  {
    if ([currentStr isEqualToString:@"胜负平"]) {
        return 0;
    }
    if ([currentStr isEqualToString:@"让球胜负平"]) {
        return 1;
    }
    if ([currentStr isEqualToString:@"比分"]) {
        return 2;
    }
    if ([currentStr isEqualToString:@"总进球"]) {
        return 3;
    }
    if ([currentStr isEqualToString:@"半全场"]) {
        return 4;
    }
    if ([currentStr isEqualToString:@"混投2选1"]) {
        return 5;
    }
    
    return 6;
}



@end
