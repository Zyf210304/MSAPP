//
//  XBScoreWebViewController.h
//  MSApp
//
//  Created by stephen on 2018/9/23.
//Copyright © 2018年 stephen. All rights reserved.
//

#import "QTBaseViewController.h"

@interface XBScoreWebViewController : QTBaseViewController

@property (nonatomic , assign ) NSInteger type;

@end
