//
//  YFHomeMatchAboutView.h
//  XBApp
//
//  Created by 张亚飞 on 2018/11/2.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFHomeMatchAboutView : UIView

@property (nonatomic, copy) void(^CellDidSelect)(NSInteger count);
@end
