//
//  YFHomeProfitView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/11/2.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFHomeProfitView.h"
#import "YFOrderModel.h"

@interface YFHomeProfitView()

@property (nonatomic, strong) UIScrollView *scrollView;

@property (nonatomic, strong) UIImageView *userHeader;

@property (nonatomic, strong) UILabel *userName;

@property (nonatomic, strong) UILabel *genLbl;

@property (nonatomic, strong) UILabel *timeLBl ;
@end

@implementation YFHomeProfitView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}

- (void)initUI {
    [self addHeader];
    self.scrollView = [[UIScrollView alloc] init];
    [self addSubview:_scrollView];
    [_scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(20 *SCALE_375);
        make.left.bottom.mas_offset(0);
        make.width.mas_offset(FRAME_WIDTH);
    }];
    
    [self addCellView];
}

- (void)addHeader {
    UIView *headerView = [[UIView alloc] init];
    [self addSubview:headerView];
    headerView.backgroundColor = UIColorFromRGB(0xF06C60);
    [headerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_offset(0);
        make.height.mas_offset(20 *SCALE_375);
        make.width.mas_offset(FRAME_WIDTH);
    }];
    
    UILabel *titleLbl = [[UILabel alloc] init];
    [headerView addSubview:titleLbl];
    titleLbl.text = @"盈利单";
    titleLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    titleLbl.textColor = [UIColor whiteColor];
    [titleLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(20 *SCALE_375);
        make.centerY.equalTo(headerView.mas_centerY);
    }];
    
    
}


- (void)addCellWithArr:(NSMutableArray *)dataArr {
    
}

- (void)addCellView {
    
    UIView *CellView = [[UIView alloc] init];
    [self addSubview:CellView];
    _CellView = CellView;
    [CellView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.mas_offset(20 *SCALE_375);
        make.width.mas_offset(FRAME_WIDTH);
        make.left.mas_offset(0);
    }];
    [CellView addTapgestureWithTarget:self action:@selector(CellDidSelect:)];
    
    
    UIImageView *userHeader = [[UIImageView alloc] init];
    _userHeader = userHeader;
    [CellView addSubview:userHeader];
    userHeader.layer.masksToBounds = YES;
    userHeader.layer.cornerRadius = 22 *SCALE_375;
    userHeader.backgroundColor = Color_Base_BG;
    [userHeader mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(15 *SCALE_375);
        make.top.mas_offset(13 *SCALE_375);
        make.width.height.mas_offset(44 *SCALE_375);
    }];
    
    UILabel *userName = [[UILabel alloc] init];
    [CellView addSubview:userName];
    userName.text = @"用户姓名";
    _userName = userName;
    userName.textColor = Color_title_333;
    userName.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [userName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(userHeader.mas_right).offset(7 *SCALE_375);
        make.centerY.equalTo(userHeader.mas_centerY);
    }];
    
    
    UIView *centerView  = [[UIView alloc] init];
    [CellView addSubview:centerView];
    CGFloat lbl_width = 226 / 3 *SCALE_375;
    centerView.layer.masksToBounds = YES;
    centerView.layer.borderWidth = 1;
    centerView.layer.borderColor = UIColorFromRGB(0xE5E5E5).CGColor;
    [centerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(15 *SCALE_375);
        make.top.mas_offset(70 *SCALE_375);
        make.width.mas_offset(226 *SCALE_375);
        make.height.mas_offset(46 *SCALE_375);
    }];
    
    NSArray *titleArr = @[@"购买类型", @"串关方式", @"金额"];
    for (int i = 0; i < 3 ; i ++) {
        UILabel *titleLBl = [[UILabel alloc] init];
        [centerView addSubview:titleLBl];
        titleLBl.textColor = Color_title_333;
        titleLBl.text = titleArr[i];
        titleLBl.backgroundColor = UIColorFromRGB(0xE5E5E5);
        titleLBl.font = [UIFont systemFontOfSize:13 *SCALE_375];
        titleLBl.textAlignment = NSTextAlignmentCenter;
        [titleLBl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(lbl_width * i);
            make.width.mas_offset(lbl_width);
            make.height.mas_offset(23 *SCALE_375);
            make.top.mas_offset(0);
        }];
        
        UILabel *contentLbl = [[UILabel alloc] init];
        [centerView addSubview:contentLbl];
        contentLbl.textColor = Color_title_333;
        contentLbl.text = titleArr[i];
        contentLbl.tag = 400 + i;
        contentLbl.backgroundColor = [UIColor whiteColor];
        contentLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
        contentLbl.textAlignment = NSTextAlignmentCenter;
        [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(lbl_width * i);
            make.width.mas_offset(lbl_width);
            make.height.mas_offset(23 *SCALE_375);
            make.top.mas_offset(23 *SCALE_375);
        }];
    }
    
    
    UILabel *genLbl = [[UILabel alloc] init];
    [CellView addSubview:genLbl];
    genLbl.backgroundColor = UIColorFromRGB(0xF06C60);
    genLbl.textColor = [UIColor whiteColor];
    genLbl.text = @"跟单";
    genLbl.textAlignment = NSTextAlignmentCenter;
    genLbl.font = [UIFont systemFontOfSize:13 *SCALE_375];
    genLbl.layer.masksToBounds = YES;
    genLbl.layer.cornerRadius =  2 *SCALE_375;
    [genLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-13 *SCALE_375);
        make.top.mas_offset(71 *SCALE_375);
        make.width.mas_offset(44 *SCALE_375);
        make.height.mas_offset(22 *SCALE_375);
    }];
    
    UILabel *timeLBl = [[UILabel alloc] init];
    [CellView addSubview:timeLBl];
    _timeLBl = timeLBl;
    timeLBl.text = @"08-19 00:30截止";
    timeLBl.font = [UIFont systemFontOfSize:11 *SCALE_375];
    timeLBl.textColor = Color_title_333;
    [timeLBl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(- 13 *SCALE_375);
        make.top.equalTo(genLbl.mas_bottom).offset(12 *SCALE_375);
    }];
    
    
}


- (void)setValueWith:(YFOrderModel *)model {
    
    [self.userHeader setImageWithURLString:model.member_logo placeholderImageString:@"default_item_small"];
    
    self.userName.text = model.member_name;

    
    //self.lbtip1.text= [NSString stringWithFormat:@" %@连红 ",obj.str(@"consecutive")];  ;
    
    NSArray *contenlblArr = @[model.lottery_name, model.pass_way, [NSString stringWithFormat:@"%@元", model.buy_amount]];

    for (int i = 0; i < 3; i ++) {
        UILabel *contentLbl = [self viewWithTag:400 + i];
        contentLbl.text = contenlblArr[i];
    }
    
    self.timeLBl.text= [model.end_time substringToIndex:16];
}


- (void)CellDidSelect:(UITapGestureRecognizer *)sender {
    self.CellDidSelect();
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
