//
//  YFHomeHeaderView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/11/2.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFHomeHeaderView.h"
#import "SDCycleScrollView.h"


@interface YFHomeHeaderView()

@property(strong,nonatomic) SDCycleScrollView *examLoopBackV;

@end

@implementation YFHomeHeaderView



- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}


- (void)initUI {
    
    [self addHeaderView];
    [self addExtensionView];

}


- (void)addHeaderView {
    
    
    _examLoopBackV = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, FRAME_WIDTH, 164 *SCALE_375) delegate:nil placeholderImage:XXplaceWidthImage];
    _examLoopBackV.autoScrollTimeInterval = 4.0;
    _examLoopBackV.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
    _examLoopBackV.currentPageDotColor = [UIColor whiteColor];
//    WEAKSELF
    _examLoopBackV.clickItemOperationBlock = ^(NSInteger index) {
//        [weakSelf bannerPush:index];
    };
    [self addSubview:_examLoopBackV];
    
}


- (void)addExtensionView {
    UIView *extensionView = [[UIView alloc] init];
    [self addSubview:extensionView];
    [extensionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_offset(0);
        make.height.mas_offset(71 *SCALE_375);
    }];
    
    for (NSInteger i = 0; i < 2; i ++) {
        UIView *typeView = [[UIView alloc] init];
        [extensionView addSubview:typeView];
        [typeView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(FRAME_WIDTH / 2 * i);
            make.top.bottom.mas_offset(0);
            make.width.mas_offset(FRAME_WIDTH / 2);
        }];
        [typeView addTapGesture:^{
            self.CellDidSelect(i);
        }];
        
        UIImageView *typeIcon = [[UIImageView alloc] init];
        [typeView addSubview:typeIcon];
        typeIcon.image = [UIImage imageNamed:[NSString stringWithFormat:@"home_top%zd",i]];        [typeIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(13 *SCALE_375);
            make.width.height.mas_offset(50 *SCALE_375);
            make.centerY.equalTo(typeView.mas_centerY);
        }];
        
        UILabel *title = [[UILabel alloc] init];
        [typeView addSubview:title];
        title.text = i == 0 ?  @"开奖信息" : @"比分直播";
        title.textColor = Color_title_333;
        title.font  = [UIFont systemFontOfSize:14 *SCALE_375];
        [title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(84 *SCALE_375);
            make.top.mas_offset(19 *SCALE_375);
        }];
        
        UILabel *contentLbl = [[UILabel alloc] init];
        [typeView addSubview:contentLbl];
        contentLbl.textColor = Color_title_999;
        contentLbl.text = i == 0 ? @"查看实时开奖信息" : @"足球篮球比分直播";
        contentLbl.font = [UIFont systemFontOfSize:12 *SCALE_375];
        [contentLbl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(80 *SCALE_375);
            make.top.mas_offset(46 *SCALE_375);
        }];
        
    }
}

- (void)setBannerArr:(NSArray *)bannerArr {
    _examLoopBackV.imageURLStringsGroup = bannerArr;
    _bannerArr = bannerArr;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
