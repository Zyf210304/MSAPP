//
//  YFHomeMatchAboutView.m
//  XBApp
//
//  Created by 张亚飞 on 2018/11/2.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFHomeMatchAboutView.h"

@implementation YFHomeMatchAboutView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}


- (void)initUI {
    [self addNoticeView];
    [self addMatchAboutView];
}
- (void)addNoticeView {
    UIView *noticeView = [[UIView alloc] init];
    [self addSubview:noticeView];
//    noticeView.backgroundColor = Color_Base_BG;
    [noticeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_offset(0);
        make.width.mas_offset(FRAME_WIDTH);
        make.height.mas_offset(50 *SCALE_375);
    }];
    
    UIImageView *noticImg = [[UIImageView alloc] init];
    [noticeView addSubview:noticImg];
    noticImg.image = [UIImage imageNamed:@"home_notice"];
    [noticImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(10 *SCALE_375);
        make.width.mas_offset(46 *SCALE_375);
        make.height.mas_offset(31 *SCALE_375);
        make.centerY.equalTo(noticeView.mas_centerY);
    }];
    
    UILabel *noticLbl = [[UILabel alloc] init];
    [noticeView addSubview:noticLbl];
    noticLbl.text = @"关于我们！";
    noticLbl.textColor  = Color_title_333;
    noticLbl.font = [UIFont systemFontOfSize:14 *SCALE_375];
    [noticLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(noticImg.mas_right).offset(5 *SCALE_375);
        make.centerY.equalTo(noticeView.mas_centerY);
    }];
}

- (void)addMatchAboutView {
    
    NSArray<NSNumber *> *leftArr = @[@16, @111, @206, @301];
    NSArray *textArray = @[@"竞彩足球", @"竞彩篮球", @"竞足单关",@"胜负彩",@"竞篮单关",@"任九",@"排列3",@"排列5"];
    NSArray *imageArray = @[@"home1", @"home2", @"home3", @"home4", @"home5", @"home6", @"home7", @"home8"];
    
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 4; j ++) {
            
            UIImageView *typeImg = [[UIImageView alloc] init];
            [self addSubview:typeImg];
            typeImg.image = [UIImage imageNamed:imageArray[i *4 + j]];
            [typeImg mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_offset(leftArr[j].integerValue *SCALE_375);
                make.width.height.mas_offset(60 *SCALE_375);
                make.top.mas_offset(54 *SCALE_375 + 92 *SCALE_375 *i);
            }];
            typeImg.tag = 400 + i * 4 + j;
            [typeImg addTapgestureWithTarget:self action:@selector(CellDidSelect:)];
            
            UILabel *typeLbl = [[UILabel alloc] init];
            [self addSubview:typeLbl];
            typeLbl.text = textArray[i * 4 + j];
            typeLbl.font = [UIFont systemFontOfSize:12 *SCALE_375];
            typeLbl.textColor = Color_title_333;
            [typeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(typeImg.mas_bottom).offset(2 *SCALE_375);
                make.centerX.equalTo(typeImg.mas_centerX);
            }];
            
        }
    }
    
    
}

- (void)CellDidSelect:(UITapGestureRecognizer *)sender {
    self.CellDidSelect(sender.view.tag - 400);
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
