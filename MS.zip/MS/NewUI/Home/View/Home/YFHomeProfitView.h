//
//  YFHomeProfitView.h
//  XBApp
//
//  Created by 张亚飞 on 2018/11/2.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YFOrderModel;

@interface YFHomeProfitView : UIView

- (void)addCellWithArr:(NSMutableArray *)dataArr;

- (void)setValueWith:(YFOrderModel *)model;

@property (nonatomic, copy) void(^CellDidSelect)(void);


@property (nonatomic, strong) UIView *CellView ;
@end
