//
//  YFHomeVC.h
//  XBApp
//
//  Created by 张亚飞 on 2018/11/5.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QTBaseViewController.h"

@interface YFHomeVC : UIViewController

@end
