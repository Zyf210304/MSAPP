//
//  YFHomeVC.m
//  XBApp
//
//  Created by 张亚飞 on 2018/11/5.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFHomeVC.h"

#import "YFHomeHeaderView.h"
#import "YFHomeMatchAboutView.h"
#import "YFHomeProfitView.h"

#import "YFOrderModel.h"

#import "YFChooseMatchVC.h"
#import "YFBasketBallMatchVC.h"

@interface YFHomeVC ()

@property (nonatomic, strong) YFHomeHeaderView *header;

@property (nonatomic, strong) UIScrollView *scrollView;

@property (nonatomic, strong) YFHomeProfitView *Profit;

@property (nonatomic, strong) NSString *orderID;

@end

@implementation YFHomeVC

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    
    [self startNetWork];

    
//    [self checkVersion];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self initUI];
}

- (void)initUI {
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, -Statur_HEIGHT, FRAME_WIDTH, APP_HEIGHT + self.tabBarHeight)];
    [self.view addSubview:scrollView];
    scrollView.backgroundColor = [UIColor whiteColor];
    _scrollView = scrollView;
    
    YFHomeHeaderView *header = [[YFHomeHeaderView alloc] initWithFrame:CGRectMake(0, 0, FRAME_WIDTH, 235 *SCALE_375)];
    [scrollView addSubview:header];
    header.CellDidSelect = ^(NSInteger count) {
        [self showHint:@"即将上线"];
    };
    _header = header;

    
    YFHomeMatchAboutView *matchAbout = [[YFHomeMatchAboutView alloc] initWithFrame:CGRectMake(0, 235 *SCALE_375, FRAME_WIDTH, 244 *SCALE_375)];
    [scrollView addSubview:matchAbout];
    matchAbout.CellDidSelect = ^(NSInteger count) {
        if (count ==0) {
            
            if (!USER_DATA.isLogin) {
                [self toPageLogin];
            }
            else{
                YFChooseMatchVC *controller = [YFChooseMatchVC controllerFromXib];
                [NAVIGATION pushViewController:controller animated:YES];
            }
        }
        
        else if (count ==1)
        {
            YFBasketBallMatchVC *basketballVC = [[YFBasketBallMatchVC alloc] init];
            [self.navigationController pushViewController:basketballVC animated:YES];
            //                [self showToast:@"即将上线"];
        }
        else{
            [self showToast:@"即将上线"];
        }
    };


    YFHomeProfitView *Profit = [[YFHomeProfitView alloc] initWithFrame:CGRectMake(0, 479 *SCALE_375, FRAME_WIDTH, 192 *SCALE_375)];
    [scrollView addSubview:Profit];
    _Profit = Profit;
    Profit.CellDidSelect = ^{
        if (USER_DATA.isLogin) {
            if (_orderID.length) {
                [self toPageOrder:_orderID];
            }
        } else {
            [self toPageLogin];
        }
        
    };

    _scrollView.contentSize = CGSizeMake(FRAME_WIDTH, 671 *SCALE_375);

}


- (void)startNetWork {
    
    [[YFNetBaseManager sharedConnect] postWithPortName:@"/v1/member/getHomePageInfo" parameters:nil hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        NSLog(@"%@", responseObject);
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
            _header.bannerArr = responseObject[@"img_src"];
            
            YFOrderModel *orderModel = [[YFOrderModel alloc] init];
            NSDictionary *orderDic = responseObject[@"orderInfo"];
            if (![[orderDic class] isEqual:[NSNull class]])  {
                [orderModel setValuesForKeysWithDictionary:orderDic];
                [_Profit setValueWith:orderModel];
                _orderID = orderModel.ID.stringValue;
                _Profit.CellView.hidden = NO;
            } else {
                _Profit.CellView.hidden = YES;
            }
            
            
            
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
}

- (void)gotoOrderDetail:(UITapGestureRecognizer *)sender {
    if (_orderID.length) {
        [self toPageOrder:_orderID];
    }
}





#pragma mark  ---- 检测更新 -----
- (void)checkVersion {
    [[YFNetBaseManager sharedConnect] postWithPortName:@"v2/version/findIosVersion" parameters:nil hud:HUDStyle_hidden success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        NSNumber *netVersion = responseObject[@"ios_version"];
        if (netVersion.integerValue > 3) {
            [self gotoUpLoad];
        } else {
            NSLog(@"当前最新版本");
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
    
}

- (void)gotoUpLoad {
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"请更新最新版本" message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self gotoSafi];
    }];
    
    [alertC addAction:alertAction1];
    
    //将alertController 显示
    [self presentViewController:alertC animated:YES completion:nil];
}




- (void)gotoSafi {
    //    return;
    //    NSString * urlStr = [NSString stringWithFormat:@"http://%@",@""];
    NSURL *url = [NSURL URLWithString:@"itms-services://?action=download-manifest&url=https://qiniu.mishen888.com/manifest.plist"];
    if([[UIDevice currentDevice].systemVersion floatValue] >= 10.0){
        if ([[UIApplication sharedApplication] respondsToSelector:@selector(openURL:options:completionHandler:)]) {
            if (@available(iOS 10.0, *)) {
                [[UIApplication sharedApplication] openURL:url options:@{}
                                         completionHandler:^(BOOL success) {
                                             NSLog(@"Open %d",success);
                                         }];
            } else {
                // Fallback on earlier versions
            }
        } else {
            BOOL success = [[UIApplication sharedApplication] openURL:url];
            NSLog(@"Open  %d",success);
        }
        
    } else{
        bool can = [[UIApplication sharedApplication] canOpenURL:url];
        if(can){
            [[UIApplication sharedApplication] openURL:url];
        }
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
