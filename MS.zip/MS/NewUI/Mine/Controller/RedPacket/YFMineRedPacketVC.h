//
//  YFMineRedPacketVC.h
//  XBApp
//
//  Created by 张亚飞 on 2018/11/5.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFMineRedPacketVC : UIViewController

@property (nonatomic) BOOL isChange;

@end
