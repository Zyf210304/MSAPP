//
//  YFMineRedPacketVC.m
//  XBApp
//
//  Created by 张亚飞 on 2018/11/5.
//  Copyright © 2018年 stephen. All rights reserved.
//

#import "YFMineRedPacketVC.h"
#import "YFBase_Nav.h"
@interface YFMineRedPacketVC ()

@property (nonatomic, strong) NSNumber *reID;

@property (nonatomic, strong) NSDictionary *paramters_transfer;

@property (nonatomic, strong) UILabel *moneyLbl;
@end

@implementation YFMineRedPacketVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self initUI];
    
}


- (void)initUI {
    
    [self addHeader];
    [self addNoticLbl];
    
    YFBase_Nav *nav = [[YFBase_Nav alloc] init];
    [self.view addSubview:nav];
    nav.titleLBl.text = @"我的红包";
    [nav mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(Statur_HEIGHT + 44);
    }];
    _reID = @(-1);
    if (_isChange) {
        [self getRedList];
    } else {
        [self getReIDNetWork];
        [self getRedAmountNetWork];
    }
    
    
}

- (void)addHeader {
    UIView *headerView = [[UIView alloc] init];
    [self.view addSubview:headerView];
    headerView.backgroundColor = UIColorFromRGB(0xFF5656);
    [headerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_offset(0);
        make.height.mas_offset(256 *SCALE_375);
    }];
    
    UILabel *title = [[UILabel alloc] init];
    [headerView addSubview:title];
    title.text = @"红包余额";
    title.font = [UIFont systemFontOfSize:16 *SCALE_375];
    title.textColor = [UIColor whiteColor];
    [title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(113 *SCALE_375);
        make.centerX.equalTo(headerView.mas_centerX);
    }];
    
    
    UILabel *moneyLbl = [[UILabel alloc] init];
    [headerView addSubview:moneyLbl];
    moneyLbl.text = @"0.00元";
    _moneyLbl = moneyLbl;
    moneyLbl.font = [UIFont systemFontOfSize:30 *SCALE_375];
    moneyLbl.textColor = [UIColor whiteColor];
    [moneyLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(147 *SCALE_375);
        make.centerX.equalTo(headerView.mas_centerX);
    }];
}


- (void)addNoticLbl {
    
    UILabel *noticeLbl = [[UILabel alloc] init];
    [self.view addSubview:noticeLbl];
    noticeLbl.textColor = Color_title_666;
    noticeLbl.text = @"温馨提示:\n\n1、分享红包必须在跟单大厅左上角发起红包，生成红包二维码，通过二维码进行红包分享。\n\n2、红包分享后可被领取，用户领取红包后在彩金中显示，彩金可转入账户余额，每个账户每天可领取一次红包。\n\n3、发起人红包余额不足时可以从账户余额中转入。";
    noticeLbl.numberOfLines = 0;
    noticeLbl.font = [UIFont systemFontOfSize:15 *SCALE_375];
    [noticeLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(277 *SCALE_375);
        make.right.mas_offset(- 17 *SCALE_375);
        make.left.mas_offset(17 *SCALE_375);
    }];
    
    
    UILabel *SendLbl = [[UILabel alloc] init];
    [self.view addSubview:SendLbl];
    SendLbl.text = _isChange ? @"转至余额" : @"余额转入红包";
    SendLbl.textColor = [UIColor whiteColor];
    SendLbl.textAlignment = NSTextAlignmentCenter;
    SendLbl.backgroundColor = UIColorFromRGB(0xF52F2F);
    [SendLbl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.height.mas_offset(50 *SCALE_375);
        if (@available(iOS 11.0,*)) {
            make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        }else{
            make.bottom.mas_equalTo(0);
        }
    }];
    
    [SendLbl addTapgestureWithTarget:self action:@selector(tureLblDidSelect)];

}

- (void)tureLblDidSelect {
    if (_isChange) {
        if (_moneyLbl.text.floatValue < 0.01) {
            [self showHint:@"没有红包余额,赶快去抢吧"];
            return;
        }
        [self transActioin];
    } else {
        [self increaseAction];
    }
}





- (void)increaseAction {
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"填写添加金额" message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    [alertC addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.keyboardType = UIKeyboardTypeDecimalPad;
    }];
    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self addRedAmountNetWork:alertC.textFields.firstObject.text];
    }];
    UIAlertAction *alertAction2 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSLog(@"取消");
    }];
    //将两个按钮与alertController相关联
    [alertC addAction:alertAction2];
    [alertC addAction:alertAction1];
    
    //将alertController 显示
    [self presentViewController:alertC animated:YES completion:nil];
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark

#pragma mark  --- 红包id ---
- (void)getReIDNetWork {
    [[YFNetBaseManager sharedConnect] postWithPortName:@"/v1/red/envelopes/my/red/envelopes/id" parameters:nil hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
            _reID = responseObject[@"data"];
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}

#pragma mark  --- 红包提取 ---
- (void)getRedList {
    [[YFNetBaseManager sharedConnect] postWithPortName:@"v1/red/envelopes/receive/amount/available" parameters:nil hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
            _paramters_transfer = responseObject[@"data"];
            NSString *surplusAmountMoney = responseObject[@"data"][@"balance"];
            _moneyLbl.text = [NSString stringWithFormat:@"%.2lf元", surplusAmountMoney.floatValue];
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}



#pragma mark  ---- 获取余额
- (void)getRedAmountNetWork {
    
    
    [[YFNetBaseManager sharedConnect] postWithPortName:@"v1/red/envelopes/grant/total/balance" parameters:nil hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
            NSString *surplusAmountMoney = responseObject[@"data"];
            _moneyLbl.text = [NSString stringWithFormat:@"%.2lf元", surplusAmountMoney.floatValue];
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
    
}


#pragma mark  ---- 充值
- (void)addRedAmountNetWork:(NSString *)amout {
    
    if ([_reID isEqual:@(-1)]) {
        [self showHint:@"获取红包信息失败，不能充值"];
        return;
    }
    
    [[YFNetBaseManager sharedConnect] postWithPortName:@"v1/red/envelopes/increase" parameters:@{@"dispatchId":_reID, @"amountMoney":[NSString stringWithFormat:@"%.2lf", amout.floatValue]} hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
//            NSString *surplusAmountMoney = responseObject[@"data"];
//            _moneyLbl.text = [NSString stringWithFormat:@"%.2lf元", surplusAmountMoney.floatValue];
            [self getRedAmountNetWork];
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}

#pragma mark  ---- 提取

- (void)transRedAmountNetWork{



    
    [[YFNetBaseManager sharedConnect] postWithPortName:@"v1/red/envelopes/transfer/balance" parameters:_paramters_transfer hud:HUDStyle_noTilte success:^(NSURLSessionDataTask * _Nonnull operation, id  _Nullable responseObject) {
        if ([responseObject[@"mark"] isEqualToString:@"0"]) {
//            [self getRedList];
            [self showHint:@"转入成功"];
            [self.navigationController popViewControllerAnimated:YES];
        } else {
            [self showHint:responseObject[@"tip"]];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull operation, NSError * _Nonnull error) {
        [self showHint:@"服务器异常"];
    }];
}


- (void)transActioin {
    
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"转入余额" message:@"将所有红包转入余额" preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *alertAction1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self transRedAmountNetWork];
    }];

    [alertC addAction:alertAction1];

    [self presentViewController:alertC animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
